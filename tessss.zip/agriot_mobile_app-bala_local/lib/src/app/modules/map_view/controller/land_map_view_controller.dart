import 'package:argiot/src/app/modules/map_view/model/crop_details.dart';
import 'package:argiot/src/app/modules/map_view/model/crop_map_data.dart';
import 'package:argiot/src/app/modules/map_view/model/land_map_data.dart';
import 'package:argiot/src/app/modules/map_view/repository/land_map_view_repository.dart';
import 'package:argiot/src/app/controller/app_controller.dart';
import 'package:argiot/src/app/modules/dashboad/model/weather_data.dart';
import 'package:argiot/src/app/modules/registration/repostrory/crop_service.dart';
import 'package:argiot/src/app/modules/task/model/schedule_crop.dart';
import 'package:argiot/src/app/modules/task/model/schedule_land.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import '../../../service/utils/utils.dart';
import '../view/widgets/crop_details_bottom_sheet.dart';

class LandMapViewController extends GetxController {
  // Variables
  final LandMapViewRepository _repository = LandMapViewRepository();
  final AppDataController appDataController = Get.find();
  final ScheduleCrop allCrop = ScheduleCrop(id: 0, name: "All");

  var isLoading = true.obs;
  var lands = <ScheduleLand>[].obs;
  var landpolyline = <LatLng>[].obs;
  var selectedLand = Rxn<ScheduleLand>();
  var selectedCrop = Rxn<ScheduleCrop>();
  var mapType = MapType.normal.obs;
  var cameraPosition = const CameraPosition(
    target: LatLng(12.9716, 77.5946),
    zoom: 14,
  ).obs;

  final Rx<CropDetails?> cropDetails = Rx<CropDetails?>(null);
  final Rx<WeatherData?> weatherData = Rx<WeatherData?>(null);
  Rx<LandMapData?> landMapDetails = Rx<LandMapData?>(null);
  final RxInt landId = 0.obs;
  final RxInt cropId = 0.obs;

  GoogleMapController? mapController;
  LatLngBounds? pendingBounds;
  final polygons = <Polygon>{}.obs;
  final markers = <Marker>{}.obs;
  // Getters
  List<ScheduleCrop> get cropsForSelectedLand =>
      selectedLand.value?.crops ?? [];
  // Lifecycle
  @override
  void onInit() {
    super.onInit();
    landId.value = Get.arguments?['landId'] ?? 0;
    cropId.value = Get.arguments?['cropId'] ?? 0;
    fetchLandsAndCrops();
  }

  // Methods
  void selectLand(ScheduleLand? land) {
    selectedLand.value = land;
    selectedCrop.value = allCrop; // reset to All
    fetchLandsAndCropMap();
  }

  void selectCrop(ScheduleCrop? crop) {
    selectedCrop.value = crop ?? allCrop;
    fetchLandsAndCropMap(); // refresh polygons + zoom
  }

  void changeMapType(MapType type) {
    mapType.value = type;
  }

  void updateCameraToPolygon(List<LatLng> polygon) {
    if (polygon.isEmpty) return;

    var bounds = boundsFromLatLngList(polygon);

    if (mapController == null) {
      pendingBounds = bounds;
      return;
    }

    mapController!.animateCamera(CameraUpdate.newLatLngBounds(bounds, 60));
  }

  LatLngBounds boundsFromLatLngList(List<LatLng> list) {
    double x0 = list.first.latitude, x1 = list.first.latitude;
    double y0 = list.first.longitude, y1 = list.first.longitude;
    for (LatLng latLng in list) {
      if (latLng.latitude > x1) x1 = latLng.latitude;
      if (latLng.latitude < x0) x0 = latLng.latitude;
      if (latLng.longitude > y1) y1 = latLng.longitude;
      if (latLng.longitude < y0) y0 = latLng.longitude;
    }
    return LatLngBounds(northeast: LatLng(x1, y1), southwest: LatLng(x0, y0));
  }

  Future<void> fetchLandsAndCrops() async {
    try {
      isLoading(true);
      final result = await _repository.fetchLandsAndCrops();
      lands.assignAll(result);

      if (result.isNotEmpty) {
        if (landId.value != 0) {
          selectedLand.value = result.firstWhere(
            (land) => land.id == landId.value,
          );
          selectedCrop.value = allCrop;
          await fetchLandsAndCropMap();
        } else {
          selectedLand.value = result.first;
          selectedCrop.value = allCrop;
          await fetchLandsAndCropMap();
        }
      }
    } finally {
      isLoading(false);
    }
  }

  Future<void> fetchLandsAndCropsDetails(int cropId) async {
    try {
      // isLoading(true);
      final result = await _repository.fetcCropDetails(
        selectedLand.value!.id,
        cropId,
      );
      cropDetails.value = result;
    } finally {
      // isLoading(false);
    }
  }

  Future<Set<Marker>> buildCropMarkers(List<CropMapData> crops) async {
    final markers = <Marker>{};

    for (final crop in crops) {
      if (crop.geoMarks == null || crop.geoMarks!.isEmpty) continue;

      // find center of polygon
      final cropPoints = crop.geoMarks!
          .map((e) => LatLng(e[0].toDouble(), e[1].toDouble()))
          .toList();

      final center = LatLng(
        cropPoints.map((e) => e.latitude).reduce((a, b) => a + b) /
            cropPoints.length,
        cropPoints.map((e) => e.longitude).reduce((a, b) => a + b) /
            cropPoints.length,
      );

      BitmapDescriptor icon = BitmapDescriptor.defaultMarker;

      if (crop.cropImage != null && crop.cropImage!.isNotEmpty) {
        try {
          final bytes = await getBytesFromUrl(crop.cropImage!, width: 120);
          // ignore: deprecated_member_use
          icon = BitmapDescriptor.fromBytes(bytes);
        } catch (e) {
          print("Failed to load crop image: $e");
        }
      }

      markers.add(
        Marker(
          markerId: MarkerId("crop_${crop.cropId}"),
          position: center,
          icon: icon,
          infoWindow: InfoWindow(title: crop.cropName ?? "Crop"),
        ),
      );
    }
    return markers;
  }

  Future<void> fetchLandsAndCropMap() async {
    if (selectedLand.value == null) return;
    final result = await _repository.fetchLandsAndCropMap(
      selectedLand.value!.id,
    );
    landMapDetails.value = result;

    // land polygon
    landpolyline.value = parseLatLngListFromString(
      result.geoMarks ?? [],
    ).toList();

    // update polygons reactively
    final polySet = <Polygon>{
      if (landpolyline.isNotEmpty)
        Polygon(
          polygonId: const PolygonId("land"),
          points: landpolyline,
          fillColor: Colors.green.withAlpha(150),
          strokeColor: Colors.green,
          strokeWidth: 3,
        ),
      if (result.crops != null)
        ...result.crops!.map((crop) {
          final cropPoints = crop.geoMarks!
              .map((e) => LatLng(e[0].toDouble(), e[1].toDouble()))
              .toList();
          return Polygon(
            polygonId: PolygonId("crop_${crop.cropId}"),
            points: cropPoints,
            fillColor: Colors.orange.withAlpha(150),
            strokeColor: Colors.orange,
            strokeWidth: 2,
            consumeTapEvents: true,
            onTap: () => cropDetailsSheet(crop),
          );
        }),
    };
    polygons.assignAll(polySet);
    markers.assignAll(await buildCropMarkers(result.crops ?? []));

    // update camera
    if (selectedCrop.value?.id == 0) {
      updateCameraToPolygon(landpolyline);
    } else {
      final crop = result.crops?.firstWhere(
        (c) => c.cropId == selectedCrop.value?.id,
        orElse: () => CropMapData(),
      );
      if (crop != null && crop.geoMarks?.isNotEmpty == true) {
        final poly = crop.geoMarks!
            .map((e) => LatLng(e[0].toDouble(), e[1].toDouble()))
            .toList();
        updateCameraToPolygon(poly);
      }
    }
  }

  Future<void> cropDetailsSheet(CropMapData crop) async {
    Get.dialog(
      const Dialog(
        child: SizedBox(
          height: 100,
          width: 100,
          child: Center(child: CircularProgressIndicator(strokeWidth: 6)),
        ),
      ),
    );

    fetchWeatherData(crop.geoMarks![0][0], crop.geoMarks![0][1]);
    await fetchLandsAndCropsDetails(crop.cropId!);
    Get.back();

    Get.bottomSheet(
      isScrollControlled: true,
      CropDetailsBottomSheet(crop: crop),
    );
  }

  Future<void> fetchWeatherData(double lat, double lon) async {
    weatherData.value = await _repository.getWeatherData(lat, lon);
  }
}

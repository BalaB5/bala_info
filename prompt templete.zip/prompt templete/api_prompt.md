"Generate Django REST Framework APIs with Swagger for a model named ModelNameHere. The model has the following fields:

field1: type CharField, max_length 100, required true

field2: type ForeignKey, related_model OtherModel, required false

field3: type IntegerField, default 0, required false

field4: type JSONField, required false

field5: type ImageField, upload_to uploads/, required false

The APIs should include:

Create

Update

Delete

Status Update

Get list with search and pagination

Get detail

Requirements:

Swagger documentation included.

Memory optimization: use select_related for foreign keys, and only select required fields for list queries.

Pagination: PageNumberPagination with default page size 10, page_size query parameter.

Error handling: JSON format {status_code: int, error: string, message: string} with status codes 400, 404, 500.

Validation: required fields, foreign key existence, correct field types.

Responses in JSON format.

Optimizations: minimal loops, dynamic update only of provided fields, select_related for foreign keys.

API tag: ModelNameHere Management.

Example Input for Create API:

{
  "field1": "John Doe",
  "field2": 3,
  "field3": 25,
  "field4": {"key": "value"},
  "field5": null
}


Example Output for Successful Create:

{
  "status_code": 201,
  "message": "ModelNameHere created successfully",
  "id": 1
}


Example Output for Validation Error:

{
  "status_code": 400,
  "error": "validation_error",
  "message": "Field 'field1' is required"
}


Example Output for Get List API:

{
  "count": 50,
  "next": "http://example.com/api/modelname/?page=2",
  "previous": null,
  "results": [
    {"id": 1, "field1": "John Doe", "field3": 25, "status": 0},
    {"id": 2, "field1": "Jane Smith", "field3": 30, "status": 1}
  ]
}


Example Output for Get Detail API:

{
  "status_code": 200,
  "ModelNameHere": {
    "id": 1,
    "field1": "John Doe",
    "field2": {"id": 3, "name": "OtherModel Name"},
    "field3": 25,
    "field4": {"key": "value"},
    "field5": null,
    "status": 0
  }
}


"

================

"Generate Django REST Framework APIs with Swagger for the following Django model:

class Employee(models.Model):
    name = models.CharField(max_length=50)
    farmer = models.ForeignKey(Farmer, on_delete=models.CASCADE, null=True, blank=True)
    manager = models.ForeignKey('ManagerUser', on_delete=models.CASCADE, null=True, blank=True)
    mobile_no = models.BigIntegerField(null=True, blank=True)
    employee_type = models.ForeignKey(EmployeeType, on_delete=models.CASCADE, null=True, blank=True)
    work_type = models.ForeignKey(WorkersType, on_delete=models.CASCADE, null=True, blank=True)
    salary = models.DecimalField(max_digits=15, decimal_places=2, default=0, null=True, blank=True)
    advance = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    topay = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    locations = models.CharField(max_length=200, null=True, blank=True)
    latitude = models.FloatField(null=True, blank=True)
    longitude = models.FloatField(null=True, blank=True)
    country = models.ForeignKey(Country, on_delete=models.CASCADE, null=True, blank=True)
    state = models.ForeignKey(State, on_delete=models.CASCADE, null=True, blank=True)
    city = models.ForeignKey(City, on_delete=models.CASCADE, null=True, blank=True)
    taluk = models.ForeignKey(Taluk, on_delete=models.CASCADE, null=True, blank=True)
    village = models.ForeignKey(Village, on_delete=models.CASCADE, null=True, blank=True)
    image = models.ImageField(upload_to='employee_images/', null=True, blank=True)
    door_no = models.CharField(max_length=200, null=True, blank=True)
    pincode = models.IntegerField(null=True, blank=True)
    description = models.TextField(null=True, blank=True)
    authority_users = models.BooleanField(default=False, null=True, blank=True)
    my_farms = models.BooleanField(default=False, null=True, blank=True)
    my_sales = models.BooleanField(default=False, null=True, blank=True)
    my_expense = models.BooleanField(default=False, null=True, blank=True)
    my_inventory = models.BooleanField(default=False, null=True, blank=True)
    attendance_payouts = models.BooleanField(default=False, null=True, blank=True)
    username = models.CharField(max_length=150, null=True, blank=True)
    password = models.CharField(max_length=150, null=True, blank=True)
    employee_user = models.OneToOneField(CustomUser, on_delete=models.CASCADE, related_name='employee_profile', null=True, blank=True)
    status = models.IntegerField(default=0, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    created_by = models.ForeignKey(CustomUser, on_delete=models.CASCADE, null=True, blank=True, related_name='employee_created_by')
    updated_at = models.DateTimeField(auto_now=True, null=True, blank=True)
    updated_by = models.ForeignKey(CustomUser, on_delete=models.CASCADE, null=True, blank=True)
    translate_json = models.JSONField(null=True, blank=True)


APIs to generate:

Create Employee

Update Employee

Delete Employee

Update Employee Status

Get Employee List (with optional search by name and pagination)

Get Employee Detail

Requirements:

Include Swagger documentation.

Memory optimization: use select_related for foreign keys, and only select required fields for list queries.

Pagination: PageNumberPagination with default page size 10, page_size query parameter.

Error handling: return JSON in the format {status_code: int, error: string, message: string} with status codes 400, 404, 500.

Validation: required fields, foreign key existence, correct field types.

Optimize updates: update only provided fields dynamically.

Tag APIs with 'Employee Management'.

Example Input for Create API:

{
  "name": "John Doe",
  "farmer": 1,
  "manager": 2,
  "mobile_no": 9876543210,
  "employee_type": 1,
  "work_type": 1,
  "salary": 25000,
  "advance": 5000,
  "topay": 20000,
  "locations": "123 Street, City",
  "latitude": 12.3456,
  "longitude": 78.9012
}


Example Output for Successful Create:

{
  "status_code": 201,
  "message": "Employee created successfully",
  "id": 1
}


Example Output for Validation Error:

{
  "status_code": 400,
  "error": "validation_error",
  "message": "Field 'name' is required"
}


Example Output for Get List API:

{
  "count": 50,
  "next": "http://example.com/api/employees/?page=2",
  "previous": null,
  "results": [
    {"id": 1, "name": "John Doe", "salary": 25000, "status": 0},
    {"id": 2, "name": "Jane Smith", "salary": 30000, "status": 1}
  ]
}


Example Output for Get Detail API:

{
  "status_code": 200,
  "employee": {
    "id": 1,
    "name": "John Doe",
    "farmer": {"id": 1, "name": "Farmer Name"},
    "manager": {"id": 2, "name": "Manager Name"},
    "mobile_no": 9876543210,
    "salary": 25000,
    "advance": 5000,
    "topay": 20000,
    "status": 0
  }
}

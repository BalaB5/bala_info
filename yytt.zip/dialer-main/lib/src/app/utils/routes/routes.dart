import 'package:flutter/material.dart';
import 'package:itracker/src/app/modules/callLogs/views/screens/dialerscreen.dart';
import 'package:itracker/src/app/modules/notification/notification_page.dart';

import '../../../../pages/active_call_screen.dart';

import '../../../../pages/incoming_call_screen.dart';
 
import '../../modules/bottombar/views/screens/home.dart';
import '../../modules/bottombar/views/screens/profile.dart';
import '../../modules/callLogs/views/screens/call_logdetailscreen.dart';
import '../../modules/lead/views/screens/add_lead.dart';
import '../../modules/splash/views/screens/splash.dart';
import '../../modules/walkthrough/views/screens/onboarding_wrapper.dart';
import 'app_pages.dart';

Route<dynamic>? onGenerateRoute(RouteSettings settings) {
  switch (settings.name) {
    case RouteNames.splash:
      return defaultRoute(const Splashscreen(), settings);
    case RouteNames.permission:
      return defaultRoute(OnboardingFlow(), settings);
    case RouteNames.home:
      return defaultRoute(const Home(), settings);
    case RouteNames.dialPad:
      return defaultRoute(DialPad(), settings);
    case RouteNames.leadsDetails:
      return defaultRoute(CallDetailsScreen(), settings);
    case RouteNames.addLead:
      return defaultRoute(AddNewLeadScreen(), settings);
    case RouteNames.profile:
      return defaultRoute(const ProfilePage(), settings);
    case RouteNames.notification:
      return defaultRoute(const NotificationPage(), settings);
    case  RouteNames.incoming:
      final IncomingCallArguments args =
          settings.arguments is IncomingCallArguments
          ? settings.arguments! as IncomingCallArguments
          : const IncomingCallArguments(number: 'Unknown');
      return defaultRoute(
        IncomingCallScreen(number: args.number, caller: args.caller),
        settings,
      );
    case  RouteNames.active:
      final ActiveCallArguments args = settings.arguments is ActiveCallArguments
          ? settings.arguments! as ActiveCallArguments
          : const ActiveCallArguments(number: 'Unknown');
      return defaultRoute(
        ActiveCallScreen(
          number: args.number,
          caller: args.caller,
          isDialing: args.isDialing,
        ),
        settings,
      );
    default:
      return null;
  }
}

PageRoute<dynamic> defaultRoute(Widget child, RouteSettings settings) {
  if (settings.name ==  RouteNames.active || settings.name ==  RouteNames.incoming) {
    return PageRouteBuilder<dynamic>(
      settings: settings,
      pageBuilder: (context, animation, secondaryAnimation) => child,
      transitionDuration: const Duration(milliseconds: 300),
      reverseTransitionDuration: const Duration(milliseconds: 250),
      transitionsBuilder: (context, animation, secondaryAnimation, child) => FadeTransition(
          opacity: CurvedAnimation(parent: animation, curve: Curves.easeInOut),
          child: ScaleTransition(
            scale: Tween<double>(begin: 0.95, end: 1.0).animate(
              CurvedAnimation(parent: animation, curve: Curves.easeOutCubic),
            ),
            child: child,
          ),
        ),
    );
  }

  // Default transition for other screens
  return MaterialPageRoute<dynamic>(builder: (_) => child, settings: settings);
}

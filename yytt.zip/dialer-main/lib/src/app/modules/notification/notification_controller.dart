import 'package:get/get.dart';

class NotificationController extends GetxController {
  List<Map<String, dynamic>> notificationList = [
    {
      "id": 1,
      "title": "Missed Call",
      "description": "You missed a call from John Doe",
      "contact_name": "John Doe",
      "phone_number": "+91 9876543210",
      "call_type": "missed",
      "timestamp": "2025-11-17T09:45:20Z",
      "duration": 0,
      "is_read": false,
      "icon": "missed_call",

      "formatted_date": "Nov-12",
      "formatted_time": "08:12 PM",
      "time_ago": "8 Hrs ago",

      "detailed_message":
          "You missed an important call that John Doe attempted to reach you for earlier today. This call may require your attention as it seems to have occurred during a busy time. Please check the caller details and decide if you want to return the call soon. Tap here to view the complete information about the missed call.",
    },
    {
      "id": 2,
      "title": "Incoming Call",
      "description": "Incoming call answered from Priya",
      "contact_name": "Priya",
      "phone_number": "+91 9000001122",
      "call_type": "incoming",
      "timestamp": "2025-11-17T08:22:10Z",
      "duration": 120,
      "is_read": true,
      "icon": "incoming_call",

      "formatted_date": "Nov-12",
      "formatted_time": "08:05 PM",
      "time_ago": "10 Hrs ago",

      "detailed_message":
          "You received an incoming call from Priya that was successfully answered without any interruption. This conversation lasted for a considerable duration indicating it might have been important. If you need to revisit the call details or check additional information, you can do so easily. Tap here to access the full summary of this incoming call.",
    },
    {
      "id": 3,
      "title": "Outgoing Call",
      "description": "You called Ramesh",
      "contact_name": "Ramesh",
      "phone_number": "+91 9888899999",
      "call_type": "outgoing",
      "timestamp": "2025-11-17T07:10:55Z",
      "duration": 45,
      "is_read": true,
      "icon": "outgoing_call",

      "formatted_date": "Nov-11",
      "formatted_time": "06:10 PM",
      "time_ago": "12 Hrs ago",

      "detailed_message":
          "You initiated an outgoing call to Ramesh which was connected successfully earlier today. The call was short but may have contained important details that you might want to review later. You can revisit the call log to see the duration, time and any other associated information. Tap here to open the complete details of your outgoing call to Ramesh.",
    },
    {
      "id": 4,
      "title": "Call Reminder",
      "description": "Reminder to call the client at 6 PM",
      "contact_name": "Client",
      "phone_number": "+91 9888899999",
      "call_type": "reminder",
      "timestamp": "2025-11-17T06:00:00Z",
      "duration": 32,
      "is_read": false,
      "icon": "reminder",

      "formatted_date": "Nov-11",
      "formatted_time": "06:00 PM",
      "time_ago": "1 Day ago",

      "detailed_message":
          "This reminder is set to notify you about an important scheduled call with your client at 6 PM. The reminder ensures that you do not miss any crucial communication related to ongoing work.You may want to review the client details and prepare before placing the call.Tap here to view full reminder information and related tasks.",
    },
  ];

  var isExpand = (-1).obs;
}

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:permission_handler/permission_handler.dart';

import '../../../../../app.dart';
import '../../../utils/routes/app_pages.dart';

class SplashController extends GetxController {
  var progress = 0.0.obs;

  @override
  void onInit() {
    super.onInit();
    startLoading();
  }

  Future<void> startLoading() async {
    for (int i = 1; i <= 100; i++) {
      await Future.delayed(const Duration(milliseconds: 25));
      progress.value = i / 100;

      if (i == 100) {
        await Future.delayed(const Duration(milliseconds: 300));
        _checkPermissionsAndNavigate();
      }
    }
  }

  Future<void> _checkPermissionsAndNavigate() async {
    final bool phoneGranted = await Permission.phone.isGranted;
    final bool contactsGranted = await Permission.contacts.isGranted;

    final String route = phoneGranted && contactsGranted
        ? RouteNames.home
        : RouteNames.permission;
    await Navigator.of(
      navigatorKey.currentContext!,
    ).pushReplacementNamed(route);
  }
}

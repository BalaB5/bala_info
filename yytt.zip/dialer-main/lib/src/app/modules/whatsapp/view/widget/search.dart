import 'package:flutter/material.dart';

import '../../../../widgets/input_card_style.dart';

class SearchFilterBar extends StatelessWidget {
  final TextEditingController controller;
  final VoidCallback onFilterTap;

  const SearchFilterBar({
    super.key,
    required this.controller,
    required this.onFilterTap,
  });

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),

    child: Row(
      children: [
        Expanded(
          child: InputCardStyle(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: TextField(
              controller: controller,

              decoration: const InputDecoration(
                labelText: 'Search for model',
                border: InputBorder.none,
                prefixIcon: Icon(Icons.search, color: Colors.black),
              ),
            ),
          ),
        ),
        const SizedBox(width: 10),
        InputCardStyle(
          padding: const EdgeInsets.symmetric(horizontal: 8),
          child: IconButton(
            onPressed: onFilterTap,
            icon: const Icon(Icons.filter_alt_sharp),
          ),
        ),
      ],
    ),
  );
}

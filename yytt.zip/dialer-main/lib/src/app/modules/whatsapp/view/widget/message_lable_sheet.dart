 
import 'package:flutter/material.dart';
import 'package:get/get.dart';
 
import '../../../../../../app.dart';
import '../../../../widgets/bottom_sheet_syle.dart';
import '../../controller/note_detail_controller.dart';
import '../../controller/notes_controller.dart';

class MessageLableSheet extends StatelessWidget {
   MessageLableSheet({
    super.key,
    required this.controller,
  });

final notesController = Get.find<NotesController>();
  final NoteDetailController controller;

  @override
  Widget build(BuildContext context) => BottomSheetStyle(
    
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            'select_label'.tr,
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children:
                notesController.labels
                    .where((filter) => filter.label != 'All')
                    .map(
                      (filter) => FilterChip(
                        label: Text(filter.label),
                        selected: controller.label.value == filter.label,
                        onSelected: (selected) {
                          controller.updateLabel(filter.label);
                           navigatorKey.currentState!.pop();
                        },
                      ),
                    )
                    .toList(),
          ),
          const SizedBox(height: 50),
        ],
      ),
    );
}

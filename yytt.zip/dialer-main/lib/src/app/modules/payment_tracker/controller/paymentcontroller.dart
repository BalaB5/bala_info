import 'package:get/get.dart';

class PendingItem {
  final String name;
  final String due;
  final String amount;
  final String status;
  final String statusColor; // 'danger' or 'warning' etc.

  PendingItem({
    required this.name,
    required this.due,
    required this.amount,
    required this.status,
    required this.statusColor,
  });
}

class Paymentcontroller extends GetxController {
  // Segmented period
  final segments = ['Weekly', 'Monthly', 'Yearly'];
  final selectedSegmentIndex = 1.obs; // Monthly default

  // Statistics (sample reactive values)
  final totalCollections = 12840.0.obs;
  final collectionChangePct = 5.2.obs;
  final totalPending = 8450.0.obs;
  final overdueAmount = 2100.0.obs;

  // Chart points (normalized 0..1 for painter)
  final chartPoints = <double>[
    0.73,
    0.14,
    0.27,
    0.61,
    0.34,
    0.68,
    0.95,
    0.55,
  ].obs;

  // Pending list
  final pendingItems = <PendingItem>[].obs;

  @override
  void onInit() {
    super.onInit();
    // populate dummy data
    pendingItems.assignAll([
      PendingItem(
        name: 'Liam Johnson',
        due: 'Due: 2 days ago',
        amount: '₹350.00',
        status: 'Overdue',
        statusColor: 'danger',
      ),
      PendingItem(
        name: 'Olivia Williams',
        due: 'Due in 5 days',
        amount: '₹720.50',
        status: 'Pending',
        statusColor: 'warning',
      ),
      PendingItem(
        name: 'Noah Brown',
        due: 'Due in 12 days',
        amount: '₹1,200.00',
        status: 'Pending',
        statusColor: 'warning',
      ),
    ]);
  }

  void selectSegment(int idx) {
    selectedSegmentIndex.value = idx;
    // Example: change numbers and chart when switching segments (demo)
    if (idx == 0) {
      totalCollections.value = 4320;
      chartPoints.assignAll([0.2, 0.4, 0.35, 0.5, 0.8, 0.6, 0.7, 0.9]);
    } else if (idx == 1) {
      totalCollections.value = 12840;
      chartPoints.assignAll([0.73, 0.14, 0.27, 0.61, 0.34, 0.68, 0.95, 0.55]);
    } else {
      totalCollections.value = 142400;
      chartPoints.assignAll([0.3, 0.6, 0.55, 0.7, 0.4, 0.6, 0.85, 0.9]);
    }
  }
}

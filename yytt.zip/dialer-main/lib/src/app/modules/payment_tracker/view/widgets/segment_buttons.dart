import 'package:itracker/src/app/modules/payment_tracker/controller/paymentcontroller.dart';
import 'package:itracker/src/core/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class SegmentButtons extends StatelessWidget {
  final Paymentcontroller controller;
  const SegmentButtons({required this.controller, super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = Get.isDarkMode;
    return Obx(() => Container(
        height: 44,
        padding: const EdgeInsets.all(4),
        decoration: BoxDecoration(
          color: isDark ? Colors.grey.shade800 : Colors.grey.shade200,
          borderRadius: BorderRadius.circular(999),
        ),
        child: Row(
          children: List.generate(controller.segments.length, (index) {
            final selected = controller.selectedSegmentIndex.value == index;
            return Expanded(
              child: GestureDetector(
                onTap: () => controller.selectSegment(index),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 220),
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: selected
                        ? (isDark ? Colors.grey.shade900 : Colors.white)
                        : Colors.transparent,
                    borderRadius: BorderRadius.circular(999),
                    boxShadow: selected
                        ? [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.06),
                              blurRadius: 8,
                              offset: const Offset(0, 2),
                            ),
                          ]
                        : [],
                  ),
                  child: Text(
                    controller.segments[index],
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: selected
                          ? (isDark ? Colors.white : AppColors.textPrimary)
                          : (isDark
                                ? Colors.grey.shade300
                                : AppColors.textSecondary),
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
            );
          }),
        ),
      ));
  }
}

import 'package:flutter/material.dart';

import '../../../bottombar/views/screens/home_screen.dart';

class StatsCard extends StatelessWidget {
  final String title;
  final Widget Function() valueBuilder;
  const StatsCard({required this.title, required this.valueBuilder, super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: isDark ? Colors.grey.shade900 : Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: Theme.of(context).textTheme.bodySmall),
              const SizedBox(height: 8),
              valueBuilder(),
            ],
          ),  
           Expanded(
             child: SizedBox(
                            height: 100,
                            child: CustomPaint(
                              size: const Size(double.infinity, 100),
                              painter: StockGraphPainter(),
                            ),
                          ),
           ),
        ],
      ),
    );
  }
}

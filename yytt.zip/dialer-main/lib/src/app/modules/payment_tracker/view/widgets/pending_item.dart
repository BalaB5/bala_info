import 'package:itracker/src/app/modules/payment_tracker/controller/paymentcontroller.dart';
import 'package:itracker/src/core/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class PendingItemWidget extends StatelessWidget {
  final PendingItem item;
  const PendingItemWidget({required this.item, super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = Get.isDarkMode;
    final statusColor = item.statusColor == 'danger'
        ? AppColors.danger
        : AppColors.tertiary;

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: isDark ? Colors.grey.shade900 : Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          // icon
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: statusColor.withOpacity(0.12),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Center(
              child: Container(
                width: 10,
                height: 10,
                decoration: BoxDecoration(
                  color: statusColor,
                  shape: BoxShape.circle,
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          // name + due
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.name,
                  style: Theme.of(
                    context,
                  ).textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 4),
                Text(
                  item.due,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: isDark
                        ? Colors.grey.shade400
                        : AppColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
          // amount + status
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                item.amount,
                style: Theme.of(
                  context,
                ).textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 4),
              Text(
                item.status,
                style: Theme.of(
                  context,
                ).textTheme.bodySmall?.copyWith(color: statusColor),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// lib/src/app/modules/customer_details/customer_details_screen.dart

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../../../../../../app.dart';
import '../../../../../core/app_colors.dart';
import '../../controller/customercontroller.dart';

class CustomerDetailsScreen extends GetView<CustomerController> {
  const CustomerDetailsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context).textTheme;
    final isDark = Get.isDarkMode;

    final bg = isDark ? AppColors.backgroundDark : AppColors.background;
    final cardBg = isDark ? Colors.grey[850]! : AppColors.card;

    return Scaffold(
      backgroundColor: bg,
      body: SafeArea(
        child: Column(
          children: [
            // Top App Bar
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
              decoration: BoxDecoration(
                color: bg,
                border: Border(
                  bottom: BorderSide(
                    color: isDark ? Colors.grey[800]! : AppColors.border,
                  ),
                ),
              ),
              child: Row(
                children: [
                  IconButton(
                    onPressed: Get.back,
                    icon: Icon(
                      Icons.arrow_back,
                      color: isDark
                          ? AppColors.textLight
                          : AppColors.textPrimary,
                    ),
                  ),
                  Expanded(
                    child: Text(
                      'Customer Details',
                      textAlign: TextAlign.center,
                      style: theme.titleLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                        color: isDark
                            ? AppColors.textLight
                            : AppColors.textPrimary,
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: () {},
                    icon: Icon(
                      Icons.more_vert,
                      color: isDark
                          ? AppColors.textLight
                          : AppColors.textPrimary,
                    ),
                  ),
                ],
              ),
            ),

            // Main content
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.only(bottom: 24),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 920),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const SizedBox(height: 12),
                      // Profile Header
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            // avatar
                            Container(
                              height: 80,
                              width: 80,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                image: DecorationImage(
                                  image: NetworkImage(
                                    controller.profileImage.value,
                                  ),
                                  fit: BoxFit.cover,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(
                                      isDark ? 0.25 : 0.06,
                                    ),
                                    blurRadius: 8,
                                    offset: const Offset(0, 3),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 12),
                            // name & company
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Obx(
                                  () => Text(
                                    controller.customerName.value,
                                    style: theme.titleLarge?.copyWith(
                                      fontWeight: FontWeight.bold,
                                      color: isDark
                                          ? AppColors.textLight
                                          : AppColors.textPrimary,
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 6),
                                Obx(
                                  () => Text(
                                    controller.customerCompany.value,
                                    style: theme.bodyMedium?.copyWith(
                                      color: isDark
                                          ? Colors.grey[400]
                                          : AppColors.textSecondary,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 16),

                      // Actions Bar (grid of icons)
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: _actionItem(Icons.phone, 'Call', isDark),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: _actionItem(Icons.chat, 'Message', isDark),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: _actionItem(Icons.mail, 'Email', isDark),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: _actionItem(
                                Icons.location_on,
                                'Directions',
                                isDark,
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 12),

                      // Segmented Buttons
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: Obx(() {
                          final sel = controller.selectedTab.value;
                          return Container(
                            padding: const EdgeInsets.all(4),
                            decoration: BoxDecoration(
                              color: isDark
                                  ? Colors.grey[800]
                                  : Colors.grey.shade200,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Row(
                              children: [
                                _segmentButton(
                                  'Payments',
                                  0,
                                  sel == 0,
                                  controller,
                                  isDark,
                                ),
                                _segmentButton(
                                  'Proposals',
                                  1,
                                  sel == 1,
                                  controller,
                                  isDark,
                                ),
                                _segmentButton(
                                  'Interactions',
                                  2,
                                  sel == 2,
                                  controller,
                                  isDark,
                                ),
                              ],
                            ),
                          );
                        }),
                      ),

                      const SizedBox(height: 12),

                      // List content section — Payments list when Payments selected
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: Obx(() {
                          final tab = controller.selectedTab.value;

                          // ------------------------------------------------
                          // TAB 0 → INVOICES
                          // ------------------------------------------------
                          if (tab == 0) {
                            return Column(
                              children: controller.invoices
                                  .asMap()
                                  .entries
                                  .map(
                                    (e) => Column(
                                      children: [
                                        _invoiceRow(
                                          e.value,
                                          e.key,
                                          isDark,
                                          theme,
                                        ),
                                        const SizedBox(height: 10),
                                      ],
                                    ),
                                  )
                                  .toList(),
                            );
                          }

                          // ------------------------------------------------
                          // TAB 1 → PROPOSALS
                          // ------------------------------------------------
                          if (tab == 1) {
                            if (controller.proposals.isEmpty) {
                              return _emptyBox(
                                isDark,
                                cardBg,
                                theme,
                                'No proposals yet',
                              );
                            }

                            return Column(
                              children: controller.proposals.map((p) {
                                final color = _statusColor(p.status);

                                return Container(
                                  margin: const EdgeInsets.only(bottom: 12),
                                  padding: const EdgeInsets.all(14),
                                  decoration: BoxDecoration(
                                    color: isDark
                                        ? AppColors.backgroundDark
                                        : Colors.white,
                                    borderRadius: BorderRadius.circular(14),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.black.withOpacity(
                                          isDark ? 0.25 : 0.07,
                                        ),
                                        blurRadius: 6,
                                      ),
                                    ],
                                  ),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      // LEFT SECTION
                                      Row(
                                        children: [
                                          // ICON BOX
                                          Container(
                                            width: 48,
                                            height: 48,
                                            decoration: BoxDecoration(
                                              color: isDark
                                                  ? Colors.grey.shade700
                                                        .withOpacity(0.5)
                                                  : AppColors.background,
                                              borderRadius:
                                                  BorderRadius.circular(12),
                                            ),
                                            child: Icon(
                                              Icons.description,
                                              size: 26,
                                              color: isDark
                                                  ? AppColors.textLight
                                                  : AppColors.textPrimary,
                                            ),
                                          ),
                                          const SizedBox(width: 14),

                                          // TEXT DETAILS
                                          Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                "Proposal #${p.id}",
                                                style: theme.bodyMedium
                                                    ?.copyWith(
                                                      color: isDark
                                                          ? AppColors.textLight
                                                          : AppColors
                                                                .textPrimary,
                                                      fontWeight:
                                                          FontWeight.w600,
                                                    ),
                                              ),
                                              const SizedBox(height: 4),
                                              Text(
                                                "${p.date} - ${p.amount}",
                                                style: theme.bodySmall
                                                    ?.copyWith(
                                                      color: isDark
                                                          ? AppColors.textLight
                                                                .withOpacity(
                                                                  0.7,
                                                                )
                                                          : AppColors
                                                                .textSecondary,
                                                    ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),

                                      // STATUS BADGE
                                      Row(
                                        children: [
                                          Container(
                                            width: 8,
                                            height: 8,
                                            decoration: BoxDecoration(
                                              color: color,
                                              shape: BoxShape.circle,
                                            ),
                                          ),
                                          const SizedBox(width: 6),
                                          Text(
                                            p.status,
                                            style: theme.bodySmall?.copyWith(
                                              color: color,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                );
                              }).toList(),
                            );
                          }

                          // ------------------------------------------------
                          // TAB 2 → INTERACTIONS
                          // ------------------------------------------------
                          if (tab == 2) {
                            if (controller.interactions.isEmpty) {
                              return _emptyBox(
                                isDark,
                                cardBg,
                                theme,
                                'No interactions yet',
                              );
                            }

                            return Stack(
                              children: [
                                // Vertical Line
                                Positioned(
                                  left: 35,
                                  top: 0,
                                  bottom: 0,
                                  child: Container(
                                    width: 2,
                                    color: isDark
                                        ? Colors.grey.shade700
                                        : AppColors.border,
                                  ),
                                ),

                                // Timeline Items
                                Column(
                                  children: controller.interactions.map((it) {
                                    final iconColor = _colorForType(it.type);
                                    final icon = _iconForType(it.type);

                                    return Padding(
                                      padding: const EdgeInsets.only(
                                        left: 8,
                                        bottom: 18,
                                      ),
                                      child: Row(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          // Left Icon circle
                                          SizedBox(
                                            width: 56,
                                            child: Container(
                                              decoration: const BoxDecoration(
                                                color: AppColors.background,
                                                shape: BoxShape.circle,
                                              ),
                                              child: Container(
                                                margin: const EdgeInsets.only(
                                                  top: 2,
                                                ),
                                                width: 36,
                                                height: 36,
                                                decoration: BoxDecoration(
                                                  color: iconColor.withOpacity(
                                                    0.12,
                                                  ),
                                                  shape: BoxShape.circle,
                                                ),
                                                child: Center(
                                                  child: Icon(
                                                    icon,
                                                    color: iconColor,
                                                    size: 18,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),

                                          // Card UI
                                          Expanded(
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: isDark
                                                    ? Colors.grey.shade800
                                                    : Colors.white,
                                                borderRadius:
                                                    BorderRadius.circular(12),
                                                border: Border.all(
                                                  color: isDark
                                                      ? Colors.grey.shade700
                                                      : AppColors.border,
                                                ),
                                                boxShadow: [
                                                  BoxShadow(
                                                    color: Colors.black
                                                        .withOpacity(
                                                          isDark ? 0.12 : 0.03,
                                                        ),
                                                    blurRadius: 6,
                                                    offset: const Offset(0, 2),
                                                  ),
                                                ],
                                              ),
                                              padding: const EdgeInsets.all(12),
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  // Title
                                                  Text(
                                                    it.title,
                                                    style: theme.bodyMedium
                                                        ?.copyWith(
                                                          color: isDark
                                                              ? AppColors
                                                                    .textLight
                                                              : AppColors
                                                                    .textPrimary,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                        ),
                                                  ),
                                                  const SizedBox(height: 6),

                                                  // Date
                                                  Text(
                                                    _formatDateTime(it.at),
                                                    style: theme.bodySmall
                                                        ?.copyWith(
                                                          color: isDark
                                                              ? AppColors
                                                                    .textLight
                                                                    .withOpacity(
                                                                      0.7,
                                                                    )
                                                              : AppColors
                                                                    .textSecondary,
                                                        ),
                                                  ),
                                                  const SizedBox(height: 8),

                                                  // Body
                                                  Text(
                                                    it.body,
                                                    style: theme.bodyMedium
                                                        ?.copyWith(
                                                          color: isDark
                                                              ? AppColors
                                                                    .textLight
                                                              : AppColors
                                                                    .textPrimary,
                                                        ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    );
                                  }).toList(),
                                ),
                              ],
                            );
                          }

                          // ------------------------------------------------
                          // FALLBACK (IMPORTANT — FIXES ERROR)
                          // ------------------------------------------------
                          return const SizedBox.shrink();
                        }),
                      ),

                      const SizedBox(height: 16),

                      // Notes section
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: cardBg,
                            borderRadius: BorderRadius.circular(12),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(
                                  isDark ? 0.12 : 0.03,
                                ),
                                blurRadius: 6,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    'Notes',
                                    style: theme.titleLarge?.copyWith(
                                      fontWeight: FontWeight.bold,
                                      color: isDark
                                          ? AppColors.textLight
                                          : AppColors.textPrimary,
                                    ),
                                  ),
                                  TextButton(
                                    onPressed: () {
                                      // could navigate to notes screen
                                    },
                                    child: Text(
                                      'View All',
                                      style: theme.bodyMedium?.copyWith(
                                        color: AppColors.primary,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 8),
                              if (controller.notes.isNotEmpty)
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      DateFormat(
                                        'MMM d, yyyy',
                                      ).format(controller.notes.first.date),
                                      style: theme.bodyMedium?.copyWith(
                                        color: isDark
                                            ? AppColors.textLight
                                            : AppColors.textPrimary,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                    const SizedBox(height: 6),
                                    Text(
                                      controller.notes.first.text,
                                      style: theme.bodySmall?.copyWith(
                                        color: isDark
                                            ? Colors.grey[300]
                                            : AppColors.textSecondary,
                                      ),
                                    ),
                                    const SizedBox(height: 12),
                                    Align(
                                      alignment:
                                          Alignment.centerLeft, // or center
                                      child: SizedBox(
                                        width: 160, // << increase width here
                                        child: ElevatedButton.icon(
                                          onPressed: () {},
                                          icon: const Icon(Icons.add),
                                          label: Text(
                                            'Add Note',
                                            style: theme.bodyMedium?.copyWith(
                                              color: AppColors.primary,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                          style: ElevatedButton.styleFrom(
                                            backgroundColor: AppColors.primary
                                                .withOpacity(0.12),
                                            foregroundColor: AppColors.primary,
                                            elevation: 0,
                                            padding: const EdgeInsets.symmetric(
                                              vertical: 12,
                                            ),
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                )
                              else
                                Column(
                                  children: [
                                    Text(
                                      'No notes',
                                      style: theme.bodyMedium?.copyWith(
                                        color: isDark
                                            ? AppColors.textLight
                                            : AppColors.textPrimary,
                                      ),
                                    ),
                                    const SizedBox(height: 8),
                                    ElevatedButton.icon(
                                      onPressed: () async {},
                                      icon: const Icon(Icons.add),
                                      label: Text(
                                        'Add Note',
                                        style: theme.bodyMedium?.copyWith(
                                          color: AppColors.primary,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: isDark
                                            ? AppColors.primary.withOpacity(
                                                0.12,
                                              )
                                            : AppColors.primary.withOpacity(
                                                0.12,
                                              ),
                                        foregroundColor: AppColors.primary,
                                        elevation: 0,
                                        padding: const EdgeInsets.symmetric(
                                          vertical: 12,
                                        ),
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(
                                            10,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                            ],
                          ),
                        ),
                      ),

                      const SizedBox(height: 24),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _formatDateTime(DateTime dt) {
    // simple formatting similar to HTML: "May 28, 2024 at 2:15 PM"
    final monthNames = [
      '',
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    final month = monthNames[dt.month];
    final day = dt.day;
    final year = dt.year;
    final hour = dt.hour > 12 ? dt.hour - 12 : (dt.hour == 0 ? 12 : dt.hour);
    final minute = dt.minute.toString().padLeft(2, '0');
    final ampm = dt.hour >= 12 ? 'PM' : 'AM';
    return '$month $day, $year at $hour:$minute $ampm';
  }

  Color _colorForType(InteractionType type) {
    switch (type) {
      case InteractionType.meeting:
        return AppColors.primary;
      case InteractionType.email:
        return AppColors.danger;
      case InteractionType.call:
        return AppColors.secondary;
      case InteractionType.note:
        return AppColors.tertiary;
    }
  }

  IconData _iconForType(InteractionType type) {
    switch (type) {
      case InteractionType.meeting:
        return Icons.groups;
      case InteractionType.email:
        return Icons.mail;
      case InteractionType.call:
        return Icons.call;
      case InteractionType.note:
        return Icons.note_alt;
    }
  }

  Color _statusColor(String status) {
    switch (status) {
      case "Approved":
        return AppColors.secondary;
      case "Pending":
        return AppColors.tertiary;
      case "Rejected":
        return AppColors.danger;
      default:
        return AppColors.textSecondary;
    }
  }

  Widget _emptyBox(bool isDark, Color cardBg, TextTheme theme, String text) => Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(isDark ? 0.12 : 0.03),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Center(
        child: Text(
          text,
          style: theme.bodyMedium?.copyWith(
            color: isDark ? AppColors.textLight : AppColors.textPrimary,
          ),
        ),
      ),
    );

  Widget _actionItem(IconData icon, String label, bool isDark) {
    final theme = Theme.of(navigatorKey.currentContext!).textTheme;
    final bg = isDark ? Colors.grey[850] : AppColors.card;
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          decoration: BoxDecoration(
            color: bg,
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(isDark ? 0.08 : 0.02),
                blurRadius: 6,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          padding: const EdgeInsets.all(12),
          child: Icon(
            icon,
            color: isDark ? AppColors.textLight : AppColors.textPrimary,
            size: 22,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          label,
          style: theme.bodyMedium?.copyWith(
            color: isDark ? Colors.grey[300] : AppColors.textPrimary,
          ),
        ),
      ],
    );
  }

  Widget _segmentButton(
    String label,
    int idx,
    bool selected,
    CustomerController controller,
    bool isDark,
  ) {
    final theme = Theme.of(navigatorKey.currentContext!).textTheme;
    return Expanded(
      child: InkWell(
        onTap: () => controller.setTab(idx),
        borderRadius: BorderRadius.circular(10),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color: selected
                ? (isDark ? Colors.grey[700] : Colors.white)
                : Colors.transparent,
            borderRadius: BorderRadius.circular(8),
          ),
          child: Center(
            child: Text(
              label,
              style: selected
                  ? theme.bodyMedium?.copyWith(
                      color: AppColors.primary,
                      fontWeight: FontWeight.w700,
                    )
                  : theme.bodySmall?.copyWith(
                      color: isDark ? Colors.grey[300] : Colors.grey[600],
                    ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _invoiceRow(Invoice inv, int index, bool isDark, TextTheme theme) {
    final status = inv.status.toLowerCase();
    Color dotColor;
    Color bgColor;
    switch (status) {
      case 'paid':
        dotColor = AppColors.secondary;
        bgColor = AppColors.secondary.withOpacity(0.12);
        break;
      case 'overdue':
        dotColor = AppColors.tertiary; // close to amber
        bgColor = AppColors.tertiary.withOpacity(0.12);
        break;
      default:
        dotColor = AppColors.primary;
        bgColor = AppColors.primary.withOpacity(0.12);
    }

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: isDark ? Colors.grey[850] : AppColors.card,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(isDark ? 0.12 : 0.03),
            blurRadius: 6,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        children: [
          // icon box
          Container(
            decoration: BoxDecoration(
              color: isDark ? Colors.grey[800] : AppColors.background,
              borderRadius: BorderRadius.circular(8),
            ),
            padding: const EdgeInsets.all(10),
            child: Icon(
              Icons.receipt_long,
              color: isDark ? Colors.grey[200] : Colors.grey[700],
            ),
          ),
          const SizedBox(width: 12),
          // text
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  inv.id,
                  style: theme.bodyLarge?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: isDark ? AppColors.textLight : AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '${DateFormat.yMMMMd().format(inv.date)} - \$${inv.amount.toStringAsFixed(2)}',
                  style: theme.bodySmall?.copyWith(
                    color: isDark ? Colors.grey[300] : AppColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
          // status pill
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: bgColor,
              borderRadius: BorderRadius.circular(999),
            ),
            child: Row(
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: dotColor,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  inv.status,
                  style: theme.bodySmall?.copyWith(
                    color: dotColor,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

import 'package:itracker/src/app/modules/payment_tracker/controller/schedulecontroller.dart';
import 'package:itracker/src/core/app_colors.dart';
import 'package:itracker/src/core/app_style.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hugeicons/hugeicons.dart';

import '../../../../../../app.dart';
import '../../../../utils/routes/app_pages.dart';
import '../../../dashboard/views/screens/dashboard_screen.dart';

class SchedulesScreen extends GetView<SchedulesController> {
  const SchedulesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // ensure controller is created
    final controller = Get.put(SchedulesController());
    final theme = Theme.of(context).textTheme;
    final isDark = Get.isDarkMode;

    return Scaffold(
      backgroundColor: isDark ? AppColors.backgroundDark : AppColors.background,
      body: SafeArea(
        child: Center(
          child: Column(
            children: [
              MainAppBar(
                title: Text(
                  "Payment Schedules",
                  style: Theme.of(context).textTheme.titleLarge!,
                ),
              ),

              // Search bar
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        decoration: InputDecoration(
                          hintText: "Search by name or number...",
                          prefixIcon: const Padding(
                            padding: EdgeInsets.all(10.0),
                            child: HugeIcon(
                              icon: HugeIcons.strokeRoundedSearch01,
                              color: AppColors.textSecondary,
                            ),
                          ),
                          filled: true,
                          fillColor: AppColors.card,
                          contentPadding: const EdgeInsets.symmetric(
                            vertical: 8,
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderSide: const BorderSide(
                              color: AppColors.border,
                            ),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide:  BorderSide(
                              color: AppColors.primary,
                            ),
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                      ),
                    ),

                    // SizedBox(width: 10),
                    // Container(
                    //   width: 42,
                    //   height: 42,
                    //   padding: EdgeInsets.all(10),
                    //   decoration: BoxDecoration(
                    //     color: AppColors.card,
                    //     shape: BoxShape.circle,
                    //     boxShadow: [
                    //       BoxShadow(
                    //         color: AppColors.textSecondary.withOpacity(0.1),
                    //         blurRadius: 4,
                    //       ),
                    //     ],
                    //   ),
                    //   child: const HugeIcon(icon:HugeIcons.strokeRoundedPreferenceHorizontal, color: AppColors.textPrimary),
                    // ),
                  ],
                ),
              ),

              const SizedBox(height: 8), // chips
              Padding(
                padding: const EdgeInsets.only(left: 12, right: 12, bottom: 6),
                child: SizedBox(
                  height: 35,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      const SizedBox(width: 4),
                      _filterChip(
                        'Sort by Due Date',
                        selected: true,
                        isDark: isDark,
                      ),
                      const SizedBox(width: 8),
                      _filterChip('Upcoming', isDark: isDark),
                      const SizedBox(width: 8),
                      _filterChip('Overdue', isDark: isDark),
                      const SizedBox(width: 8),
                      _filterChip('Paid', isDark: isDark),
                      const SizedBox(width: 8),
                    ],
                  ),
                ),
              ),

              // list
              Expanded(
                child: Obx(() {
                  final items = controller.schedules;
                  if (items.isEmpty) {
                    return SingleChildScrollView(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: _emptyState(theme, isDark),
                    );
                  }

                  return ListView.separated(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount:
                        items.length + 1, // +1 for empty spacer at bottom
                    separatorBuilder: (_, __) => const SizedBox(height: 5),
                    itemBuilder: (context, index) {
                      if (index >= items.length) {
                        return const SizedBox(height: 24);
                      }
                      final s = items[index];
                      return _scheduleCard(s, theme, isDark);
                    },
                  );
                }),
              ),
            ],
          ),
        ),
      ),

      // floating add button (bottom-right)
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.pushNamed(context, RouteNames.addSchedule);
        },
        backgroundColor: AppColors.primary,
        child: const Icon(Icons.add, color: AppColors.card),
      ),
    );
  }

  Widget _filterChip(
    String label, {
    bool selected = false,
    bool isDark = false,
  }) => Container(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: AppStyle.decoration.copyWith(
        color: selected
            ? AppColors.primary.withAlpha(50)
            : (isDark ? Colors.grey[800] : Colors.white),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Row(
        children: [
          Text(
            label,
            style: Theme.of(navigatorKey.currentContext!).textTheme.bodyMedium
                ?.copyWith(
                  color: selected
                      ? AppColors.primary
                      : (isDark ? AppColors.textLight : AppColors.textPrimary),
                ),
          ),
          const SizedBox(width: 6),
          Icon(
            Icons.expand_more,
            size: AppStyle.iconSize,

            color: selected
                ? AppColors.primary
                : (isDark ? AppColors.textLight : AppColors.textPrimary),
          ),
        ],
      ),
    );

  Widget _scheduleCard(PaymentSchedule s, TextTheme theme, bool isDark) {
    Color statusColor;

    switch (s.statusLabel.toLowerCase()) {
      case 'overdue':
        statusColor = AppColors.danger;

        break;
      case 'upcoming':
        statusColor = Colors.orange.shade700;

        break;
      case 'paid':
        statusColor = Colors.green.shade700;

        break;
      default:
        statusColor = AppColors.textSecondary;

        break;
    }

    return Container(
      padding: const EdgeInsets.all(10),
      decoration: AppStyle.decoration,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // title + status
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                s.title,
                style: Theme.of(navigatorKey.currentContext!)
                    .textTheme
                    .bodyLarge
                    ?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: isDark
                          ? AppColors.textLight
                          : AppColors.textPrimary,
                    ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: statusColor.withAlpha(30),
                  borderRadius: BorderRadius.circular(5),
                ),
                child: Text(
                  s.statusLabel,
                  style: Theme.of(navigatorKey.currentContext!)
                      .textTheme
                      .bodySmall
                      ?.copyWith(
                        color: statusColor,
                        fontWeight: FontWeight.w600,
                      ),
                ),
              ),
            ],
          ),
          //  const SizedBox(height: 8),
          Text(
            s.note,
            style: Theme.of(
              navigatorKey.currentContext!,
            ).textTheme.bodySmall?.copyWith(color: AppColors.textSecondary),
          ),
          const SizedBox(height: 5),

          // progress + percent
          Row(
            children: [
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(999),
                  child: LinearProgressIndicator(
                    value: s.progress,
                    minHeight: 8,
                    backgroundColor: isDark
                        ? Colors.grey[800]
                        : Colors.grey[200],
                    valueColor: AlwaysStoppedAnimation<Color>(
                      AppColors.primary,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Text(
                '${(s.progress * 100).toStringAsFixed(0)}%',
                style: Theme.of(navigatorKey.currentContext!)
                    .textTheme
                    .bodyMedium
                    ?.copyWith(
                      color: isDark
                          ? AppColors.textLight
                          : AppColors.textPrimary,
                      fontWeight: FontWeight.w600,
                    ),
              ),
            ],
          ),

          const SizedBox(height: 3),

          // Paid / Remaining / Total
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Paid',
                      style: Theme.of(navigatorKey.currentContext!)
                          .textTheme
                          .bodySmall
                          ?.copyWith(color: AppColors.textSecondary),
                    ),

                    Text(
                      '₹${s.paid.toStringAsFixed(0)}',
                      style: Theme.of(navigatorKey.currentContext!)
                          .textTheme
                          .bodyMedium
                          ?.copyWith(fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      'Remaining',
                      style: Theme.of(navigatorKey.currentContext!)
                          .textTheme
                          .bodySmall
                          ?.copyWith(color: AppColors.textSecondary),
                    ),

                    Text(
                      '₹${s.remaining.toStringAsFixed(0)}',
                      style: Theme.of(navigatorKey.currentContext!)
                          .textTheme
                          .bodyMedium
                          ?.copyWith(fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      'Total',
                      style: Theme.of(navigatorKey.currentContext!)
                          .textTheme
                          .bodySmall
                          ?.copyWith(color: AppColors.textSecondary),
                    ),

                    Text(
                      '₹${s.total.toStringAsFixed(0)}',
                      style: Theme.of(navigatorKey.currentContext!)
                          .textTheme
                          .bodyMedium
                          ?.copyWith(fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _emptyState(TextTheme theme, bool isDark) => Column(
      children: [
        Container(
          height: 120,
          decoration: BoxDecoration(
            color: isDark ? Colors.grey[850] : Colors.grey[50],
            borderRadius: BorderRadius.circular(12),
          ),
          padding: const EdgeInsets.all(18),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                height: 56,
                width: 56,
                decoration: BoxDecoration(
                  color: AppColors.primary.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Icon(
                  Icons.receipt_long,
                  size: 32,
                  color: AppColors.primary,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                'No Payment Schedules Yet',
                style: theme.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: isDark ? AppColors.textLight : AppColors.textPrimary,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                'Tap the \'+\' button to add your first payment schedule and start tracking.',
                style: theme.bodySmall?.copyWith(
                  color: AppColors.textSecondary,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 12),
              ElevatedButton(
                onPressed: () {},
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 18,
                    vertical: 12,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.add, color: Colors.white),
                    const SizedBox(width: 8),
                    Text(
                      'Add New Schedule',
                      style: Theme.of(navigatorKey.currentContext!)
                          .textTheme
                          .bodyMedium
                          ?.copyWith(
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                          ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
}

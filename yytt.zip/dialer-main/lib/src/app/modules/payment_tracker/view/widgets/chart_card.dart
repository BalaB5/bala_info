import 'package:itracker/src/app/modules/payment_tracker/controller/paymentcontroller.dart';
import 'package:itracker/src/core/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ChartCard extends StatefulWidget {
  final Paymentcontroller controller;
  const ChartCard({required this.controller, super.key});

  @override
  State<ChartCard> createState() => _ChartCardState();
}

class _ChartCardState extends State<ChartCard>
    with SingleTickerProviderStateMixin {
  late AnimationController animCtrl;
  late Animation<double> progress;

  @override
  void initState() {
    super.initState();

    animCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );

    progress = CurvedAnimation(parent: animCtrl, curve: Curves.easeInOutCubic);

    animCtrl.forward();
  }

  @override
  void dispose() {
    animCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final controller = widget.controller;
    final theme = Theme.of(context).textTheme;
    final isDark = Get.isDarkMode;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isDark ? Colors.grey.shade900 : Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Collection Trends',
            style: theme.bodyMedium?.copyWith(
              color: isDark ? Colors.grey.shade300 : AppColors.textSecondary,
            ),
          ),

          const SizedBox(height: 6),

          Obx(
            () => AnimatedCounter(
              value: controller.totalCollections.value,
              duration: const Duration(milliseconds: 500),
              style: theme.titleLarge?.copyWith(
                fontSize: 28,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),

          const SizedBox(height: 6),

          Row(
            children: [
              Text(
                'This Month',
                style: theme.bodySmall?.copyWith(
                  color: isDark
                      ? Colors.grey.shade400
                      : AppColors.textSecondary,
                ),
              ),
              const SizedBox(width: 8),
              Obx(
                () => Text(
                  '+${controller.collectionChangePct.value}%',
                  style: theme.bodySmall?.copyWith(
                    color: AppColors.secondary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 12),

          Obx(() {
            final points = List<double>.from(controller.chartPoints);

            if (points.length < 2) {
              return const Center(child: Text("Not enough data to draw chart"));
            }

            return AnimatedBuilder(
              animation: progress,
              builder: (_, __) => SizedBox(
                  height: 180,
                  width: double.infinity,
                  child: CustomPaint(
                    painter: ChartPainter(
                      points: points,
                      color: AppColors.primary,
                      progress: progress.value,
                    ),
                  ),
                ),
            );
          }),

          const SizedBox(height: 10),

          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: List.generate(4, (i) => Text(
                'W${i + 1}',
                style: theme.bodySmall?.copyWith(
                  color: isDark
                      ? Colors.grey.shade400
                      : AppColors.textSecondary,
                  fontWeight: FontWeight.bold,
                ),
              )),
          ),
        ],
      ),
    );
  }
}

class AnimatedCounter extends StatelessWidget {
  final double value;
  final TextStyle? style;
  final Duration duration;

  const AnimatedCounter({
    super.key,
    required this.value,
    this.style,
    this.duration = const Duration(milliseconds: 600),
  });

  @override
  Widget build(BuildContext context) => TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: value),
      duration: duration,
      curve: Curves.easeOutCubic,
      builder: (context, val, _) => Text("₹${val.toStringAsFixed(0)}", style: style),
    );
}

class ChartPainter extends CustomPainter {
  final List<double> points;
  final Color color;
  final double progress;

  ChartPainter({
    required this.points,
    required this.color,
    required this.progress,
  });

  @override
  void paint(Canvas canvas, Size size) {
    if (points.isEmpty || points.length < 2) return;

    final paintLine = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round;

    final fillPaint = Paint()
      ..shader = LinearGradient(
        colors: [color.withOpacity(0.22), color.withOpacity(0.0)],
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height))
      ..style = PaintingStyle.fill;

    final Path linePath = Path();
    final Path fillPath = Path();

    final stepX = size.width / (points.length - 1);

    for (
      int i = 0;
      i < (points.length * progress).clamp(0, points.length - 1);
      i++
    ) {
      final dx = i * stepX;
      final dy = size.height - (points[i].clamp(0.0, 1.0) * size.height);

      if (i == 0) {
        linePath.moveTo(dx, dy);
        fillPath.moveTo(dx, dy);
      } else {
        linePath.lineTo(dx, dy);
        fillPath.lineTo(dx, dy);
      }
    }

    fillPath.lineTo(size.width, size.height);
    fillPath.lineTo(0, size.height);
    fillPath.close();

    canvas.drawPath(fillPath, fillPaint);
    canvas.drawPath(linePath, paintLine);
  }

  @override
  bool shouldRepaint(covariant ChartPainter oldDelegate) =>
      oldDelegate.progress != progress || oldDelegate.points != points;
}

import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../../app.dart';
import '../../../../../core/app_colors.dart';
import '../../controller/schedulecontroller.dart';

class NewSchedulePage extends GetView<SchedulesController> {
  const NewSchedulePage({super.key});

  @override
  Widget build(BuildContext context) {
    // ensure controller is available
    final theme = Theme.of(context).textTheme;
    final isDark = Get.isDarkMode;

    Color cardColor = isDark ? const Color(0xFF1C2830) : AppColors.card;
    Color borderColor = isDark
        ? const Color(0xFF38444D)
        : const Color(0xFFE5E5EA);
    Color background = isDark
        ? const Color(0xFF101c22)
        : const Color(0xFFF9F9F9);

    return Scaffold(
      backgroundColor: background,
      body: SafeArea(
        child: Column(
          children: [
            // Top App Bar
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
              color: background,
              child: Row(
                children: [
                  InkWell(
                    onTap: () => navigatorKey.currentState!.pop(),
                    borderRadius: BorderRadius.circular(8),
                    child: Padding(
                      padding: const EdgeInsets.all(6.0),
                      child: Icon(
                        Icons.arrow_back_ios_new,
                        color: isDark
                            ? AppColors.textLight
                            : AppColors.textPrimary,
                      ),
                    ),
                  ),
                  Expanded(
                    child: Text(
                      'New Schedule',
                      textAlign: TextAlign.center,
                      style: theme.titleLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                        color: isDark
                            ? AppColors.textLight
                            : AppColors.textPrimary,
                      ),
                    ),
                  ),
                  const SizedBox(width: 40), // placeholder to center title
                ],
              ),
            ),

            // Content
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 12,
                ),
                child: Column(
                  children: [
                    // Column(children: [SearchDropdown()]),
                    const SizedBox(height: 12),

                    // Amount / Date / Method Card
                    Container(
                      decoration: BoxDecoration(
                        color: cardColor,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: borderColor),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(
                              isDark ? 0.15 : 0.03,
                            ),
                            blurRadius: 6,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: Column(
                        children: [
                          _inputRow(
                            icon: Icons.money,
                            child: _textField(
                              controller: controller.totalAmount,
                              placeholder: 'Total Amount',
                              keyboardType: TextInputType.number,
                              theme: theme,
                              isDark: isDark,
                            ),
                            borderColor: borderColor,
                          ),
                          _inputRow(
                            icon: Icons.calendar_today,
                            child: GestureDetector(
                              onTap: () => controller.pickDate(context),
                              child: AbsorbPointer(
                                child: _textField(
                                  controller: controller.dueDate,
                                  placeholder: 'Due Date',
                                  readOnly: true,
                                  theme: theme,
                                  isDark: isDark,
                                ),
                              ),
                            ),
                            borderColor: borderColor,
                          ),
                          _inputRow(
                            icon: Icons.credit_card,
                            child: SizedBox(
                              height: 55, // ⭐ SAME HEIGHT as text field
                              child: Obx(() => DropdownButtonFormField<String>(
                                  initialValue:
                                      controller.paymentMethod.value.isEmpty
                                      ? null
                                      : controller.paymentMethod.value,
                                  onChanged: (v) {
                                    if (v != null) {
                                      controller.setPaymentMethod(v);
                                    }
                                  },
                                  decoration: InputDecoration(
                                    isDense:
                                        false, // ⭐ must be false for height
                                    contentPadding: const EdgeInsets.symmetric(
                                      vertical:
                                          16, // ⭐ same padding as text field
                                    ),
                                    border: InputBorder.none,
                                    hintStyle: theme.bodyMedium?.copyWith(
                                      color: isDark
                                          ? AppColors.textLight.withOpacity(0.7)
                                          : AppColors.textSecondary,
                                    ),
                                  ),
                                  hint: Text(
                                    'Payment Method',
                                    style: theme.bodyMedium?.copyWith(
                                      color: isDark
                                          ? AppColors.textLight.withOpacity(0.7)
                                          : AppColors.textSecondary,
                                    ),
                                  ),
                                  items: const [
                                    DropdownMenuItem(
                                      value: 'bank_transfer',
                                      child: Text('Bank Transfer'),
                                    ),
                                    DropdownMenuItem(
                                      value: 'credit_card',
                                      child: Text('Credit Card'),
                                    ),
                                    DropdownMenuItem(
                                      value: 'cash',
                                      child: Text('Cash'),
                                    ),
                                    DropdownMenuItem(
                                      value: 'other',
                                      child: Text('Other'),
                                    ),
                                  ],
                                  style: theme.bodyMedium?.copyWith(
                                    color: isDark
                                        ? AppColors.textLight
                                        : AppColors.textPrimary,
                                  ),
                                  dropdownColor: cardColor,
                                )),
                            ),
                            borderColor: borderColor,
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 12),

                    // Frequency Card
                    Container(
                      decoration: BoxDecoration(
                        color: cardColor,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: borderColor),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(
                              isDark ? 0.15 : 0.03,
                            ),
                            blurRadius: 6,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Payment Frequency',
                            style: theme.bodyMedium?.copyWith(
                              color: isDark
                                  ? AppColors.textLight
                                  : AppColors.textPrimary,
                            ),
                          ),
                          const SizedBox(height: 15),
                          Row(
                            children: [
                              Expanded(
                                child: Obx(
                                  () => _freqButton('One-time', controller),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Obx(
                                  () => _freqButton('Monthly', controller),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Obx(
                                  () => _freqButton('Quarterly', controller),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 12),

                    // Notes Card
                    Container(
                      decoration: BoxDecoration(
                        color: cardColor,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: borderColor),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(
                              isDark ? 0.15 : 0.03,
                            ),
                            blurRadius: 6,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      padding: const EdgeInsets.all(12),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Padding(
                            padding: EdgeInsets.only(right: 12),
                            child: Icon(Icons.notes, size: 20),
                          ),
                          Expanded(
                            child: TextField(
                              controller: controller.notes,
                              maxLines: 6,
                              decoration: InputDecoration(
                                hintText: 'Add notes...',
                                hintStyle: theme.bodyMedium?.copyWith(
                                  color: isDark
                                      ? AppColors.textLight.withOpacity(0.7)
                                      : AppColors.textSecondary,
                                ),
                                border: InputBorder.none,
                                isDense: true,
                                contentPadding: EdgeInsets.zero,
                              ),
                              style: theme.bodyMedium?.copyWith(
                                color: isDark
                                    ? AppColors.textLight
                                    : AppColors.textPrimary,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 12),

                    // Status Card
                    Container(
                      decoration: BoxDecoration(
                        color: cardColor,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: borderColor),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(
                              isDark ? 0.15 : 0.03,
                            ),
                            blurRadius: 6,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Status',
                            style: theme.bodyMedium?.copyWith(
                              color: isDark
                                  ? AppColors.textLight
                                  : AppColors.textPrimary,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Obx(
                            () => DropdownButtonFormField<String>(
                              initialValue: controller.status.value.isNotEmpty
                                  ? controller.status.value
                                  : null,
                              items: ['Upcoming', 'Overdue', 'Paid']
                                  .map(
                                    (status) => DropdownMenuItem<String>(
                                      value: status,
                                      child: Text(
                                        status,
                                        style: Theme.of(context)
                                            .textTheme
                                            .bodyMedium
                                            ?.copyWith(
                                              fontWeight: FontWeight.w600,
                                              color: status == 'Overdue'
                                                  ? AppColors.danger
                                                  : status == 'Upcoming'
                                                  ? AppColors.warning
                                                  : AppColors.success, // Paid
                                            ),
                                      ),
                                    ),
                                  )
                                  .toList(),
                              onChanged: (value) {
                                if (value != null) controller.setStatus(value);
                              },
                              decoration: const InputDecoration(
                                isDense: false,
                                contentPadding: EdgeInsets.symmetric(
                                  vertical: 4,
                                  horizontal: 0,
                                ),
                                hintText: 'Select status',
                                border: InputBorder.none, // removes underline
                              ),
                              style: Theme.of(context).textTheme.bodyLarge
                                  ?.copyWith(
                                    fontWeight: FontWeight.bold,
                                    color: AppColors.textDark,
                                  ),
                              dropdownColor: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 28), // space before sticky button
                  ],
                ),
              ),
            ),

            // Sticky Save Button
            Container(
              padding: const EdgeInsets.all(12),
              color: background,
              child: Obx(
                () => ElevatedButton(
                  onPressed: controller.saving.value
                      ? null
                      : () => controller.saveSchedule(),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primary,
                    minimumSize: const Size.fromHeight(56),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: controller.saving.value
                      ? Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const SizedBox(
                              width: 12,
                              height: 12,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            ),
                            const SizedBox(width: 12),
                            Text(
                              'Saving...',
                              style: theme.bodyMedium?.copyWith(
                                color: Colors.white,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ],
                        )
                      : Text(
                          'Save Schedule',
                          style: theme.bodyMedium?.copyWith(
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // small widgets
  Widget _inputRow({
    required IconData icon,
    required Widget child,
    required Color borderColor,
  }) => Container(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        border: Border(bottom: BorderSide(color: borderColor)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: Icon(icon, size: 22),
          ),
          Expanded(child: child),
        ],
      ),
    );

  Widget _textField({
    required TextEditingController controller,
    required String placeholder,
    TextInputType keyboardType = TextInputType.text,
    bool readOnly = false,
    required TextTheme theme,
    required bool isDark,
  }) => TextField(
      controller: controller,
      readOnly: readOnly,
      keyboardType: keyboardType,

      decoration: InputDecoration(
        hintText: placeholder,
        hintStyle: theme.bodyMedium?.copyWith(
          color: isDark
              ? AppColors.textLight.withOpacity(0.75)
              : AppColors.textSecondary,
        ),

        border: InputBorder.none,
        isDense: false,

        // ⭐ Increase height here
        contentPadding: const EdgeInsets.symmetric(
          vertical: 18, // <-- increase as needed (16–20 recommended)
        ),
      ),

      style: theme.bodyMedium?.copyWith(
        color: isDark ? AppColors.textLight : AppColors.textPrimary,
      ),
    );

  Widget _freqButton(String label, SchedulesController ctrl) {
    final theme = Theme.of(navigatorKey.currentContext!).textTheme;
    final isDark = Get.isDarkMode;
    final selected = ctrl.frequency.value == label;
    return InkWell(
      onTap: () => ctrl.setFrequency(label),
      borderRadius: BorderRadius.circular(10),
      child: Container(
        height: 44,
        decoration: BoxDecoration(
          color: selected
              ? AppColors.primary
              : (isDark ? Colors.white10 : Colors.grey[100]),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: selected ? AppColors.primary : Colors.transparent,
          ),
        ),
        alignment: Alignment.center,
        child: Text(
          label,
          style: theme.bodyMedium?.copyWith(
            color: selected
                ? Colors.white
                : (isDark ? AppColors.textLight : AppColors.textPrimary),
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }
}

// To preview quickly, you can use this as a standalone app:
void main() {
  runApp(
    GetMaterialApp(
      debugShowCheckedModeBanner: false,
      home: const NewSchedulePage(),
      theme: ThemeData(
        brightness: Brightness.light,
        textTheme: const TextTheme(
          titleLarge:
              TextStyle(), // will inherit default sizes; we won't set sizes
          bodyMedium: TextStyle(),
          bodySmall: TextStyle(),
        ),
      ),
      darkTheme: ThemeData.dark(),
      themeMode: ThemeMode.system,
    ),
  );
}

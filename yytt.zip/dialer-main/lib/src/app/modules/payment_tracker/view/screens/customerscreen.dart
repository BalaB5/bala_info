import 'package:itracker/src/app/modules/payment_tracker/controller/customercontroller.dart';
import 'package:itracker/src/core/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hugeicons/hugeicons.dart';

import '../../../../../../app.dart';
import '../../../../../core/app_style.dart';
import '../../../../controller/app_controller.dart';
import '../../../../utils/routes/app_pages.dart';
import '../../../../widgets/widget_gap.dart'; 

class CustomerScreen extends GetView<CustomerController> {
  CustomerScreen({super.key});
  final AppDataController appDeta = Get.find();

  @override
  Widget build(BuildContext context) {
    final isDark = Get.isDarkMode;

    int role = appDeta.roleId.value;
    return Scaffold(
      backgroundColor: isDark ? AppColors.backgroundDark : AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            // HEADER
            const AppSearchBar(),

            if (role == 2) ...[
              const WidgetGap(),

              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: SizedBox(
                  height: 35,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      _filterChip("All POS", selected: true, isDark: isDark),
                      const SizedBox(width: 10),
                      _filterChip("Proposal Status", isDark: isDark),
                      const SizedBox(width: 10),
                      _filterChip("Reminder Status", isDark: isDark),
                    ],
                  ),
                ),
              ),
            ] else ...[
              const WidgetGap(),

              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: SizedBox(
                  height: 35,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      _filterChip("All", selected: true ),
                      const SizedBox(width: 10),
                      _filterChip("CRM",  ),
                      const SizedBox(width: 10),
                      _filterChip("Assign to",  ),
                    ],
                  ),
                ),
              ),
            ],
            const WidgetGap(),
            Expanded(
              child: Obx(
                () => ListView.separated(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  itemCount: controller.customers.length,
                  separatorBuilder: (_, __) =>
                      const SizedBox(height: AppStyle.listGap),
                  itemBuilder: (context, index) {
                    final customer = controller.customers[index];
                    return CustomerCard(customer: customer);
                  },
                ),
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.pushNamed(context, RouteNames.addLead);
        },
        backgroundColor: AppColors.primary,
        child:   const HugeIcon(
            icon:HugeIcons.strokeRoundedUserAdd02,
            color:  AppColors.card,
            size: AppStyle.iconSizelarge,
          ),
      ),
    );
  }

  // Filter Chip Widget
  Widget _filterChip(
    String label, {
    bool selected = false,
    bool isDark = false,
  }) {
    final theme = Theme.of(navigatorKey.currentContext!).textTheme;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: AppStyle.decoration.copyWith(
        color: selected ? AppColors.primary : AppColors.card,
        borderRadius: BorderRadius.circular(AppStyle.borderRadiusClip),
      ),
      child: Row(
        children: [
          Text(
            label,
            style: theme.bodyMedium?.copyWith(
              color: selected ? AppColors.card : AppColors.textDark,
            ),
          ),
          const SizedBox(width: 4),
          Icon(
            Icons.expand_more,
            color: selected ? AppColors.card : AppColors.textDark,
            size: AppStyle.iconSize,
          ),
        ],
      ),
    );
  }
}

class AppSearchBar extends StatelessWidget {
  const AppSearchBar({super.key});

  @override
  Widget build(BuildContext context) => Container(
      margin: const EdgeInsets.symmetric(horizontal: 10),
      padding: const EdgeInsets.symmetric(horizontal: 8),
      decoration: AppStyle.decoration,
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            padding: const EdgeInsets.all(10),

            child: const HugeIcon(
              icon: HugeIcons.strokeRoundedSearch01,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(width: 10),
          const Expanded(
            child: TextField(
              decoration: InputDecoration(
                hintText: "Search by name or number...",

                contentPadding: EdgeInsets.all(0),
                border: InputBorder.none,
              ),
            ),
          ),
        ],
      ),
    );
}

class CustomerCard extends StatelessWidget {
  final Customer customer;

  final AppDataController appDeta = Get.find();

  CustomerCard({required this.customer, super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = Get.isDarkMode;
    final theme = Theme.of(context).textTheme;
    int role = appDeta.roleId.value;
    return GestureDetector(
      onTap: () {
        Navigator.pushNamed(context, RouteNames.leadsDetails);
      },
      child: Container(
        decoration: isDark ? AppStyle.decorationDark : AppStyle.decoration,
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        // margin: const EdgeInsets.symmetric(vertical: 3),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // Profile Image
            Container(
              height: 40,
              width: 40,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                image: DecorationImage(
                  image: NetworkImage(customer.profileImage),
                  fit: BoxFit.cover,
                ),
              ),
            ),
            const SizedBox(width: 8),

            // Customer Info
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    customer.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: theme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: isDark ? Colors.white : AppColors.textDark,
                    ),
                  ),

                  Text(
                    role == 2 ? "ID: ${customer.id}" : customer.id,
                    style: theme.bodySmall?.copyWith(
                      color: isDark
                          ? Colors.grey[400]
                          : AppColors.textSecondary,
                    ),
                  ),
                  if (role == 2) ...[
                    const SizedBox(height: 6),

                    Wrap(
                      spacing: 6,
                      runSpacing: 4,
                      children: [
                        _proposalChip(customer.proposalStatus, isDark),

                        if (customer.reminderStatus != null)
                          _reminderChip(customer.reminderStatus!, isDark),
                      ],
                    ),
                  ],
                ],
              ),
            ),

            if (role == 2)
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    customer.dueAmount,
                    style: theme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: isDark ? Colors.white : AppColors.danger,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    "Due",
                    style: theme.bodyMedium?.copyWith(
                      // fontWeight: FontWeight.bold,
                      color: isDark ? Colors.white : AppColors.textDark,
                    ),
                  ),
                ],
              )
            else
              Container(
                height: 40,
                width: 40,
                decoration: BoxDecoration(
                  color: AppColors.primary10(0.1),
                  shape: BoxShape.circle,
                  border: Border.all(color: AppColors.primary.withAlpha(100)),
                ),
                child: Icon(
                  Icons.call,
                  color: AppColors.primary,
                  size: AppStyle.iconSize,
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _proposalChip(String status, bool isDark) {
    final theme = Theme.of(navigatorKey.currentContext!).textTheme;

    Color textColor;
    Color bgColor;

    switch (status.toLowerCase()) {
      case "accepted":
        textColor = const Color(0xFF0A6F5A);
        bgColor = const Color(0xFFD7F3EC);
        break;

      case "sent":
        textColor = const Color(0xFF0D47A1);
        bgColor = const Color(0xFFDCE8FF);
        break;

      case "draft":
        textColor = Colors.grey[800]!;
        bgColor = const Color(0xFFE8E8E8);
        break;

      default:
        textColor = Colors.grey[700]!;
        bgColor = Colors.grey[300]!;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: bgColor.withAlpha(140),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        "Proposal: $status",
        style: theme.bodySmall?.copyWith(
          fontWeight: FontWeight.w600,
          color: textColor,
        ),
      ),
    );
  }

  Widget _reminderChip(String status, bool isDark) {
    final theme = Theme.of(navigatorKey.currentContext!).textTheme;

    Color textColor;
    Color bgColor;

    switch (status.toLowerCase()) {
      case "sent":
        textColor = const Color(0xFFB71C1C);
        bgColor = const Color(0xFFFFDAD6);
        break;

      case "scheduled":
        textColor = const Color(0xFF8C5300);
        bgColor = const Color(0xFFFFE8C7);
        break;

      default:
        textColor = Colors.grey[700]!;
        bgColor = Colors.grey[300]!;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: bgColor.withAlpha(140),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        "Reminder: $status",
        style: theme.bodySmall?.copyWith(
          fontWeight: FontWeight.w600,
          color: textColor,
        ),
      ),
    );
  }
}

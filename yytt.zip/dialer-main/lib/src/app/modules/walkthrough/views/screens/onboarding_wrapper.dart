import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'firstscreen.dart';
import 'secondscreen.dart';
import 'thirdscreen.dart';
import '../../controller/onboarding_controller.dart';

class OnboardingFlow extends StatelessWidget {
  final controller = Get.put(OnboardingController());

  OnboardingFlow({super.key});

  final screens = [const OnboardingScreen(), const PermissionScreen(), const AppSettingsScreen()];

  @override
  Widget build(BuildContext context) => Obx(() => screens[controller.pageIndex.value]);
}

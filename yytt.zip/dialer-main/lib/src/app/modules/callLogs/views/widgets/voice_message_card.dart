import 'package:flutter/material.dart';

import '../../../../../../core/models/call_log_entry.dart';
import '../../../../../core/app_colors.dart';
import '../../../../../core/app_style.dart';

class VoiceMessageCard extends StatelessWidget {
  const VoiceMessageCard({super.key, this.color});
  final Color? color;
  @override
  Widget build(BuildContext context) => Container(
    decoration: AppStyle.decoration,
    margin: const EdgeInsets.only(bottom: AppStyle.listGap),
    padding: const EdgeInsets.all(10),
    child: Row(
      children: [
        // Left section: date & message
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  AppColors.getCallTypeIcon(CallType.incoming),
                  Text(
                    "21/02/2025 10:32am",
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                              color:  color ?? AppColors.textPrimary,
                                              fontWeight: FontWeight.w600,
                                            )
                  ),
                ],
              ),

              const SizedBox(height: 3),
              if (color == null)
                Text(
                  "Just wanted to confirm if you received my previous email regarding ...",
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: AppColors.textSecondary,
                    height: 1,
                  ),
                ),
            ],
          ),
        ),
        const SizedBox(width: 10),
        if (color == null)
          // Right section: play icon and red rec dot
          Column(
            children: [
              Stack(
                alignment: Alignment.center,
                children: [
                  // Play button circle
                  Container(
                    decoration: BoxDecoration(
                      color: AppColors.primary.withAlpha(30),
                      shape: BoxShape.circle,
                    ),
                    padding: const EdgeInsets.all(5),
                    child: Icon(
                      Icons.play_arrow,
                      color:  AppColors.primary,
                      size: AppStyle.iconSize,
                    ),
                  ),

                  // Red dot positioned bottom right
                  Positioned(
                    bottom: 2,
                    right: 2,
                    child: Container(
                      width: 5,
                      height: 5,
                      decoration: const BoxDecoration(
                        color: Colors.red,
                        shape: BoxShape.circle,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(width: 8),
              Text("10:00", style: Theme.of(context).textTheme.bodySmall),
            ],
          ),
      ],
    ),
  );
}

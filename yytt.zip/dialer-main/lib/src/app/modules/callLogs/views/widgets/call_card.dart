import 'dart:math';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:itracker/src/app/modules/callLogs/controller/followup_add_controller.dart';

import '../../../../../../bottom_sheet.dart';
import '../../../../../../core/models/call_log_entry.dart';
import '../../../../../../tt.dart';
import '../../../../../core/app_colors.dart';
import '../../../../../core/app_style.dart';
import '../../../../utils/routes/app_pages.dart';
import '../../../../utils/utils.dart';
import '../../../../widgets/action_button.dart';
import '../../../test/view/screens/template_bottom_sheet.dart';
import '../../controller/call_logcontroller.dart';
import 'add_follow_up_bottom_sheet.dart';
import 'agent_selection_bottom_sheet.dart';
import 'tag_card.dart';

class CallCard extends GetView<CallLogsController> {
  const CallCard({
    super.key,
    required this.call,
    required this.isExpended,
    required this.onTop,
  });

  final Map<String, dynamic> call;
  final bool isExpended;
  final VoidCallback onTop;

  @override
  Widget build(BuildContext context) {
    final CallType type = call["type"];
    return Column(
      children: [
        InkWell(
          onTap: onTop,

          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),

            decoration: AppStyle.decoration,
            child: Column(
              children: [
                Row(
                  children: [
                    Column(
                      children: [
                        const SizedBox(height: 5),
                        InkWell(
                          onTap: () {
                            Navigator.pushNamed(
                              context,
                              RouteNames.leadsDetails,
                            );
                          },
                          child: Stack(
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(
                                  bottom: 10,
                                  right: 10,
                                ),
                                child: Container(
                                  width:
                                      40, // Set size (CircleAvatar default = 40)
                                  height: 40,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: Color.fromARGB(
                                      50,
                                      Random().nextInt(256),
                                      Random().nextInt(256),
                                      Random().nextInt(256),
                                    ),
                                  ),
                                  alignment: Alignment.center,
                                  child: Text(
                                    call["name"][0].toUpperCase(),
                                    style: const TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black87,
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                bottom: 0,
                                right: 0,
                                child: AppColors.getCallTypeIcon(type),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(width: 8),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          call["name"],
                          style: Theme.of(context).textTheme.bodyMedium
                              ?.copyWith(
                                color: type == CallType.missed
                                    ? AppColors.danger
                                    : null,
                                fontWeight: FontWeight.w600,
                              ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        InkWell(
                          onTap: () {
                            Navigator.pushNamed(
                              context,
                              RouteNames.leadsDetails,
                            );
                          },
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 0),
                            child: Row(
                              children: [
                                InkWell(
                                  onTap: () {
                                    Navigator.pushNamed(
                                      context,
                                      RouteNames.leadsDetails,
                                    );
                                  },
                                  child: Text(
                                    call["time"],
                                    style: Theme.of(context)
                                        .textTheme
                                        .bodySmall!
                                        .copyWith(
                                          color: Get.isDarkMode
                                              ? Colors.grey[400]
                                              : AppColors.textSecondary,
                                        ),
                                  ),
                                ),
                                // const SizedBox(width: 1),
                                Text(
                                  type == CallType.missed
                                      ? "00:00"
                                      : Utils.formatDuration(
                                          int.tryParse("333") ?? 0,
                                        ),
                                  style: Theme.of(context).textTheme.bodySmall!
                                      .copyWith(
                                        color: Get.isDarkMode
                                            ? Colors.grey[400]
                                            : AppColors.textSecondary,
                                      ),
                                ),
                                // if (call["time"] != null)
                                if (type == CallType.incoming ||
                                    type == CallType.outgoing) ...[
                                  Container(
                                    decoration: AppStyle.decoration.copyWith(
                                      color: Colors.red.withAlpha(50),
                                      boxShadow: [],
                                    ),
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 4,
                                      vertical: 2,
                                    ),
                                    margin: const EdgeInsets.symmetric(
                                      horizontal: 4,
                                    ),
                                    child: Row(
                                      children: [
                                        const Icon(
                                          Icons.circle,
                                          color: Colors.red,
                                          size: 8,
                                        ),
                                        Text(
                                          "RCE",
                                          style: Theme.of(context)
                                              .textTheme
                                              .bodySmall
                                              ?.copyWith(
                                                color: Colors.black,
                                                fontSize: 9,
                                              ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  // LocalAudioPlayer(audioPath: audioPath!),
                                ],
                              ],
                            ),
                          ),
                        ),

                        SizedBox(height: 6),
                        SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: Row(
                            children: [
                              TagCard(
                                onTap: () {
                                  // showTagBottomSheet();
                                },
                                color: Colors.orange,
                                lable: "VIP",
                              ),
                              TagCard(
                                onTap: () {},
                                color: Colors.blueGrey,
                                lable: "Call Back",
                                // icon: Icons.add,
                              ),
                              TagCard(
                                onTap: () {
                                  showTagBottomSheet();
                                },
                                color: Colors.blue,
                                lable: "",
                                icon: Icons.add,
                                // icon: Icons.add,
                              ),

                              // Spacer(),
                              // Flexible(
                              //   child: ,
                              // ),
                              // Row(
                              //   children: [
                              //     IconButton(onPressed: (){}, icon: Icon(Icons.mic)),
                              //   ],
                              // )
                            ],
                          ),
                        ),
                      ],
                    ),

                    const Spacer(),
                    Container(
                      height: 40,
                      width: 40,
                      decoration: BoxDecoration(
                        color: AppColors.primary.withAlpha(20),
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: AppColors.primary.withAlpha(100),
                        ),
                      ),
                      child: Icon(
                        Icons.call,
                        color: AppColors.primary,
                        size: AppStyle.iconSize,
                      ),
                    ),
                  ],
                ),
                if (isExpended)
                  Container(
                    // margin: const EdgeInsets.symmetric(
                    //   vertical: 4,
                    //   horizontal: 4,
                    // ),
                    padding: const EdgeInsets.all(5),
                    // decoration: AppStyle.decoration.copyWith(boxShadow: []),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Expanded(
                          child: ActionButton(
                            icon: HugeIcons.strokeRoundedPropertyAdd,
                            label: 'Add Follow Up',
                            color: Theme.of(context).primaryColor,
                            //onTap: openAddFollowUpBottomSheet,
                            onTap: () {
                              final controller = Get.put(
                                FollowUpAddController(),
                              );
                              controller.setCall(
                                call,
                              ); // ✅ now it's the correct controller
                              openAddFollowUpBottomSheet();
                            },
                          ),
                        ),
                        const Expanded(
                          child: ActionButton(
                            icon: HugeIcons.strokeRoundedWhatsapp,
                            label: 'Whatsapp',
                            color: AppColors.secondary,
                            onTap: openTemplateBottomSheet,
                          ),
                        ),
                        Expanded(
                          child: ActionButton(
                            icon: HugeIcons.strokeRoundedBubbleChat,
                            label: 'SMS',
                            color: Colors.blue,
                            onTap: () {
                              // openSMS(number);
                            },
                          ),
                        ),
                        Expanded(
                          child: ActionButton(
                            icon: HugeIcons.strokeRoundedUserSwitch,
                            label: 'Assigned to',
                            color: Colors.indigo,
                            onTap: () {
                              openButtomsheet(AgentSelectionBottomSheet());
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ),
        // Divider(height: 1, color: Theme.of(context).primaryColor.withAlpha(10)),
      ],
    );
  }
}

class FollowUpBottomSheetDraggable extends StatelessWidget {
  const FollowUpBottomSheetDraggable({super.key});

  @override
  Widget build(BuildContext context) => DraggableScrollableSheet(
    initialChildSize: 0.65,
    minChildSize: 0.40,
    maxChildSize: 0.95,
    expand: false,
    builder: (_, controller) => SingleChildScrollView(
      controller: controller,
      child: const FollowUpBottomSheet(),
    ),
  );
}

class FollowUpBottomSheet extends GetView<CallLogsController> {
  const FollowUpBottomSheet({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context).textTheme;

    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // small handle
          Padding(
            padding: const EdgeInsets.only(top: 12, bottom: 8),
            child: Container(
              height: 4,
              width: 38,
              decoration: BoxDecoration(
                color: Colors.grey.shade300,
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),

          // Header Icon + Title
          Padding(
            padding: const EdgeInsets.only(top: 6, bottom: 4),
            child: Column(
              children: [
                Container(
                  height: 54,
                  width: 54,
                  decoration: BoxDecoration(
                    color: AppColors.primary.withOpacity(0.08),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    Icons.notifications_active,
                    size: 26,
                    color: AppColors.primary,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  "Follow-Up Reminder",
                  style: theme.titleLarge?.copyWith(
                    color: AppColors.textPrimary,
                    fontWeight: FontWeight.w700,
                    fontSize: 22,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 4),

          // Contact Info
          _premiumInfoTile(
            icon: Icons.person_rounded,
            text: "Jane Doe • Innovate Corp",
            theme: theme,
          ),
          _premiumInfoTile(
            icon: Icons.call_rounded,
            text: "Follow-up Call",
            theme: theme,
          ),
          _premiumInfoTile(
            icon: Icons.access_time_filled_rounded,
            text: "Today at 3:00 PM",
            theme: theme,
          ),

          const SizedBox(height: 6),

          // Snooze section
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 6),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Snooze For",
                  style: theme.bodySmall?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: Colors.grey.shade600,
                    fontSize: 12.5,
                  ),
                ),
                const SizedBox(height: 8),

                GridView.count(
                  shrinkWrap: true,
                  crossAxisCount: 2,
                  childAspectRatio: 3.3,
                  mainAxisSpacing: 10,
                  crossAxisSpacing: 10,
                  physics: const NeverScrollableScrollPhysics(),
                  children: [
                    _snoozeBtn("5 minutes"),
                    _snoozeBtn("15 minutes"),
                    snoozeBtnLight("30 minutes"),
                    snoozeBtnLight("1 hour"),
                  ],
                ),

                const SizedBox(height: 12),

                // Custom button
                GestureDetector(
                  onTap: () => controller.toggleCustomFields(),
                  child: Container(
                    height: 48,
                    decoration: BoxDecoration(
                      color: Colors.grey.shade100,
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(
                          Icons.tune_rounded,
                          size: 18,
                          color: AppColors.textPrimary,
                        ),
                        const SizedBox(width: 6),
                        Text(
                          "Custom",
                          style: theme.bodyMedium?.copyWith(
                            fontWeight: FontWeight.w600,
                            color: AppColors.textPrimary,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 12),

                // Custom Fields (Date & Time)
                Obx(() {
                  if (!controller.showCustomFields.value) {
                    return const SizedBox();
                  }

                  final dt = controller.customDateTime.value;

                  return Row(
                    children: [
                      // Date Field
                      Expanded(
                        child: GestureDetector(
                          onTap: () async {
                            final date = await showDatePicker(
                              context: context,
                              initialDate: dt ?? DateTime.now(),
                              firstDate: DateTime.now(),
                              lastDate: DateTime(2100),
                            );
                            if (date != null) {
                              final oldTime = dt != null
                                  ? TimeOfDay.fromDateTime(dt)
                                  : TimeOfDay.now();
                              controller.customDateTime.value = DateTime(
                                date.year,
                                date.month,
                                date.day,
                                oldTime.hour,
                                oldTime.minute,
                              );
                            }
                          },
                          child: Container(
                            height: 48,
                            decoration: BoxDecoration(
                              color: Colors.grey.shade100,
                              borderRadius: BorderRadius.circular(14),
                            ),
                            padding: const EdgeInsets.symmetric(horizontal: 12),
                            child: Row(
                              children: [
                                const Icon(
                                  Icons.calendar_today_rounded,
                                  size: 20,
                                ),
                                const SizedBox(width: 8),
                                Text(
                                  dt != null
                                      ? "${dt.day}/${dt.month}/${dt.year}"
                                      : "Select Date",
                                  style: TextStyle(
                                    fontWeight: FontWeight.w600,
                                    color: dt != null
                                        ? AppColors.textPrimary
                                        : Colors.grey,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),

                      const SizedBox(width: 12),

                      // Time Field
                      Expanded(
                        child: GestureDetector(
                          onTap: () async {
                            final time = await showTimePicker(
                              context: context,
                              initialTime: dt != null
                                  ? TimeOfDay.fromDateTime(dt)
                                  : TimeOfDay.now(),
                            );
                            if (time != null) {
                              final oldDate = dt ?? DateTime.now();
                              controller.customDateTime.value = DateTime(
                                oldDate.year,
                                oldDate.month,
                                oldDate.day,
                                time.hour,
                                time.minute,
                              );
                            }
                          },
                          child: Container(
                            height: 48,
                            decoration: BoxDecoration(
                              color: Colors.grey.shade100,
                              borderRadius: BorderRadius.circular(14),
                            ),
                            padding: const EdgeInsets.symmetric(horizontal: 12),
                            child: Row(
                              children: [
                                const Icon(Icons.access_time_rounded, size: 20),
                                const SizedBox(width: 8),
                                Text(
                                  dt != null
                                      ? "${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}"
                                      : "Select Time",
                                  style: TextStyle(
                                    fontWeight: FontWeight.w600,
                                    color: dt != null
                                        ? AppColors.textPrimary
                                        : Colors.grey,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  );
                }),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Cleaner info tile
  Widget _premiumInfoTile({
    required IconData icon,
    required String text,
    required TextTheme theme,
  }) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
    child: Row(
      children: [
        Container(
          height: 42,
          width: 42,
          decoration: BoxDecoration(
            color: Colors.grey.shade100,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(icon, size: 20, color: AppColors.textPrimary),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            text,
            style: theme.bodyMedium?.copyWith(
              color: AppColors.textPrimary,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      ],
    ),
  );

  // Premium snooze button
  Widget _snoozeBtn(String label) => GestureDetector(
    onTap: () => controller.onSnooze(label),
    child: Container(
      decoration: BoxDecoration(
        color: AppColors.primary.withOpacity(.15),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Center(
        child: Text(
          label,
          style: TextStyle(
            color: AppColors.primary,
            fontWeight: FontWeight.w600,
            fontSize: 13,
          ),
        ),
      ),
    ),
  );

  Widget snoozeBtnLight(String label) => GestureDetector(
    onTap: () => controller.onSnooze(label),
    child: Container(
      decoration: BoxDecoration(
        color: Colors.grey.shade100,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Center(
        child: Text(
          label,
          style: const TextStyle(
            color: AppColors.textPrimary,
            fontWeight: FontWeight.w600,
            fontSize: 13,
          ),
        ),
      ),
    ),
  );
}

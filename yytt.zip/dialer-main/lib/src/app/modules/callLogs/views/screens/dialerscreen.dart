import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:itracker/src/app/widgets/custom_app_bar.dart';
import 'package:itracker/src/core/app_colors.dart';

import '../../../../../core/app_style.dart';
import '../../controller/dial_pad_controller.dart';

class DialPad extends StatelessWidget {
  DialPad({super.key});

  final DialPadController c = Get.put(DialPadController());

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: AppColors.background,
    appBar: const CustomAppBar(
       
    ),

    body: Column(
      children: [
        // 🔍 Suggested Contacts
        Expanded(
          child: Obx(() {
            final list = c.filteredContacts;
            if (list.isEmpty) return const SizedBox();

            return AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: SingleChildScrollView(
                child: Column(
                  children: list
                      .map(
                        (e) => ListTile(
                          title: Text(e["name"]!),
                          subtitle: Text(e["number"]!),
                          onTap: () {
                            c.typedNumber.value = e["number"]!;
                          },
                        ),
                      )
                      .toList(),
                ),
              ),
            );
          }),
        ),
        // const Divider(),
        Container(
          decoration: AppStyle.decoration.copyWith( ),
          child: Column(
            children: [
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: Center(
                      child: Obx(
                        () => TweenAnimationBuilder(
                          key: ValueKey(c.typedNumber.value),
                          duration: const Duration(milliseconds: 250),
                          tween: Tween<double>(begin: 0.8, end: 1.0),
                          builder: (context, scale, child) => Opacity(
                            opacity: scale,
                            child: Transform.scale(
                              scale: scale,
                              child: Text(
                                c.typedNumber.value.isEmpty
                                    ? ""
                                    : c.typedNumber.value,
                                style: Theme.of(context)
                                    .textTheme
                                    .headlineMedium
                                    ?.copyWith(
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black,
                                    ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  // BACKSPACE
                  // IconButton(
                  //   icon: const HugeIcon(
                  //     icon: HugeIcons.strokeRoundedCancelSquare,
                  //     size: AppStyle.iconSizelarge,
                  //     color: AppColors.danger,
                  //     strokeWidth: 1.5,
                  //   ),
                  //   onPressed: () => c.removeDigit(),
                  // ),
                ],
              ),
              const SizedBox(height: 10),

              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: GridView.count(
                  crossAxisCount: 3,
                  shrinkWrap: true,
                  childAspectRatio: 1.7,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  children: [
                    buildDialButton("1"),
                    buildDialButton("2"),
                    buildDialButton("3"),
                    buildDialButton("4"),
                    buildDialButton("5"),
                    buildDialButton("6"),
                    buildDialButton("7"),
                    buildDialButton("8"),
                    buildDialButton("9"),
                    buildDialButton("*"),
                    buildDialButton("0"),
                    buildDialButton("#"),
                  ],
                ),
              ),
   const SizedBox(height: 10),
              Padding(
                padding: const EdgeInsets.only(
                  bottom: 16,
                  right: 10,
                  left: 10,
                  top: 10,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    IconButton(
                      icon: const HugeIcon(
                        icon: HugeIcons.strokeRoundedEraser01,
                        size: AppStyle.iconSizelarge + 10,
                        color: AppColors.danger,
                        strokeWidth: 1.5,
                      ),
                      onPressed: () => c.removeDigit(),
                    ),

                    // CALL BUTTON
                    GestureDetector(
                      onTap: () => c.makeCall(),
                      child: Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: AppColors.primary,
                          boxShadow: const [
                            BoxShadow(
                              color: Color.fromRGBO(204, 219, 232, 1),
                              blurRadius: 6,
                              spreadRadius: 0,
                              offset: Offset(3, 3),
                            ),
                            BoxShadow(
                              color: Color.fromRGBO(255, 255, 255, 0.5),
                              blurRadius: 6,
                              spreadRadius: 1,
                              offset: Offset(-3, -3),
                            ),
                            BoxShadow(
                              color: Color.fromRGBO(0, 0, 0, 1.0),
                              blurRadius: 0,
                              spreadRadius: 0,
                              offset: Offset(0, 0),
                            ),
                          ],
                        ),
                        child: const Icon(
                          Icons.call,
                          color: Colors.white,
                          size: 36,
                        ),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(
                        Icons.no_accounts,
                        color: Colors.transparent,
                      ),
                      onPressed: () {
                        // c.removeDigit()
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    ),
  );

  // Dial Button
  Widget buildDialButton(String number) => GestureDetector(
    onTapDown: (_) => c.isPressed.value = number, // start animation
    onTapUp: (_) {
      Future.delayed(const Duration(milliseconds: 120), () {
        c.isPressed.value = ""; // reset animation
      });
      c.addDigit(number);
    },
    onTapCancel: () => c.isPressed.value = "",
    child: Obx(() {
      bool pressed = c.isPressed.value == number;

      return AnimatedContainer(
        duration: const Duration(milliseconds: 120),
        curve: Curves.easeOut,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: pressed ? AppColors.primary : Colors.white,
          boxShadow: [
            const BoxShadow(
              color: Color.fromRGBO(204, 219, 232, 1),
              blurRadius: 6,
              spreadRadius: 0,
              offset: Offset(3, 3),
            ),
            const BoxShadow(
              color: Color.fromRGBO(255, 255, 255, 0.5),
              blurRadius: 6,
              spreadRadius: 1,
              offset: Offset(-3, -3),
            ),
            const BoxShadow(
              color: Color.fromRGBO(0, 0, 0, 1.0),
              blurRadius: 0,
              spreadRadius: 0,
              offset: Offset(0, 0),
            ),
          ],
        ),
        child: AnimatedScale(
          scale: pressed ? 0.90 : 1.0,
          duration: const Duration(milliseconds: 120),
          child: Center(
            child: Text(
              number,
              style: TextStyle(
                fontSize: 28,
                color: !pressed ? AppColors.primary : Colors.white,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ),
      );
    }),
  );
}

import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../app.dart';
import '../model/model.dart';
import '../repository/repository.dart';
import '../views/widgets/add_follow_up_bottom_sheet.dart';

class FollowUpAddController extends GetxController {
  final FollowUpRepository _repository = FollowUpRepository();

  var selectedTab = 'Reminder'.obs;
  var selectedWhenOption = ''.obs;
  var selectedDateOption = ''.obs;
  var selectedTimeOption = ''.obs;
  var selectedCustomDate = ''.obs;
  var selectedCustomTime = ''.obs;
  var noteDescription = ''.obs;

  // Form observables
  final Rx<DateTime> _selectedDate = DateTime.now().obs;
  final Rx<TimeOfDay> _selectedTime = TimeOfDay.now().obs;
  final RxString _reason = ''.obs;
  final RxString _notes = ''.obs;
  final RxBool _isLoading = false.obs;
  final RxMap<String, String?> _errors = <String, String>{}.obs;

  // Getters
  DateTime get selectedDate => _selectedDate.value;
  TimeOfDay get selectedTime => _selectedTime.value;
  String get reason => _reason.value;
  String get notes => _notes.value;
  bool get isLoading => _isLoading.value;
  Map<String, String?> get errors => _errors;

  // Computed getter for form validity
  bool get isFormValid =>
      reason.isNotEmpty &&
      reason.length >= 2 &&
      reason.length <= 100 &&
      errors.isEmpty;

  // Date selection
  Future<void> selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime.now(),
      lastDate: DateTime(2100),
    );

    if (picked != null && picked != selectedDate) {
      _selectedDate.value = picked;
      _validateForm();
    }
  }

  // Time selection
  Future<void> selectTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: selectedTime,
    );

    if (picked != null && picked != selectedTime) {
      _selectedTime.value = picked;
      _validateForm();
    }
  }

  // Reason update
  void updateReason(String value) {
    _reason.value = value;
    _validateForm();
  }

  // Notes update
  void updateNotes(String value) {
    _notes.value = value;
    _validateForm();
  }

  // Form validation
  void _validateForm() {
    final followUp = FollowUp(
      date: selectedDate,
      time: selectedTime,
      reason: reason,
      notes: notes.isEmpty ? null : notes,
    );

    final validationErrors = _repository.validateFollowUp(followUp);
    _errors.assignAll(validationErrors);
  }

  // Form submission
  Future<void> submitFollowUp() async {
    if (!isFormValid) {
      _showToast('form_invalid'.tr);
      return;
    }

    try {
      _isLoading.value = true;

      final followUp = FollowUp(
        date: selectedDate,
        time: selectedTime,
        reason: reason.trim(),
        notes: notes.trim().isEmpty ? null : notes.trim(),
      );

      final response = await _repository.addFollowUp(followUp);

      if (response.status) {
        _showToast('add_success'.tr);
        Get.back(result: response.data); // Return created follow-up
      } else {
        _showToast(
          response.message,
        ); // Use the actual error message from response
      }
    } catch (e) {
      _showToast('add_error'.tr);
    } finally {
      _isLoading.value = false;
    }
  }

  // Reset form
  void resetForm() {
    _selectedDate.value = DateTime.now();
    _selectedTime.value = TimeOfDay.now();
    _reason.value = '';
    _notes.value = '';
    _errors.clear();
  }

  // Close bottom sheet
  void closeBottomSheet() {
    navigatorKey.currentState!.pop();
  }

  void _showToast(String message) {
    // Fluttertoast.showToast(
    //   msg: message,
    //   toastLength: Toast.LENGTH_SHORT,
    //   gravity: ToastGravity.BOTTOM,
    //   backgroundColor: Theme.of(context).colorScheme.onBackground.withOpacity(0.8),
    //   textColor: Theme.of(context).colorScheme.background,
    // );
  }

  late Map<String, dynamic> selectedCall;

  void setCall(Map<String, dynamic> call) {
    selectedCall = call;
  }

  void submitReminder() {
    final remarks = noteDescription.value.trim(); // bottom sheet input
    final call = selectedCall; // now we have the selected call

    // Delay logic
    Duration delay = Duration.zero;
    if (selectedWhenOption.value == "2 sec")
      delay = const Duration(seconds: 2);
    else if (selectedWhenOption.value == "15 min")
      delay = const Duration(minutes: 15);
    else if (selectedWhenOption.value == "30 min")
      delay = const Duration(minutes: 30);
    else if (selectedWhenOption.value == "1 hour")
      delay = const Duration(hours: 1);
    else if (selectedWhenOption.value == "2 hours")
      delay = const Duration(hours: 2);

    DateTime scheduledTime = DateTime.now().add(delay);

    // Combine remarks + user info
    final String fullRemarks =
        "${remarks.isNotEmpty ? '$remarks\n' : ''}${call['name']} • ${call['number']}";

    InAppReminderDialog.schedule(
      navigatorKey.currentContext!,
      scheduledTime,
      remarks,
      selectedCall, // pass the selected call here
    );

    Navigator.pop(navigatorKey.currentContext!);
  }

  @override
  void onClose() {
    _reason.close();
    _notes.close();
    super.onClose();
  }
}

 
import 'package:flutter/material.dart'; 
import 'package:get/get.dart';

import '../../../../../core/models/call_log_entry.dart';
 
import '../model/client_model.dart';
import '../repository/client_repository.dart';

class CallLogsController extends GetxController {
  RxString isExpended = "".obs;
  final ClientRepository repository = Get.find();
  var selectedFilter = CallType.all.obs;
  final RxList<AgentModel> availableAgents = <AgentModel>[].obs;
  final selectedAgent = Rxn<AgentModel>();
  final reasonTextController = TextEditingController();
  final selectedcallStatus = ''.obs;
  final selectedleadStatus = ''.obs;
  void changeFilter(CallType filter) {
    selectedFilter.value = filter;
  }

 @override
  void onInit() {
    super.onInit();
 
    loadAvailableAgents();
    update();
  }
  Future<void> loadAvailableAgents() async {
    try {
      final agents = await repository.getAvailableAgents();
      availableAgents.assignAll(agents);
    } catch (e) {
      showErrorToast('Failed to load agents');
    }
  }


    void showErrorToast(String message) {
   
  }

  // Example mock data
  final todayCalls = [
    {
      "name": "Jane Cooper",
      "number": "+1 (555) 123-4567",
      "type": CallType.incoming,
      "duration": "02:15",
      "time": "10:45 AM",
    },
    {
      "name": "Floyd Miles",
      "number": "+1 (555) 987-6543",
      "type": CallType.outgoing,
      "duration": "05:30",
      "time": "09:12 AM",
    },
    {
      "name": "Ronald Richards",
      "number": "+1 (555) 246-8135",
      "type": CallType.missed,
      "duration": "",
      "time": "08:30 AM",
    },
    {
      "name": "Jane Cooper",
      "number": "+1 (555) 123-4567",
      "type": CallType.incoming,
      "duration": "02:15",
      "time": "10:45 AM",
    },
    {
      "name": "Floyd Miles",
      "number": "+1 (555) 987-6543",
      "type": CallType.outgoing,
      "duration": "05:30",
      "time": "09:12 AM",
    },
    {
      "name": "Ronald Richards",
      "number": "+1 (555) 246-8135",
      "type": CallType.missed,
      "duration": "",
      "time": "08:30 AM",
    },
    {
      "name": "Jane Cooper",
      "number": "+1 (555) 123-4567",
      "type": CallType.incoming,
      "duration": "02:15",
      "time": "10:45 AM",
    },
    {
      "name": "Floyd Miles",
      "number": "+1 (555) 987-6543",
      "type": CallType.outgoing,
      "duration": "05:30",
      "time": "09:12 AM",
    },
    {
      "name": "Ronald Richards",
      "number": "+1 (555) 246-8135",
      "type": CallType.missed,
      "duration": "",
      "time": "08:30 AM",
    },
  ];

  // final yesterdayCalls = [
  //   {
  //     "name": "Annette Black",
  //     "number": "+1 (555) 369-2580",
  //     "type": CallType.missed,
  //     "duration": "",
  //     "time": "5:21 PM",
  //   },
  //   {
  //     "name": "Savannah Nguyen",
  //     "number": "+1 (555) 159-7532",
  //     "type": CallType.outgoing,
  //     "duration": "12:45",
  //     "time": "2:03 PM",
  //   },
  //   {
  //     "name": "Annette Black",
  //     "number": "+1 (555) 369-2580",
  //     "type": CallType.missed,
  //     "duration": "",
  //     "time": "5:21 PM",
  //   },
  //   {
  //     "name": "Savannah Nguyen",
  //     "number": "+1 (555) 159-7532",
  //     "type": CallType.outgoing,
  //     "duration": "12:45",
  //     "time": "2:03 PM",
  //   },
  // ];

  List<Map<String, dynamic>> get filteredToday {
    if (selectedFilter.value == CallType.all) return todayCalls;
    return todayCalls.where((e) => e["type"] == selectedFilter.value).toList();
  }

  // List<Map<String, dynamic>> get filteredYesterday {
  //   if (selectedFilter.value == CallType.all) return yesterdayCalls;
  //   return yesterdayCalls
  //       .where((e) => e["type"] == selectedFilter.value)
  //       .toList();
  // }

  void onSnooze(String value) {
  }

  void onCustom() {
  }

  // Show/hide custom fields
  var showCustomFields = false.obs;

  // Store the selected date and time
  var customDateTime = Rxn<DateTime>();

  void toggleCustomFields() {
    showCustomFields.value = !showCustomFields.value;
  }
}

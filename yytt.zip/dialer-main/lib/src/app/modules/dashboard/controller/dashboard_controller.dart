// lib/modules/dashboard/controller/dashboard_controller.dart
import 'package:get/get.dart';

class DashboardController extends GetxController {
  // counts (animated)
  final outgoing = 124.obs;
  final incoming = 82.obs;
  final missed = 12.obs;
  final rejected = 5.obs;

  final totalCallDuration = 132.obs;

  final todayTotalCalls = 218.obs;
  final weekTotalCalls = 218.obs;

  // weekly data (0..1 relative heights)
  final weeklyData = <double>[23,50,33,10].obs;

  // percent change
  final percentChange = 5.2.obs;

 
}

import 'package:flutter/material.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'package:get/get.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:lottie/lottie.dart';
import 'package:syncfusion_flutter_gauges/gauges.dart';

import '../../../../../core/app_colors.dart';
import '../../../../../core/app_style.dart';
import '../../../../utils/routes/app_pages.dart';
import '../../../../widgets/widget_gap.dart';
import '../../controller/dashboard_controller.dart';
import '../widgets/pie_chart.dart';
import '../widgets/stat_card.dart';
import '../widgets/weekly_graph.dart';
import 'dart:math' as math;

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen>
    with SingleTickerProviderStateMixin {
  final DashboardController controller = Get.find();

  @override
  Widget build(BuildContext context) {
    final themeTitle = Theme.of(context).textTheme.titleLarge!;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          physics: const BouncingScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Hero banner + CTA
              Container(
                height: 150,
                padding: const EdgeInsets.all(10),
                decoration: AppStyle.decoration.copyWith(
                  color: AppColors.primary,
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 8),
                            child: Text(
                              "WelCome!",
                              style: themeTitle.copyWith(
                                color: AppColors.textLight,
                              ),
                            ),
                          ),
                          const SizedBox(height: 4),
                          Padding(
                            padding: const EdgeInsets.only(left: 8),
                            child: Text(
                              "Success is the sum of small efforts repeated day in and day out",
                              // textAlign: TextAlign.justify,
                              style: Theme.of(context).textTheme.bodyMedium!
                                  .copyWith(
                                    height: 1,
                                    color: AppColors.textLight,
                                  ),
                            ),
                          ),
                          const Spacer(),
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(
                                AppStyle.borderRadiusBox,
                              ),
                              color: const Color.fromARGB(47, 255, 255, 255),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  child: RichText(
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    text: TextSpan(
                                      children: [
                                        TextSpan(
                                          text: "Duration ",
                                          style: Theme.of(context)
                                              .textTheme
                                              .bodyMedium
                                              ?.copyWith(color: Colors.white),
                                        ),

                                        TextSpan(
                                          text: "16.9",
                                          style: Theme.of(context)
                                              .textTheme
                                              .titleLarge!
                                              .copyWith(
                                                color: Colors.white,
                                                fontWeight: FontWeight.w900,

                                                shadows: [
                                                  Shadow(
                                                    color: Colors.black
                                                        .withAlpha(100),
                                                    offset: const Offset(0, 2),
                                                    blurRadius: 4,
                                                  ),
                                                ],
                                              ),
                                        ),
                                        TextSpan(
                                          text: "hrs",
                                          style: Theme.of(context)
                                              .textTheme
                                              .bodySmall
                                              ?.copyWith(color: Colors.white),
                                        ),
                                        TextSpan(
                                          text: " - ",
                                          style: Theme.of(context)
                                              .textTheme
                                              .titleLarge!
                                              .copyWith(
                                                color: Colors.white,
                                                fontWeight: FontWeight.w900,

                                                // shadows: [
                                                //   Shadow(
                                                //     color: Colors.black
                                                //         .withOpacity(0.3),
                                                //     offset: const Offset(
                                                //       0,
                                                //       2,
                                                //     ),
                                                //     blurRadius: 4,
                                                //   ),
                                                // ],
                                              ),
                                        ),
                                        TextSpan(
                                          text: controller.todayTotalCalls.value
                                              .toString(),
                                          style: Theme.of(context)
                                              .textTheme
                                              .titleLarge!
                                              .copyWith(
                                                color: Colors.white,
                                                fontWeight: FontWeight.w900,

                                                shadows: [
                                                  Shadow(
                                                    color: Colors.black
                                                        .withAlpha(100),
                                                    offset: const Offset(0, 2),
                                                    blurRadius: 4,
                                                  ),
                                                ],
                                              ),
                                        ),
                                        TextSpan(
                                          text: "Calls",
                                          style: Theme.of(context)
                                              .textTheme
                                              .bodySmall
                                              ?.copyWith(color: Colors.white),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),

                            // Text(,style: bodyMedium.copyWith(
                            //   color: AppColors.textLight ,
                            // ),),
                          ),
                        ],
                      ),
                    ),

                    Column(
                      children: [
                        //  Text(
                        //   "performance",
                        //   style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        //     color: AppColors.textLight.withAlpha(220),
                        //   ),
                        // ),
                        Flexible(
                          child: SizedBox(
                            width: 130,
                            // height: 130,
                            child: SfRadialGauge(
                              axes: <RadialAxis>[
                                RadialAxis(
                                  minimum: 0,
                                  maximum: 100,
                                  showLabels: false,
                                  showTicks: false,
                                  pointers: <GaugePointer>[
                                    const RangePointer(
                                      value: 30,
                                      cornerStyle: CornerStyle.bothCurve,
                                      width: 0.2,
                                      color: AppColors.secondary,
                                      sizeUnit: GaugeSizeUnit.factor,
                                    ),
                                    // RangePointer(
                                    //   value: 50,
                                    //   cornerStyle: CornerStyle.bothCurve,
                                    //   width: 0.2,
                                    //   sizeUnit: GaugeSizeUnit.factor,
                                    // ),
                                  ],
                                  annotations: <GaugeAnnotation>[
                                    GaugeAnnotation(
                                      positionFactor: 0.1,
                                      angle: 90,
                                      widget: Padding(
                                        padding: const EdgeInsets.all(5),
                                        child: Lottie.network(
                                          'https://raw.githubusercontent.com/EIBSDeveloper/animation/refs/heads/main/girl-excitedly-working.json',
                                        ),
                                      ),
                                    ),
                                  ],
                                  axisLineStyle: const AxisLineStyle(
                                    thickness: 0.2,
                                    cornerStyle: CornerStyle.bothCurve,
                                    color: Color.fromARGB(255, 255, 255, 255),
                                    thicknessUnit: GaugeSizeUnit.factor,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),

                        RichText(
                          text: TextSpan(
                            children: [
                              TextSpan(
                                text: "20",
                                style: Theme.of(context).textTheme.titleLarge!
                                    .copyWith(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w900,

                                      shadows: [
                                        Shadow(
                                          color: Colors.black.withAlpha(100),
                                          offset: const Offset(0, 2),
                                          blurRadius: 4,
                                        ),
                                      ],
                                    ),
                              ),
                              TextSpan(
                                text: "/",
                                style: Theme.of(context).textTheme.titleLarge!
                                    .copyWith(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w900,

                                      shadows: [
                                        const Shadow(
                                          color: Color.fromARGB(
                                            255,
                                            107,
                                            107,
                                            107,
                                          ),
                                          offset: Offset(0, 2),
                                          blurRadius: 4,
                                        ),
                                      ],
                                    ),
                              ),

                              TextSpan(
                                text: '100',
                                style: Theme.of(context).textTheme.titleLarge!
                                    .copyWith(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w600,
                                    ),
                              ),
                              TextSpan(
                                text: 'calls',
                                style: Theme.of(context).textTheme.bodySmall!
                                    .copyWith(
                                      color: Colors.white.withAlpha(220),
                                      fontWeight: FontWeight.w600,
                                    ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              const WidgetGap(),

              Row(
                children: [
                  Expanded(
                    child: StatCard.animated(
                      title: "Outgoing",
                      icon: Icons.call_made,
                      color: AppColors.primary,
                      countRx: controller.outgoing,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: StatCard.animated(
                      title: "Incoming",
                      icon: Icons.call_received,
                      color: AppColors.secondary,
                      countRx: controller.incoming,
                    ),
                  ),
                ],
              ),

              const WidgetGap(),
              Row(
                children: [
                  Expanded(
                    child: StatCard.animated(
                      title: "Missed",
                      icon: Icons.call_missed,
                      color: AppColors.tertiary,
                      countRx: controller.missed,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: StatCard.animated(
                      title: "Rejected",
                      icon: Icons.call_missed_outlined,
                      color: AppColors.danger,
                      countRx: controller.rejected,
                    ),
                  ),
                ],
              ),

              const WidgetGap(),

              // donut + legend
              Container(
                padding: const EdgeInsets.all(10),
                decoration: AppStyle.decoration,
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("Today's Reminder Summary", style: themeTitle),

                            Text(
                              "October 26",
                              style: Theme.of(context).textTheme.bodySmall!
                                  .copyWith(color: AppColors.textSecondary),
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        // Pie/donut
                        Expanded(
                          child: SizedBox(
                            width: 120,
                            height: 120,
                            child: Stack(
                              alignment: Alignment.center,
                              children: [
                                // ✅ Force the CustomPaint to fill full area
                                SizedBox.expand(
                                  child: Obx(() {
                                    final totals = [
                                      controller.outgoing.value.toDouble(),
                                      controller.incoming.value.toDouble(),
                                      // controller.missed.value.toDouble(),
                                      controller.rejected.value.toDouble(),
                                    ];
                                    return DonutPieChart(
                                      values: totals,
                                      colors: [
                                        AppColors.primary,
                                        AppColors.secondary,

                                        AppColors.danger,
                                      ],
                                    );
                                  }),
                                ),

                                // ✅ Optional soft inner circle (for text contrast)
                                Container(
                                  width: 65,
                                  height: 65,
                                  decoration: BoxDecoration(
                                    color: Colors.white.withOpacity(0.9),
                                    shape: BoxShape.circle,
                                  ),
                                ),

                                // ✅ Center total calls text
                                Obx(
                                  () => Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text(
                                        "${controller.todayTotalCalls.value}",
                                        style: themeTitle.copyWith(
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                      Text(
                                        "Total Calls",
                                        style: Theme.of(context)
                                            .textTheme
                                            .bodySmall!
                                            .copyWith(
                                              color: AppColors.textSecondary,
                                            ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),

                        // legend
                        Expanded(
                          child: Container(
                            alignment: Alignment.centerRight,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,

                              children: [
                                LegendItem(
                                  color: AppColors.primary,
                                  label: "Pending",
                                ),
                                const LegendItem(
                                  color: AppColors.secondary,
                                  label: "Completed",
                                ),
                                // LegendItem(
                                //   color: AppColors.tertiary,
                                //   label: "Missed",
                                // ),
                                const LegendItem(
                                  color: AppColors.danger,
                                  label: "Over due",
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(width: 18),
                      ],
                    ),
                  ],
                ),
              ),

              const WidgetGap(),

              // weekly activity (graph)
              InkWell(
                onTap: () {
                  // FlutterOverlayWindow.showOverlay(
                  //   alignment: OverlayAlignment.center,
                  //   overlayTitle: "Call Ended",

                  //   enableDrag: true,
                  // );

                  // _sendAndUpdate();
                },
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: AppStyle.decoration,
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "Weekly Activity",
                                style: Theme.of(context).textTheme.titleLarge
                                    ?.copyWith(fontWeight: FontWeight.bold),
                              ),
                              // SizedBox(height:2),
                              RichText(
                                text: TextSpan(
                                  children: [
                                    TextSpan(
                                      text: 'Total ',
                                      style: Theme.of(context)
                                          .textTheme
                                          .titleLarge!
                                          .copyWith(
                                            color: Colors.black.withAlpha(220),
                                            fontWeight: FontWeight.w600,
                                          ),
                                    ),
                                    TextSpan(
                                      text: "869",
                                      style: Theme.of(context)
                                          .textTheme
                                          .titleLarge!
                                          .copyWith(
                                            color: AppColors.primary,
                                            fontWeight: FontWeight.w900,

                                            shadows: [
                                              Shadow(
                                                color: Colors.grey.withOpacity(
                                                  0.3,
                                                ),
                                                offset: const Offset(0, 2),
                                                blurRadius: 4,
                                              ),
                                            ],
                                          ),
                                    ),

                                    TextSpan(
                                      text: ' calls',
                                      style: Theme.of(context)
                                          .textTheme
                                          .bodySmall!
                                          .copyWith(
                                            color: Colors.black.withAlpha(220),
                                            fontWeight: FontWeight.w600,
                                          ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 6,
                            ),
                            decoration: BoxDecoration(
                              color: AppColors.danger,
                              borderRadius: BorderRadius.circular(
                                AppStyle.borderRadiusClip,
                              ),
                              boxShadow: [
                                const BoxShadow(
                                  color: Color.fromRGBO(0, 0, 0, 0.15),
                                  blurRadius: 3,
                                  spreadRadius: 0,
                                  offset: Offset(0, 3),
                                ),
                              ],
                            ),
                            child: Row(
                              children: [
                                const HugeIcon(
                                  icon: HugeIcons.strokeRoundedTradeDown,
                                  color: Colors.white,
                                  size: AppStyle.iconSize2,
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  "-5.2%",
                                  style: Theme.of(context).textTheme.bodySmall
                                      ?.copyWith(
                                        color: AppColors.card,
                                        fontWeight: FontWeight.bold,
                                      ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 160, child: SmoothCallsGraph()),
                    ],
                  ),
                ),
              ),
              const WidgetGap(),

              // Container(
              //   child: Column(
              //     crossAxisAlignment: CrossAxisAlignment.start,
              //     children: [
              //       Text("Recent Activity", style: themeTitle),
              //       const SizedBox(height: 12),
              //       Obx(
              //         () => Column(
              //           children: controller.recent.map((r) {
              //             return RecentActivityItem(
              //               name: r['name'] ?? '',
              //               subtitle: r['type'] ?? '',
              //               time: r['time'] ?? '',
              //               icon: r['icon'] ?? 'call_made',
              //               colorName: r['color'] ?? 'primary',
              //             );
              //           }).toList(),
              //         ),
              //       ),
              //     ],
              //   ),
              // ),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }
}

class MainAppBar extends StatelessWidget {
  const MainAppBar({super.key, required this.title});

  final Text title;

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.only(right: 16, left: 16),
    margin: const EdgeInsets.only(bottom: AppStyle.widgetsGap),
    height: 50,
    color: AppColors.background,
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        InkWell(
          onTap: () {
            Navigator.pushNamed(context, RouteNames.profile);
          },
          child: Container(
            height: 40,
            width: 40,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(999),
              color: AppColors.accent,
              border: Border.all(color: AppColors.primary),
              image: const DecorationImage(
                fit: BoxFit.cover,
                image: NetworkImage(
                  "https://lh3.googleusercontent.com/aida-public/AB6AXuDLDFxgqsAXjLtu5DKx_HR7Ts8sJK5DVAthanMpcLQzhRECNKHW3IKu-F3s4xHuR8yDgUNYZkelLHvFubWW9PKDhwXsS9VlwBU-EuyZxv3hRG8SGArDtQUbOcSUb5p7tuZUIofDIKGtsPcpWbd5I82N_YHUv7kuIIWF4CM9PL1XBWshr2WHLqlh9_bcgr9xSm9aAe-gsrcNBU_E75jqHKCNfq8gny91RY1ilCexW20qquoqN_cfwDoyxCqvORVXRzKxw6PEa95nEhgI",
                ),
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        title,
        // Ripples(onPressed: () {}),
        const Spacer(),
        const NotificationIconWithRipples(),
      ],
    ),
  );
}

class LegendItem extends StatelessWidget {
  final Color color;
  final String label;
  const LegendItem({super.key, required this.color, required this.label});
  @override
  Widget build(BuildContext context) {
    final bodyMedium = Theme.of(context).textTheme.bodyMedium!;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 10),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 10,
            height: 10,
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(4),
            ),
          ),
          const SizedBox(width: 10),
          Text(label, style: bodyMedium.copyWith(color: AppColors.textPrimary)),
        ],
      ),
    );
  }
}

class NotificationIconWithRipples extends StatefulWidget {
  const NotificationIconWithRipples({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _NotificationIcon createState() => _NotificationIcon();
}

class _NotificationIcon extends State<NotificationIconWithRipples>
    with TickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Stack(
    clipBehavior: Clip.none,
    children: [
      // Ripple animation positioned at top-right
      Positioned(
        top: 8,
        right: 8,
        child: Icon(Icons.circle, size: 10, color: AppColors.primary),
      ),

      // Notification icon
      IconButton(
        onPressed: () {
          Navigator.pushNamed(context, RouteNames.notification);
        },
        icon: const HugeIcon(
          icon: HugeIcons.strokeRoundedNotification01,
          // color: widget.backgroundColor,
          size: AppStyle.iconSizelarge,
        ),
        color: AppColors.textDark,
      ),
    ],
  );
}

class CirclePainter extends CustomPainter {
  final Animation<double> _animation;
  final Color color;

  CirclePainter(this._animation, {required this.color})
    : super(repaint: _animation);

  void circle(Canvas canvas, Rect rect, double value) {
    // Fade using alpha
    int alpha = ((1.0 - (value / 4.0)).clamp(0.0, 1.0) * 150).toInt();
    final Color circleColor = color.withAlpha(
      alpha,
    ); // use withAlpha instead of withOpacity

    final double size = rect.width / 2;
    final double area = size * size;
    final double radius = math.sqrt(area * value / 4);

    final Paint paint = Paint()..color = circleColor;
    canvas.drawCircle(rect.center, radius, paint);
  }

  @override
  void paint(Canvas canvas, Size size) {
    final Rect rect = Rect.fromLTRB(0, 0, size.width, size.height);
    for (int wave = 3; wave >= 0; wave--) {
      circle(canvas, rect, wave + _animation.value);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

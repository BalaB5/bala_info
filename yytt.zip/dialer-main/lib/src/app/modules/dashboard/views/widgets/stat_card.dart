import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../core/app_colors.dart';
import '../../../../../core/app_style.dart';

class StatCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final Color color;
  final RxInt? countRx;

  const StatCard({
    super.key,
    required this.title,
    required this.icon,
    required this.color,
    this.countRx,
  });

  /// helper constructor for animated number
  factory StatCard.animated({
    required String title,
    required IconData icon,
    required Color color,
    required RxInt countRx,
  }) => StatCard(title: title, icon: icon, color: color, countRx: countRx);

  @override
  Widget build(BuildContext context) {
    final titleStyle = Theme.of(context).textTheme.titleLarge!;
    final bodyMedium = Theme.of(context).textTheme.bodyMedium!;
    return Container(
      height: 80,
      decoration: AppStyle.decoration,
      padding: const EdgeInsets.all(10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            height: 44,
            width: 44,
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(AppStyle.borderRadiusBox),
              boxShadow: [
                const BoxShadow(
                  color: Color.fromRGBO(0, 0, 0, 0.15),
                  blurRadius: 3,
                  spreadRadius: 0,
                  offset: Offset(0, 3),
                ),
              ],
            ),
            child: Icon(icon, color: Colors.white),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  title,
                  style: bodyMedium.copyWith(color: AppColors.textPrimary),
                ),
                // const SizedBox(height: 3),
                if (countRx != null)
                  Obx(() {
                    final target = countRx!.value.toDouble();
                    return TweenAnimationBuilder<double>(
                      tween: Tween(begin: 0, end: target),
                      duration: const Duration(milliseconds: 900),
                      builder: (context, value, _) => Text(
                        value.toInt().toString(),
                        style: titleStyle.copyWith(
                          fontSize: 24,
                          color: AppColors.textPrimary,
                        ),
                      ),
                    );
                  })
                else
                  Text("0", style: titleStyle.copyWith(fontSize: 24)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class HomeWidgetStatCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final Color color;
  final RxInt? countRx;

  const HomeWidgetStatCard({
    super.key,
    required this.title,
    required this.icon,
    required this.color,
    this.countRx,
  });

  factory HomeWidgetStatCard.animated({
    required String title,
    required IconData icon,
    required Color color,
    required RxInt countRx,
  }) => HomeWidgetStatCard(
    title: title,
    icon: icon,
    color: color,
    countRx: countRx,
  );

  @override
  Widget build(BuildContext context) {
    final titleStyle = Theme.of(context).textTheme.bodyMedium!;
    final bodyMedium = Theme.of(context).textTheme.bodySmall!;

    return Container(
      height: 70,
      margin: const EdgeInsets.all(10),
      decoration: AppStyle.decoration,
      padding: const EdgeInsets.all(5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // ICON BOX
          Container(
            height: 30,
            width: 25,
            decoration: BoxDecoration(
              color: color.withAlpha(30),
              borderRadius: BorderRadius.circular(AppStyle.borderRadiusBox),
            ),
            child: Icon(icon, color: color),
          ),

          const SizedBox(width: 12),

          // TEXT CONTENT – FIXED Expanded with constraints
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min, // VERY IMPORTANT FIX
              children: [
                Text(
                  title,
                  style: bodyMedium.copyWith(color: AppColors.textSecondary),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),

                const SizedBox(height: 3),

                if (countRx != null)
                  Obx(() {
                    final target = countRx!.value.toDouble();
                    return TweenAnimationBuilder<double>(
                      tween: Tween(begin: 0, end: target),
                      duration: const Duration(milliseconds: 900),
                      builder: (context, value, _) => Text(
                        value.toInt().toString(),
                        style: titleStyle.copyWith(
                          fontSize: 24,
                          color: AppColors.textPrimary,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    );
                  })
                else
                  Text(
                    "0",
                    style: titleStyle.copyWith(fontSize: 24),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

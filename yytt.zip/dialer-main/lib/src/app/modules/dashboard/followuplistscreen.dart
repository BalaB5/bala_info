import 'package:flutter/material.dart';
import 'package:quickalert/quickalert.dart';

import '../../../../app.dart';
import '../../../../core/models/call_log_entry.dart';
import '../../../core/app_colors.dart';
import '../../../core/app_style.dart';
import '../payment_tracker/view/screens/customerscreen.dart';

class FollowUpsScreen extends StatelessWidget {
  const FollowUpsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    bool isDark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      backgroundColor: AppColors.background,

      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const AppSearchBar(),
          const SizedBox(height: 8),
          _filterChips(),

          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Section: Today
                  Text(
                    'Today, Oct 26',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: isDark
                          ? AppColors.textSecondary
                          : AppColors.textSecondary,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Column(
                    children: [
                      FollowUpCard(
                        name: 'Maria Garcia',
                        task: 'Send initial quote for project alpha.',
                        time: '4:00 PM',
                        date: 'Oct 26',
                        isOverdue: false,
                      ),
                      SizedBox(height: 8),
                      FollowUpCard(
                        name: 'Alex Johnson',
                        task:
                            'Follow up on proposal. Client mentioned budget concerns.',
                        time: '',
                        date: 'Oct 24',
                        isOverdue: true,
                      ),
                    ],
                  ),

                  const SizedBox(height: 16),

                  // Section: Tomorrow
                  Text(
                    'Tomorrow, Oct 27',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: isDark
                          ? AppColors.textSecondary
                          : AppColors.textSecondary,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Column(
                    children: [
                      FollowUpCard(
                        name: 'David Chen',
                        task: 'Schedule discovery meeting for Q4 initiatives.',
                        time: '11:30 AM',
                        date: 'Oct 27',
                        isOverdue: false,
                      ),
                    ],
                  ),

                  const SizedBox(height: 32),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _filterChips() => SizedBox(
    height: 43,
    child: ListView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.only(bottom: 8, right: 10, left: 10),
      children: [
        _chip("All", CallType.all, AppColors.primary, 30),
        _chip("Today", CallType.all, AppColors.primary, 20),
        _chip("Yeasterday", CallType.all, AppColors.primary, 20),
        _chip("Pending", CallType.all, AppColors.primary, 20),
        _chip("Completed", CallType.all, AppColors.secondary, 10),
      ],
    ),
  );

  Widget _chip(
    String label,
    CallType type,
    Color color,
    int count, [
    IconData? icon,
  ]) {
    final theme = Theme.of(navigatorKey.currentContext!).textTheme;
    final bool active = ("pending" == label);
    return GestureDetector(
      // onTap: () => controller.changeFilter(type),
      child: Container(
        margin: const EdgeInsets.only(right: 10),
        padding: const EdgeInsets.symmetric(horizontal: 12),
        decoration: AppStyle.decoration.copyWith(
          color: active ? AppColors.primary : AppColors.card,
          borderRadius: BorderRadius.circular(AppStyle.borderRadiusClip),
        ),
        child: Row(
          children: [
            if (icon != null)
              Icon(icon, color: active ? Colors.white : color, size: 18),
            if (icon != null) const SizedBox(width: 6),
            Text(
              label,
              style: theme.bodyMedium?.copyWith(
                color: active ? Colors.white : AppColors.textPrimary,
              ),
            ),
            const SizedBox(width: 2),
            Text(
              "($count)",
              style: theme.bodyMedium?.copyWith(
                color: active ? Colors.white : AppColors.textPrimary,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Individual Follow-Up Card
class FollowUpCard extends StatelessWidget {
  final String name;
  final String task;
  final String time;
  final String date;
  final bool isOverdue;

  const FollowUpCard({
    super.key,
    required this.name,
    required this.task,
    required this.time,
    required this.date,
    this.isOverdue = false,
  });

  @override
  Widget build(BuildContext context) {
    bool isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      decoration: AppStyle.decoration,
      padding: const EdgeInsets.all(10),
      child: Column(
        children: [
          Row(
            children: [
              const SizedBox(width: 5),
              Container(
                width: 6,
                height: 60,
                decoration: BoxDecoration(
                  color: Colors.orange,
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              const SizedBox(width: 9),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: isDark
                            ? AppColors.textLight
                            : AppColors.textPrimary,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    // const SizedBox(height: 4),
                    Text(
                      task,
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: isDark
                            ? AppColors.textSecondary
                            : AppColors.textSecondary,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        if (time.isNotEmpty) ...[
                          Row(
                            children: [
                              Icon(
                                Icons.schedule,
                                size: AppStyle.iconSize2,
                                color: AppColors.primary,
                              ),
                              const SizedBox(width: 4),
                              Text(
                                time,
                                style: Theme.of(context).textTheme.bodySmall
                                    ?.copyWith(color: AppColors.textPrimary),
                              ),
                            ],
                          ),
                          const SizedBox(width: 16),
                        ],
                        Row(
                          children: [
                            Icon(
                              Icons.calendar_today,
                              size: AppStyle.iconSize2,
                              color: AppColors.primary,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              date,
                              style: Theme.of(context).textTheme.bodySmall
                                  ?.copyWith(color: AppColors.textPrimary),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Container(
                height: 40,
                width: 40,
                decoration: BoxDecoration(
                  color: AppColors.primary.withAlpha(20),
                  shape: BoxShape.circle,
                  border: Border.all(color: AppColors.primary.withAlpha(100)),
                ),
                child: Icon(
                  Icons.call,
                  color: AppColors.primary,
                  size: AppStyle.iconSize,
                ),
              ),
            ],
          ),
          // Mark as Done button
          Container(
            width: double.infinity,
            decoration: const BoxDecoration(
              borderRadius: BorderRadius.vertical(
                bottom: Radius.circular(AppStyle.borderRadiusBox),
              ),
            ),
            child: ElevatedButton(
              onPressed: () {
                QuickAlert.show(
                  context: context,
                  type: QuickAlertType.confirm,
                  text: 'The reminder is completed.',
                  confirmBtnText: 'Yes',
                  cancelBtnText: 'No',
                  confirmBtnColor: AppColors.primary,
                  headerBackgroundColor: AppColors.primary,
                  borderRadius: 10.0,
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary10(0.1),
                elevation: 0,
                foregroundColor: AppColors.primary,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(AppStyle.borderRadiusBox),
                ),
              ),
              child: const Text('Mark as Done'),
            ),
          ),
        ],
      ),
    );
  }
}

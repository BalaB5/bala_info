import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../core/app_colors.dart';
import '../../../../../core/app_style.dart';
import '../../../../widgets/custom_app_bar.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  @override
  Widget build(BuildContext context) {
    bool isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: isDark ? AppColors.backgroundDark : AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            // App Bar
            CustomAppBar(
              title: Text(
                'Profile',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.titleLarge,
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Column(
                  children: [
                    // User Info Card
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: AppStyle.decoration,
                      child: Row(
                        children: [
                          // Avatar
                          Container(
                            height: 64,
                            width: 64,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(color: AppColors.primary),
                              image: const DecorationImage(
                                image: NetworkImage(
                                  'https://lh3.googleusercontent.com/aida-public/AB6AXuDLDFxgqsAXjLtu5DKx_HR7Ts8sJK5DVAthanMpcLQzhRECNKHW3IKu-F3s4xHuR8yDgUNYZkelLHvFubWW9PKDhwXsS9VlwBU-EuyZxv3hRG8SGArDtQUbOcSUb5p7tuZUIofDIKGtsPcpWbd5I82N_YHUv7kuIIWF4CM9PL1XBWshr2WHLqlh9_bcgr9xSm9aAe-gsrcNBU_E75jqHKCNfq8gny91RY1ilCexW20qquoqN_cfwDoyxCqvORVXRzKxw6PEa95nEhgI',
                                ),
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          // Name and Email
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Bala',
                                style: Theme.of(context).textTheme.bodyLarge,
                              ),

                              Text(
                                'bala@example.com',
                                style: Theme.of(context).textTheme.bodyMedium,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 8),

                    // Account & Preferences Section
                    const SectionTitle(title: 'Account & Preferences'),
                    Container(
                      decoration: AppStyle.decoration,
                      child: Column(
                        children: [
                          SettingCard(
                            icon: Icons.tune,
                            title: 'App Settings',
                            isDark: isDark,
                          ),
                          Divider(
                            height: 1,
                            color: isDark ? Colors.grey[700] : AppColors.border,
                          ),
                          SettingCard(
                            icon: Icons.notifications,
                            title: 'Notification Settings',
                            isDark: isDark,
                          ),

                          Divider(
                            height: 1,
                            color: isDark ? Colors.grey[700] : AppColors.border,
                          ),
                          SettingCard(
                            icon: Icons.dark_mode,
                            title: 'App Theme',
                            isDark: isDark,
                            onTap: () {
                              showModalBottomSheet(
                                context: context,
                                shape: const RoundedRectangleBorder(
                                  borderRadius: BorderRadius.vertical(
                                    top: Radius.circular(16),
                                  ),
                                ),
                                builder: (context) {
                                  // List of 5 colors
                                  final List<Color> colors = [
                                    const Color.fromRGBO(0, 128, 255, 1),
                                    const Color.fromRGBO(125, 182, 212, 1),
                                    const Color.fromRGBO(6, 63, 92, 1),
                                    const Color.fromRGBO(19, 82, 161, 1),
                                    const Color.fromRGBO(12, 92, 117, 1),
                                    const Color.fromRGBO(254, 81, 46, 1),
                                    const Color.fromRGBO(132, 116, 161, 1),
                                    const Color.fromRGBO(78, 126, 149, 1),
                                    const Color.fromRGBO(25, 30, 62, 1),
                                    const Color.fromRGBO(0, 82, 106, 1),
                                    const Color.fromRGBO(99, 102, 241, 1),
                                  ];

                                  return Padding(
                                    padding: const EdgeInsets.all(16.0),
                                    child: Wrap(
                                      spacing: 16, // horizontal spacing
                                      runSpacing: 16, // vertical spacing
                                      children: colors.map((color) => GestureDetector(
                                          onTap: () {
                                            AppColors.primary = color;
                                            Navigator.pop(
                                              context,
                                              color,
                                            ); // return selected color
                                          },
                                          child: CircleAvatar(
                                            backgroundColor: color,
                                            radius: 24,
                                          ),
                                        )).toList(),
                                    ),
                                  );
                                },
                              ).then((vlue) {
                                setState(() {});
                              });
                            },
                            trailing: SizedBox(
                              // height: 10,
                              child: Switch(
                                value: Get.isDarkMode,
                                onChanged: (val) => Get.changeThemeMode(
                                  val ? ThemeMode.dark : ThemeMode.light,
                                ),
                                activeThumbColor: AppColors.primary,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 8),

                    // Support & Information Section
                    const SectionTitle(title: 'Support & Information'),
                    Container(
                      decoration: AppStyle.decoration,
                      child: Column(
                        children: [
                          SettingCard(
                            icon: Icons.help_outline,
                            title: 'Help & Support',
                            isDark: isDark,
                          ),
                          Divider(
                            height: 1,
                            color: isDark ? Colors.grey[700] : AppColors.border,
                          ),
                          SettingCard(
                            icon: Icons.privacy_tip,
                            title: 'Privacy Policy',
                            isDark: isDark,
                          ),
                          Divider(
                            height: 1,
                            color: isDark ? Colors.grey[700] : AppColors.border,
                          ),
                          SettingCard(
                            icon: Icons.info,
                            title: 'About',
                            isDark: isDark,
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 24),

                    // Logout Button
                    // ElevatedButton.icon(
                    //   onPressed: () {},
                    //   style: ElevatedButton.styleFrom(
                    //     backgroundColor: isDark
                    //         ? AppColors.textSecondary
                    //         : AppColors.card,
                    //     foregroundColor: AppColors.danger,
                    //     minimumSize: const Size.fromHeight(50),
                    //     shape: RoundedRectangleBorder(
                    //       borderRadius: BorderRadius.circular(
                    //         AppStyle.borderRadiusBox,
                    //       ),
                    //     ),
                    //     elevation: 1,
                    //   ),
                    //   icon: const Icon(Icons.logout),
                    //   label: Text(
                    //     'Logout',
                    //     style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    //       color: AppColors.danger,
                    //     ),
                    //   ),
                    // ),
                    const SizedBox(height: 32),

                    // App Version
                    Text(
                      'Version 1.2.0',
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Section Title Widget
class SectionTitle extends StatelessWidget {
  final String title;
  const SectionTitle({super.key, required this.title});

  @override
  Widget build(BuildContext context) => Container(
      alignment: Alignment.centerLeft,
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
      child: Text(
        title.toUpperCase(),
        style: Theme.of(context).textTheme.bodyMedium,
      ),
    );
}

// Setting Card Widget
class SettingCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final bool isDark;
  final Widget? trailing;
  final void Function()? onTap;
  const SettingCard({
    super.key,
    required this.icon,
    required this.title,
    required this.isDark,
    this.trailing,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) => InkWell(
      onTap: onTap,
      child: Container(
        height: 56,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: AppColors.primary.withOpacity(0.1),
                borderRadius: BorderRadius.circular(AppStyle.borderRadiusBox),
              ),
              child: Icon(
                icon,
                color: AppColors.primary,
                size: AppStyle.iconSizelarge,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(title, style: Theme.of(context).textTheme.bodyMedium),
            ),
            if (trailing != null)
              trailing!
            else
              Icon(
                Icons.chevron_right,
                color: isDark
                    ? AppColors.textSecondary
                    : AppColors.textSecondary,
              ),
          ],
        ),
      ),
    );
}

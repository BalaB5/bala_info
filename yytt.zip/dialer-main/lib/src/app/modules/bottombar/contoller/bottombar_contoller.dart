import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hugeicons/hugeicons.dart';
 
import '../../../../core/app_colors.dart';
import '../../../controller/app_controller.dart';
import '../../callLogs/views/screens/call_logscreen.dart';
 
import '../../dashboard/followuplistscreen.dart';
import '../../dashboard/views/screens/dashboard_screen.dart';
import '../../payment_tracker/view/screens/customerscreen.dart'; 
import '../model/bottom_nav_bar_item.dart';

class BottomBarContoller extends GetxController {
  final AppDataController appDeta = Get.find();

  RxList<BottomNavBarItem> get pages => <BottomNavBarItem>[
    const BottomNavBarItem(
      screen: CallLogsScreen(),
      title: 'Call Log',
      icon: HugeIcons.strokeRoundedContact02,
      color: AppColors.converted,
    ),
    const BottomNavBarItem(
      screen: FollowUpsScreen(),
      title: "Reminder",
      // icon: Icons.trending_down_sharp,
      icon: HugeIcons.strokeRoundedTaskEdit02,
      color: Colors.blue,
    ),
    BottomNavBarItem(
      screen: const DashboardScreen(),
      title: 'Dashboard',
      icon: HugeIcons.strokeRoundedDashboardSquare02,
      color: AppColors.primary,
    ),
    // if (appDeta.roleId.value != 2)

    // if (appDeta.roleId.value = 1)
    BottomNavBarItem(
      screen: CustomerScreen(),
      title: 'Leads',
      icon: HugeIcons.strokeRoundedContact01,
      color: Colors.pink,
    ),

    // if (appDeta.roleId.value == 2)
  ].obs;
  final RxInt selectedIndex = 0.obs;
  late final PageController pageController;
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
  @override
  void onInit() {
    super.onInit();
    pageController = PageController(initialPage: selectedIndex.value);
  }

  @override
  void onClose() {
    pageController.dispose();
    super.onClose();
  }

  void openDrawer() {
    scaffoldKey.currentState?.openDrawer();
  }

  void closeDrawer() {
    scaffoldKey.currentState?.openEndDrawer();
  }
}

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:itracker/app.dart';

import '../../../../../core/app_colors.dart';
import '../../../../widgets/custom_app_bar.dart';
import '../../../../widgets/input_card_style.dart';
import '../../controller/leadcontroller.dart';

class AddNewLeadScreen extends StatelessWidget {
  AddNewLeadScreen({super.key});

  final LeadController controller = Get.put(LeadController());

  Widget sectionTitle(String title, {Color? color}) => Padding(
    padding: const EdgeInsets.only(right: 10, bottom: 8.0),
    child: Text(
      title,
      style: Theme.of(navigatorKey.currentContext!).textTheme.bodyLarge!
          .copyWith(
            color: color ?? AppColors.textPrimary,
            fontWeight: FontWeight.w600,
          ),
    ),
  );

  Widget errorText(RxString error) => Obx(
    () => error.value.isEmpty
        ? const SizedBox.shrink()
        : Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(
              error.value,
              style: Theme.of(
                navigatorKey.currentContext!,
              ).textTheme.bodySmall!.copyWith(color: AppColors.danger),
            ),
          ),
  );

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: AppColors.background,
    appBar: CustomAppBar(
      title: Text("Add Lead", style: Theme.of(context).textTheme.titleLarge!),
    ),
    body: SafeArea(
      bottom: false,
      child: Stack(
        children: [
          Column(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 100),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Column(
                        children: [
                          InputCardStyle(
                            padding: const EdgeInsets.symmetric(horizontal: 8),
                            child: TextFormField(
                              controller: controller.nameCtrl,
                              keyboardType: TextInputType.text,
                              decoration: InputDecoration(
                                label: const LableText(
                                  'Name',
                                  isrequired: true,
                                ),
                                border: InputBorder.none,
                                errorText: controller.nameError.value.isEmpty
                                    ? null
                                    : controller.nameError.value,
                              ),
                            ),
                          ),

                          const SizedBox(height: 8),

                          InputCardStyle(
                            padding: const EdgeInsets.symmetric(horizontal: 8),
                            child: TextFormField(
                              controller: controller.mobileCtrl,
                              keyboardType: TextInputType.phone,
                              inputFormatters: [
                                DigitsOnlyFormatter(),
                                FilteringTextInputFormatter
                                    .digitsOnly, // only digits
                                LengthLimitingTextInputFormatter(
                                  10,
                                ), // max 6 digits
                              ],
                              decoration: InputDecoration(
                                label: const LableText(
                                  'Mobile No',
                                  isrequired: true,
                                ),
                                border: InputBorder.none,
                                errorText: controller.mobileError.value.isEmpty
                                    ? null
                                    : controller.mobileError.value,
                              ),
                            ),
                          ),
                          const SizedBox(height: 8),
                          InputCardStyle(
                            child: TextFormField(
                              controller: controller.emailCtrl,
                              decoration: InputDecoration(
                                labelText: 'Email'.tr,
                                border: InputBorder.none,
                              ),
                              keyboardType: TextInputType.emailAddress,
                            ),
                          ),
                          const SizedBox(height: 8),
                          InputCardStyle(
                            padding: const EdgeInsets.symmetric(horizontal: 8),
                            child: Obx(
                              () => DropdownButtonFormField<String>(
                                value: controller.selectedGender.value.isEmpty
                                    ? null
                                    : controller.selectedGender.value,
                                icon: const Icon(Icons.keyboard_arrow_down),
                                items: controller.gender
                                    .map(
                                      (g) => DropdownMenuItem(
                                        value: g,
                                        child: Text(g),
                                      ),
                                    )
                                    .toList(),
                                onChanged: (value) {
                                  if (value != null) {
                                    controller.setGender(value);
                                  }
                                },
                                decoration: InputDecoration(
                                  labelText: 'Select Gender',
                                  border: InputBorder.none,
                                  errorText:
                                      controller.genderError.value.isEmpty
                                      ? null
                                      : controller.genderError.value,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 8),

                          InputCardStyle(
                            padding: const EdgeInsets.symmetric(horizontal: 8),
                            child: Obx(
                              () => DropdownButtonFormField<String>(
                                value: controller.selectedCountry.value.isEmpty
                                    ? null
                                    : controller.selectedCountry.value,
                                icon: const Icon(Icons.keyboard_arrow_down),
                                items: controller.countries
                                    .map(
                                      (g) => DropdownMenuItem(
                                        value: g,
                                        child: Text(g),
                                      ),
                                    )
                                    .toList(),
                                onChanged: (value) {
                                  if (value != null) {
                                    controller.setCountry(value);
                                  }
                                },
                                decoration: InputDecoration(
                                  labelText: 'Select Country *',
                                  border: InputBorder.none,
                                  errorText:
                                      controller.countryError.value.isEmpty
                                      ? null
                                      : controller.countryError.value,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 8),

                          Row(
                            children: [
                              Expanded(
                                child: InputCardStyle(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 8,
                                  ),
                                  child: Obx(
                                    () => DropdownButtonFormField<String>(
                                      value:
                                          controller.selectedState.value.isEmpty
                                          ? null
                                          : controller.selectedState.value,
                                      icon: const Icon(
                                        Icons.keyboard_arrow_down,
                                      ),
                                      items: controller.states
                                          .map(
                                            (g) => DropdownMenuItem(
                                              value: g,
                                              child: Text(g),
                                            ),
                                          )
                                          .toList(),
                                      onChanged: (value) {
                                        if (value != null) {
                                          controller.setStateValue(value);
                                        }
                                      },
                                      decoration: InputDecoration(
                                        labelText: 'Select State *',
                                        border: InputBorder.none,
                                        errorText:
                                            controller.stateError.value.isEmpty
                                            ? null
                                            : controller.stateError.value,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: InputCardStyle(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 8,
                                  ),
                                  child: Obx(
                                    () => DropdownButtonFormField<String>(
                                      value:
                                          controller.selectedCity.value.isEmpty
                                          ? null
                                          : controller.selectedCity.value,
                                      icon: const Icon(
                                        Icons.keyboard_arrow_down,
                                      ),
                                      items: controller.cities
                                          .map(
                                            (g) => DropdownMenuItem(
                                              value: g,
                                              child: Text(g),
                                            ),
                                          )
                                          .toList(),
                                      onChanged: (value) {
                                        if (value != null) {
                                          controller.setCity(value);
                                        }
                                      },
                                      decoration: InputDecoration(
                                        labelText: 'Select Country *',
                                        border: InputBorder.none,
                                        errorText:
                                            controller.cityError.value.isEmpty
                                            ? null
                                            : controller.cityError.value,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),

                          InputCardStyle(
                            padding: const EdgeInsets.symmetric(horizontal: 8),
                            child: Obx(
                              () => DropdownButtonFormField<String>(
                                value:
                                    controller.selectedLeadSource.value.isEmpty
                                    ? null
                                    : controller.selectedLeadSource.value,
                                icon: const Icon(Icons.keyboard_arrow_down),
                                items: controller.leadSources
                                    .map(
                                      (g) => DropdownMenuItem(
                                        value: g,
                                        child: Text(g),
                                      ),
                                    )
                                    .toList(),
                                onChanged: (value) {
                                  if (value != null) {
                                    controller.setLeadSource(value);
                                  }
                                },
                                decoration: InputDecoration(
                                  labelText: 'Select Source',
                                  border: InputBorder.none,
                                  errorText:
                                      controller.sourceError.value.isEmpty
                                      ? null
                                      : controller.sourceError.value,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Column(
                        children: [
                          // InputCardStyle(
                          //   child: TextFormField(
                          //     controller: controller.locationUrlCtrl,
                          //     decoration: InputDecoration(
                          //       labelText: 'Location'.tr,
                          //       border: InputBorder.none,
                          //     ),
                          //     keyboardType: TextInputType.url,
                          //   ),
                          // ),
                          // const SizedBox(height: 8),
                          InputCardStyle(
                            child: TextFormField(
                              controller: controller.addressCtrl,
                              maxLines: 3,
                              decoration: InputDecoration(
                                label: LableText(
                                  'Address'.tr,
                                  isrequired: false,
                                ),
                                border: InputBorder.none,
                              ),
                              inputFormatters: [
                                LengthLimitingTextInputFormatter(100),
                              ],
                            ),
                          ),
                          const SizedBox(height: 8),

                          Row(
                            children: [
                              Expanded(
                                child: InputCardStyle(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 8,
                                  ),
                                  child: Obx(
                                    () => DropdownButtonFormField<String>(
                                      value:
                                          controller
                                              .selectedLeadTag
                                              .value
                                              .isEmpty
                                          ? null
                                          : controller.selectedLeadTag.value,
                                      icon: const Icon(
                                        Icons.keyboard_arrow_down,
                                      ),
                                      items: controller.leadTags
                                          .map(
                                            (g) => DropdownMenuItem(
                                              value: g,
                                              child: Text(g),
                                            ),
                                          )
                                          .toList(),
                                      onChanged: (value) {
                                        if (value != null) {
                                          controller.setLeadTag(value);
                                        }
                                      },
                                      decoration: const InputDecoration(
                                        labelText: 'Select Tag ',
                                        border: InputBorder.none,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: InputCardStyle(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 8,
                                  ),
                                  child: Obx(
                                    () => DropdownButtonFormField<String>(
                                      value:
                                          controller
                                              .selectedLeadType
                                              .value
                                              .isEmpty
                                          ? null
                                          : controller.selectedLeadType.value,
                                      icon: const Icon(
                                        Icons.keyboard_arrow_down,
                                      ),
                                      items: controller.leadTypes
                                          .map(
                                            (g) => DropdownMenuItem(
                                              value: g,
                                              child: Text(g),
                                            ),
                                          )
                                          .toList(),
                                      onChanged: (value) {
                                        if (value != null) {
                                          controller.setLeadType(value);
                                        }
                                      },
                                      decoration: const InputDecoration(
                                        labelText: 'Select Type ',
                                        border: InputBorder.none,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          InputCardStyle(
                            child: TextFormField(
                              controller: controller.descriptionCtrl,
                              maxLines: 3,
                              decoration: InputDecoration(
                                label: LableText(
                                  'Description'.tr,
                                  isrequired: false,
                                ),
                                border: InputBorder.none,
                              ),
                              inputFormatters: [
                                LengthLimitingTextInputFormatter(100),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: Container(
              color: AppColors.background,
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              child: SafeArea(
                top: false,
                child: SizedBox(
                  height: 56,
                  child: ElevatedButton(
                    onPressed: () async {
                      await controller.createLead();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primary,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      elevation: 0,
                    ),
                    child: Text(
                      'Create Lead',
                      style: Theme.of(context).textTheme.bodyMedium!.copyWith(
                        color: AppColors.card,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    ),
  );
}

class LableText extends StatelessWidget {
  const LableText(this.text, {super.key, this.isrequired = false});

  final String text;
  final bool isrequired;

  @override
  Widget build(BuildContext context) => RichText(
    text: TextSpan(
      text: text,
      style: const TextStyle(color: Colors.black),
      children: [
        if (isrequired)
          const TextSpan(
            text: " *",
            style: TextStyle(color: Colors.red, fontSize: 20),
          ),
      ],
    ),
  );
}

class DigitsOnlyFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    final filtered = newValue.text.replaceAll(RegExp(r'[^0-9]'), '');
    return TextEditingValue(
      text: filtered,
      selection: TextSelection.collapsed(offset: filtered.length),
    );
  }
}

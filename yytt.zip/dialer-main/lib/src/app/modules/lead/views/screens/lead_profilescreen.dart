import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../core/app_colors.dart';
import '../../../../../core/app_style.dart';
import '../../../../controller/app_controller.dart';

class LeadProfileScreen extends StatefulWidget {
  const LeadProfileScreen({super.key});

  @override
  State<LeadProfileScreen> createState() => _LeadProfileScreenState();
}

class _LeadProfileScreenState extends State<LeadProfileScreen> {
  final AppDataController appDeta = Get.find();
  final List<Map<String, dynamic>> roles = [
    {"id": 0, "name": "Caller"},
    {"id": 1, "name": "Seller"},
    {"id": 2, "name": "Payment Collector"},
  ];

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final theme = Theme.of(context).textTheme;
    final isDark = Get.isDarkMode;

    return Scaffold(
      backgroundColor: dark ? const Color(0xFF101C22) : const Color(0xFFF5F7F8),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        title: Text(
          "Lead Profile",
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.bold,
            color: dark ? Colors.white : const Color(0xFF111618),
          ),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios),
          color: dark ? Colors.white : const Color(0xFF111618),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Profile
            Row(
              children: [
                const CircleAvatar(
                  radius: 30,
                  backgroundImage: NetworkImage(
                    "https://lh3.googleusercontent.com/aida-public/AB6AXuAX41WUHE14_m0qm-HBZkdkxqviKQRm5Yf0h8-KnBPDMd9mKxZUZkJNOYaK1iqh3LxOBoulXceV0UT2MgFVCjWt7-DdGRLpXOr8XgdUHBu_Ey1iDtW9zXxTfYsU748FMzRFse688ScQ0xDo0GLTM5QgZqUyN9R06zm4YVFF6hySBmICUaguA5kR9a6z3AAiHQPP0u91Vf94kt5mGPCY4niKHcMGsr7kS47UYUZoesVP1v37RvhLrUVahKBjCXnokWR4RUwJgRS23if-",
                  ),
                ),
                const SizedBox(width: 10),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Jordan Davies",
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                        color: dark ? Colors.white : const Color(0xFF111618),
                      ),
                    ),
                    Text(
                      "ID:BS035",
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: dark
                            ? Colors.grey[400]
                            : const Color(0xFF607C8A),
                      ),
                    ),
                    const SizedBox(height: 8),

                   // Row(
                    //   children: [
                    //     _contactIcon(
                    //       icon: Icons.call,
                    //       color: Colors.green.shade600,
                    //       onTap: () {}, // WhatsApp action
                    //     ),
                    //     const SizedBox(width: 8),
                    //     _contactIcon(
                    //       icon: Icons.message,
                    //       color: Colors.blue.shade400,
                    //       onTap: () {}, // Message action
                    //     ),
                    //     const SizedBox(width: 8),
                    //     _contactIcon(
                    //       icon: Icons.email,
                    //       color: Colors.red.shade400,
                    //       onTap: () {}, // Email action
                    //     ),
                    //   ],
                    // ),
                  ],
                ),
              ],
            ),

            const SizedBox(height: 8),
   DropdownButtonFormField<int>(
                      decoration: const InputDecoration(
                        labelText: "Select Role",
                        border: OutlineInputBorder(),
                      ),
                      initialValue: appDeta.roleId.value,
                      items: roles.map((role) => DropdownMenuItem<int>(
                          value: role["id"],
                          child: Text(role["name"]),
                        )).toList(),
                      onChanged: (value) {
                        appDeta.roleId.value = value!;
                      },
                    ),
                   const SizedBox(height: 8),
            // Lead Info
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: isDark ? AppColors.backgroundDark : AppColors.card,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.border),
              ),
              child: Column(
                children: [
                  _infoRow(Icons.phone, "+1 (555) 123-4567"),
                  _infoRow(Icons.mail, "jordan.d@innovate.com"),
                  _infoRow(Icons.work, "Innovate Inc."),
                  _statusRow("Qualified"),
                ],
              ),
            ),

            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Text("App Settings", style: theme.titleLarge),
                // const SizedBox(height: 8),
                // Text(
                //   "Customize your experience. These settings can be changed later.",
                //   style: theme.bodyMedium?.copyWith(
                //     color: isDark
                //         ? AppColors.textLight
                //         : AppColors.textSecondary,
                //   ),
                // ),
                const SizedBox(height: 8),

                _card(
                  isDark,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _iconTitle(
                        isDark,
                        icon: Icons.schedule,
                        title: "Time Format",
                        subtitle: "Choose 12-hour or 24-hour format.",
                      ),
                      const SizedBox(height: 8),

                      Row(
                        children: [
                          Expanded(
                            child: _optionButton(
                              text: "12-hour",
                              isSelected: true,
                              onTap: () {
                                // controller.changeTimeFormat(true)
                              },
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: _optionButton(
                              text: "24-hour",
                              isSelected: false,
                              onTap: () {
                                // controller.changeTimeFormat(false),
                              },
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 8),

                _card(
                  isDark,
                  child: Row(
                    children: [
                      Expanded(
                        child: _iconTitle(
                          isDark,
                          icon: Icons.public,
                          title: "Timezone",
                          subtitle: "Select your local timezone.",
                        ),
                      ),
                      Row(
                        children: [
                          Text(
                            "GMT-5:00",
                            style: theme.bodyMedium?.copyWith(
                              color: isDark
                                  ? AppColors.textLight
                                  : AppColors.textSecondary,
                            ),
                          ),
                          const SizedBox(width: 4),
                          Icon(
                            Icons.arrow_forward_ios,
                            size: 16,
                            color: isDark ? AppColors.textLight : Colors.grey,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 8),

                _card(
                  isDark,
                  child: Row(
                    children: [
                      Expanded(
                        child: _iconTitle(
                          isDark,
                          icon: Icons.translate,
                          title: "Language",
                          subtitle: "Choose your preferred language.",
                        ),
                      ),
                      Row(
                        children: [
                          Text(
                            "English (US)",
                            style: theme.bodyMedium?.copyWith(
                              color: isDark
                                  ? AppColors.textLight
                                  : AppColors.textSecondary,
                            ),
                          ),
                          const SizedBox(width: 4),
                          const Icon(
                            Icons.arrow_forward_ios,
                            size: 16,
                            color: Colors.grey,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 8),

                _card(
                  isDark,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _iconTitle(
                        isDark,
                        icon: Icons.format_size,
                        title: "Font Size",
                        subtitle: "Adjust text size for better readability.",
                      ),

                      // const SizedBox(height: 8),
                      Slider(
                        value: 1,
                        min: 0,
                        max: 100,
                        activeColor: AppColors.primary,
                        inactiveColor: AppColors.primary10(0.4),
                        onChanged: (vlu) {
                          // controller.changeFontSize;
                        },
                      ),

                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text("Small", style: theme.bodySmall),
                          Text("Default", style: theme.bodySmall),
                          Text("Large", style: theme.bodySmall),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),

            // const SizedBox(height: 24),

            // Text(
            //   "Interaction History",
            //   style: Theme.of(context).textTheme.titleLarge?.copyWith(
            //     fontWeight: FontWeight.bold,
            //     color: dark ? Colors.white : const Color(0xFF111618),
            //   ),
            // ),

            // const SizedBox(height: 12),

            // // Filter chips
            // SingleChildScrollView(
            //   scrollDirection: Axis.horizontal,
            //   child: Row(
            //     children: [
            //       _chip("All", true),
            //       _chip("Calls", false),
            //       _chip("Notes", false),
            //       _chip("Recordings", false),
            //       _chip("Emails", false),
            //     ],
            //   ),
            // ),

            // const SizedBox(height: 16),

            // // Interactions
            // Column(
            //   children: [
            //     _callCard(),
            //     const Padding(
            //       padding: EdgeInsets.only(left: 60),
            //       child: Divider(height: 20, thickness: 1, endIndent: 5),
            //     ),

            //     _noteCard(),
            //     const Padding(
            //       padding: EdgeInsets.only(left: 60),
            //       child: Divider(height: 20, thickness: 1, endIndent: 5),
            //     ),
            //     _emailCard(),
            //     const Padding(
            //       padding: EdgeInsets.only(left: 60),
            //       child: Divider(height: 20, thickness: 1, endIndent: 5),
            //     ),
            //     _initialContactCard(),
            //   ],
            // ),
          ],
        ),
      ),
    );
  }


  Widget _infoRow(IconData icon, String value) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Icon(icon, color: Colors.grey[600], size: 20),
          const SizedBox(width: 12),
          Text(
            value,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.black87),
          ),
        ],
      ),
    );

  Widget _statusRow(String label) => Row(
      children: [
        const Icon(Icons.signal_cellular_alt, color: Colors.grey, size: 20),
        const SizedBox(width: 12),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          decoration: BoxDecoration(
            color: Colors.green.shade100,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(
            label,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
              color: Colors.green,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ],
    );


  Widget _card(bool isDark, {required Widget child}) => Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: isDark ? AppColors.backgroundDark : AppColors.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: child,
    );

  Widget _iconTitle(
    bool isDark, {
    required IconData icon,
    required String title,
    required String subtitle,
  }) {
    final theme = Theme.of(context).textTheme;

    return Row(
      children: [
        Container(
          height: 48,
          width: 48,
          decoration: BoxDecoration(
            color: AppColors.primary.withAlpha(20),
            shape: BoxShape.circle,
          ),
          child: Icon(icon, color: AppColors.primary, size: AppStyle.iconSize),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: theme.bodyMedium?.copyWith(fontWeight: FontWeight.bold),
              ),
              Text(subtitle, style: theme.bodySmall),
            ],
          ),
        ),
      ],
    );
  }

  Widget _optionButton({
    required bool isSelected,
    required String text,
    required VoidCallback onTap,
  }) {
    final theme = Theme.of(context).textTheme;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 30,
        decoration: BoxDecoration(
          color: isSelected ? AppColors.primary : AppColors.card,
          borderRadius: BorderRadius.circular(50),
          border: Border.all(color: AppColors.primary),
        ),
        alignment: Alignment.center,
        child: Text(
          text,
          style: theme.bodyMedium?.copyWith(
            color: isSelected ? Colors.white : AppColors.textPrimary,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }


  // Widget _audioPlayer() {
  //   return StreamBuilder<Duration?>(
  //     stream: _player.durationStream,
  //     builder: (context, snapshot) {
  //       final duration = snapshot.data ?? Duration.zero;
  //       return StreamBuilder<Duration>(
  //         stream: _player.positionStream,
  //         builder: (context, snap) {
  //           final position = snap.data ?? Duration.zero;
  //           final progress = duration.inMilliseconds == 0
  //               ? 0.0
  //               : position.inMilliseconds / duration.inMilliseconds;

  //           return Container(
  //             padding: const EdgeInsets.all(8),
  //             decoration: BoxDecoration(
  //               color: Colors.grey.shade200,
  //               borderRadius: BorderRadius.circular(10),
  //             ),
  //             child: Row(
  //               children: [
  //                 IconButton(
  //                   icon: Icon(
  //                     _player.playing ? Icons.pause : Icons.play_arrow,
  //                     color: const Color(0xFF0DA6F2),
  //                   ),
  //                   onPressed: () {
  //                     _player.playing ? _player.pause() : _player.play();
  //                   },
  //                 ),
  //                 Expanded(
  //                   child: LinearProgressIndicator(
  //                     value: progress,
  //                     color: const Color(0xFF0DA6F2),
  //                     backgroundColor: Colors.grey[300],
  //                   ),
  //                 ),
  //                 const SizedBox(width: 8),
  //                 Text(
  //                   "${position.inSeconds}s / ${duration.inSeconds}s",
  //                   style: Theme.of(context).textTheme.bodySmall?.copyWith(
  //                     color: Colors.grey,
  //                   ),
  //                 ),
  //               ],
  //             ),
  //           );
  //         },
  //       );
  //     },
  //   );
  // }




}

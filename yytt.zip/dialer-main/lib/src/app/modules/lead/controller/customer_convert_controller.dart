import 'package:get/get.dart';

class CustomerConvertController extends GetxController {
  // Selected values
  var conversionType = "Send Document".obs;
  var salesDocument = "Proposal".obs;
  var communicationVia = "Whatsapp".obs;
  var paymentType = "With Payment".obs;
  var paymentMode = "Cash In Hand".obs;

  var minPaymentAmount = "".obs;

  // Available items (optional)
  List<String> salesDocList = [
    "Proposal",
    "Quotation",
    "Brochure",
  ];
}

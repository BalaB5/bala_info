
class TemplateModel {
  final String id;
  final String title;
  final String message;
  final String type;
  final bool hasChat;
  final bool hasCall;

  TemplateModel({
    required this.id,
    required this.title,
    required this.message,
    required this.type,
    required this.hasChat,
    required this.hasCall,
  });

  factory TemplateModel.fromJson(Map<String, dynamic> json) => TemplateModel(
      id: json['id'] ?? '',
      title: json['title'] ?? '',
      message: json['message'] ?? '',
      type: json['type'] ?? '',
      hasChat: json['has_chat'] ?? false,
      hasCall: json['has_call'] ?? false,
    );

  Map<String, dynamic> toJson() => {
      'id': id,
      'title': title,
      'message': message,
      'type': type,
      'has_chat': hasChat,
      'has_call': hasCall,
    };
}

class TemplateResponse {
  final bool status;
  final String message;
  final List<TemplateModel> data;

  TemplateResponse({
    required this.status,
    required this.message,
    required this.data,
  });

  factory TemplateResponse.fromJson(Map<String, dynamic> json) => TemplateResponse(
      status: json['status'] ?? false,
      message: json['message'] ?? '',
      data: (json['data'] as List<dynamic>?)
              ?.map((item) => TemplateModel.fromJson(item))
              .toList() ??
          [],
    );
}

class TemplateRepository {
  
  // Mock data since API is not developed yet
  final List<TemplateModel> _mockTemplates = [
    TemplateModel(
      id: '1',
      title: 'Welcome',
      message: 'Welcome aboard! We\'re delighted to have you as part of the [Your Company Name] family. Our team is committed to helping you succeed and grow with us.',
      type: 'welcome',
      hasChat: true,
      hasCall: true,
    ),
    TemplateModel(
      id: '2',
      title: 'Onboard',
      message: 'Welcome to [Your Company Name]! We\'re excited to have you onboard and look forward to supporting your business growth and success every step of the way.',
      type: 'onboard',
      hasChat: true,
      hasCall: true,
    ),
    TemplateModel(
      id: '3',
      title: 'Follow Up',
      message: 'Just checking in to see how everything is going. Let us know if you have any questions or need assistance with anything.',
      type: 'follow_up',
      hasChat: true,
      hasCall: false,
    ),
    TemplateModel(
      id: '4',
      title: 'Thank You',
      message: 'Thank you for your business! We truly appreciate your trust in us and look forward to continuing to serve you.',
      type: 'thank_you',
      hasChat: true,
      hasCall: false,
    ),
  ];

  Future<TemplateResponse> getTemplates({String? searchQuery}) async {
    // Simulate API delay
    await Future.delayed(const Duration(milliseconds: 500));
    
    try {
      List<TemplateModel> filteredTemplates = _mockTemplates;
      
      // Apply search filter if query exists
      if (searchQuery != null && searchQuery.isNotEmpty) {
        filteredTemplates = _mockTemplates.where((template) =>
            template.title.toLowerCase().contains(searchQuery.toLowerCase()) ||
            template.message.toLowerCase().contains(searchQuery.toLowerCase())
        ).toList();
      }
      
      return TemplateResponse(
        status: true,
        message: 'Success',
        data: filteredTemplates,
      );
    } catch (e) {
      return TemplateResponse(
        status: false,
        message: 'Error loading templates',
        data: [],
      );
    }
  }

  Future<TemplateResponse> selectTemplate(String templateId) async {
    // Simulate API delay
    await Future.delayed(const Duration(milliseconds: 300));
    
    try {
      final template = _mockTemplates.firstWhere(
        (template) => template.id == templateId,
        orElse: () => _mockTemplates.first,
      );
      
      return TemplateResponse(
        status: true,
        message: 'Template selected successfully',
        data: [template],
      );
    } catch (e) {
      return TemplateResponse(
        status: false,
        message: 'Error selecting template',
        data: [],
      );
    }
  }
}
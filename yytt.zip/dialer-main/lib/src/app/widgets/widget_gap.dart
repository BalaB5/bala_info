
import 'package:flutter/material.dart';

import '../../core/app_style.dart';

class WidgetGap extends StatelessWidget {
  const WidgetGap({super.key});

  @override
  Widget build(BuildContext context) => const SizedBox(height: AppStyle.widgetsGap);
}

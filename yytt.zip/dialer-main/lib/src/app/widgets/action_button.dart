import 'package:flutter/material.dart';
 
import 'dart:io';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:hugeicons/hugeicons.dart';

import '../../core/app_style.dart';

class ActionButton extends StatelessWidget {
  final List<List<dynamic>> icon;
  final String label;
  final Function()? onTap;
  final Color color;
  const ActionButton({
    super.key,
    required this.icon,
    required this.label,
    required this.onTap,
    required this.color,
  });

  @override
  Widget build(BuildContext context) => Column(
      children: [
        InkWell(
          onTap: onTap,
          child: Container(
            decoration: BoxDecoration(
               color: color.withAlpha(30),
              
              borderRadius: const BorderRadius.all(
                Radius.circular(AppStyle.borderRadiusBottom),
              ),
            ),
            padding: const EdgeInsets.all(10),
            child: 
              HugeIcon(
            icon:  icon,
         
            size: AppStyle.iconSizelarge,
            color: color),
          ),
        ),
        const SizedBox(height: 2),
        Text(
          label,
          style: TextStyle(fontSize: 12, color: color),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
      ],
    );
}

class ImageView extends StatelessWidget {
  const ImageView(
    this.icon, {
    super.key,

    this.width,
    this.height,
    this.color,
    this.fit = BoxFit.contain,
    this.placeholder,
    this.errorWidget,
  });

  final String icon;
  final double? width;
  final double? height;
  final Color? color;
  final BoxFit fit;
  final Widget? placeholder;
  final Widget? errorWidget;

  bool _isNetworkImage(String url) =>
      url.startsWith('http://') || url.startsWith('https://');

  bool _isAssetImage(String path) =>
      !path.startsWith('/') && !path.startsWith('http');

  bool _isLocalFile(String path) => File(path).existsSync();

  bool _isSvg(String path) => path.toLowerCase().endsWith('.svg');

  @override
  Widget build(BuildContext context) {
    if (_isSvg(icon)) {
      // ✅ Handle SVG Images
      if (_isNetworkImage(icon)) {
        return SvgPicture.network(
          icon,
          width: width,
          height: height,
          colorFilter:
              color != null ? ColorFilter.mode(color!, BlendMode.srcIn) : null,
          placeholderBuilder:
              (context) =>
                  placeholder ??
                  const Center(child: CircularProgressIndicator()),
        );
      } else if (_isAssetImage(icon)) {
        return SvgPicture.asset(
          icon,
          width: width,
          height: height,
          colorFilter:
              color != null ? ColorFilter.mode(color!, BlendMode.srcIn) : null,
        );
      } else if (_isLocalFile(icon)) {
        return SvgPicture.file(
          File(icon),
          width: width,
          height: height,
          colorFilter:
              color != null ? ColorFilter.mode(color!, BlendMode.srcIn) : null,
        );
      }
    } else {
      // ✅ Handle Raster Images (PNG, JPG, JPEG, WEBP, etc.)
      if (_isNetworkImage(icon)) {
        return CachedNetworkImage(
          imageUrl: icon,
          width: width,
          height: height,
          fit: fit,
          color: color,
          placeholder:
              (context, url) =>
                  placeholder ??
                  const Center(child: CircularProgressIndicator()),
          errorWidget:
              (context, url, error) =>
                  errorWidget ??
                  const Icon(Icons.broken_image, color: Colors.grey),
        );
      } else if (_isAssetImage(icon)) {
        return Image.asset(
          icon,
          width: width,
          height: height,
          fit: fit,
          color: color,
          errorBuilder:
              (context, error, stackTrace) =>
                  errorWidget ??
                  const Icon(Icons.broken_image, color: Colors.grey),
        );
      } else if (_isLocalFile(icon)) {
        return Image.file(
          File(icon),
          width: width,
          height: height,
          fit: fit,
          color: color,
          errorBuilder:
              (context, error, stackTrace) =>
                  errorWidget ??
                  const Icon(Icons.broken_image, color: Colors.grey),
        );
      }
    }

    // Default fallback if nothing matches
    return errorWidget ?? const Icon(Icons.broken_image, color: Colors.grey);
  }
}

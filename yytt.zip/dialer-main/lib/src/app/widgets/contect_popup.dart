import 'package:flutter/material.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'package:flutter_phone_direct_caller/flutter_phone_direct_caller.dart';
import 'package:get/get.dart';

import '../../core/app_colors.dart';
import '../../core/app_icons.dart';
import '../../core/app_style.dart';
import '../../core/image_view.dart';
import '../utils/utils.dart';

class ContactPopup extends StatefulWidget {
  const ContactPopup({super.key});

  @override
  State<ContactPopup> createState() => _ContactPopupState();
}

class _ContactPopupState extends State<ContactPopup> {
  final TextEditingController callSummaryController = TextEditingController();
  final TextEditingController followupReasonController =
      TextEditingController();

  String? selectedStatus = "Capsule";
  TimeOfDay? selectedTime;
  DateTime? selectedDate;

  final List<String> statuses = [
    "Capsule",
    "Interested",
    "Not Interested",
    "Callback",
  ];

  Future<void> pickTime() async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (picked != null) {
      setState(() => selectedTime = picked);
    }
  }

  Future<void> pickDate() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    if (picked != null) {
      setState(() => selectedDate = picked);
    }
  }

  @override
  Widget build(BuildContext context) => Dialog(
    backgroundColor: Colors.transparent,
    child: Stack(
      children: [
        Container(
          width: 450,
          // margin: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: const BorderRadius.all(Radius.circular(12)),
            border: Border.all(
              color: AppColors.primary,
              width: 1,
              style: BorderStyle.solid,
            ),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Header Section
              Container(
                decoration: BoxDecoration(
                  color: AppColors.primary,
                  borderRadius: const BorderRadius.vertical(
                    top: Radius.circular(12),
                  ),
                  border: Border.all(
                    color: AppColors.primary,
                    width: 2,
                    style: BorderStyle.solid,
                  ),
                ),
                padding: const EdgeInsets.symmetric(
                  vertical: 5,
                  horizontal: 16,
                ),
                child: Row(
                  children: [
                    InkWell(
                      onTap: () async {
                        await FlutterOverlayWindow.shareData({
                          "id": 101,
                          "message": "User clicked overlay button",
                        });

                        FlutterOverlayWindow.closeOverlay();
                      },
                      child: const CircleAvatar(
                        radius: 24,
                        backgroundColor: Colors.white24,
                        child: Text(
                          "A",
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "API Data .....",
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: Theme.of(context).textTheme.bodyMedium
                                ?.copyWith(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                          ),

                          Text(
                            "+91 9403890435",
                            style: Theme.of(context).textTheme.bodySmall
                                ?.copyWith(color: Colors.white70),
                          ),
                          const SizedBox(height: 6),
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 15,
                                  vertical: 2,
                                ),
                                decoration: BoxDecoration(
                                  color: Colors.green.shade50,
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Text(
                                  "VIP",
                                  style: Theme.of(context).textTheme.bodySmall
                                      ?.copyWith(
                                        color: Colors.green,
                                        fontWeight: FontWeight.w600,
                                      ),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Container(
                                width: 22,
                                height: 22,
                                decoration: BoxDecoration(
                                  border: Border.all(color: Colors.white38),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: const Icon(
                                  Icons.add,
                                  size: 14,
                                  color: Colors.white,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      icon: ImageView(
                        AppIcons.whatsapp,
                        width: AppStyle.iconSize,
                        height: AppStyle.iconSize,
                      ),
                      onPressed: () {
                        openWhatsApp("+918608080510");
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.phone, color: Colors.white),
                      onPressed: () {
                        FlutterPhoneDirectCaller.callNumber(
                          95382364.toString(),
                        );
                      },
                    ),
                  ],
                ),
              ),

              // Lead and Assign info
              SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      color: const Color.fromARGB(255, 255, 255, 255),
                      padding: const EdgeInsets.symmetric(
                        vertical: 4,
                        horizontal: 16,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Text(
                              "Lead stage: Demo",
                              style: Theme.of(context).textTheme.bodySmall,
                            ),
                          ),
                          Expanded(
                            child: Text(
                              "Assigned to: Sales",
                              style: Theme.of(context).textTheme.bodySmall,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      "Followup Status",
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 3),
                    DropdownButtonFormField<String>(
                      initialValue: selectedStatus,
                      decoration: _inputDecoration(),
                      padding: const EdgeInsets.symmetric(vertical: 0),
                      items: statuses
                          .map(
                            (status) => DropdownMenuItem(
                              value: status,
                              child: Text(status),
                            ),
                          )
                          .toList(),
                      onChanged: (value) =>
                          setState(() => selectedStatus = value),
                    ),

                    const SizedBox(height: 8),
                    Text(
                      "Call Summary",
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 3),
                    _textBox(
                      controller: callSummaryController,
                      hint: "Enter call summary",
                    ),

                    // const SizedBox(height: 8),
                    // Text(
                    //   "Followup info:",
                    //   style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    //     fontWeight: FontWeight.w600,
                    //   ),
                    // ),
                    // Text(
                    //   "Followup eiubbnnnionbiubjiikjknk",
                    //   style: Theme.of(context).textTheme.bodySmall?.copyWith(),
                    // ),
                  ],
                ),
              ),

              const SizedBox(height: 24),
              Center(
                child: SizedBox(
                  width: 120,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primary,

                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                    onPressed: () {
                      FlutterOverlayWindow.closeOverlay();
                    },
                    child: Text(
                      "Saved",
                      style: Theme.of(
                        context,
                      ).textTheme.bodyMedium?.copyWith(color: Colors.white),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              // Tabs
              // DefaultTabController(
              //   length: 2,
              //   child: Column(
              //     children: [
              //       TabBar(
              //         labelColor: Colors.blue,
              //         unselectedLabelColor: Colors.grey,
              //         tabs: [const Tab(text: "Activity"), const Tab(text: "Info")],
              //         labelStyle: Theme.of(context).textTheme.bodyMedium,
              //       ),
              //       Container(
              //         height: 250,
              //         padding: const EdgeInsets.symmetric(
              //           vertical: 0,
              //           horizontal: 16,
              //         ),
              //         child: ListView(
              //           children: [
              //             ListTile(
              //               leading: const Icon(
              //                 Icons.note_alt_outlined,
              //                 color: Colors.blue,
              //               ),
              //               title: const Text("Notes"),
              //               trailing: const Icon(Icons.arrow_forward_ios, size: 14),
              //               onTap: () {},
              //             ),
              //             ListTile(
              //               leading: const Icon(
              //                 Icons.message_outlined,
              //                 color: Colors.green,
              //               ),
              //               title: const Text("Quick Message"),
              //               trailing: const Icon(Icons.arrow_forward_ios, size: 14),
              //               onTap: () {},
              //             ),
              //             ListTile(
              //               leading: const Icon(Icons.alarm, color: Colors.orange),
              //               title: const Text("Reminders"),
              //               trailing: const Icon(Icons.arrow_forward_ios, size: 14),
              //               onTap: () {},
              //             ),
              //             ListTile(
              //               leading: const Icon(
              //                 Icons.business,
              //                 color: Colors.deepPurple,
              //               ),
              //               title: const Text("Boost your Google Business Profile"),
              //               trailing: const Icon(Icons.arrow_forward_ios, size: 14),
              //               onTap: () {},
              //             ),
              //           ],
              //         ),
              //       ),
              //     ],
              //   ),
              // ),
            ],
          ),
        ),
        Positioned(
          top: -10,
          right: -10,
          child: IconButton(
            onPressed: () {
              FlutterOverlayWindow.closeOverlay();
            },
            icon: const Icon(
              Icons.cancel_presentation_outlined,
              color: Colors.red,
            ),
          ),
        ),
      ],
    ),
  );

  InputDecoration _inputDecoration() => InputDecoration(
    contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(8),
      borderSide: const BorderSide(color: Colors.grey),
    ),
  );

  Widget _textBox({
    required TextEditingController controller,
    required String hint,
  }) => TextField(
    controller: controller,
    maxLines: 3,

    decoration: InputDecoration(
      hintText: hint,
      hintStyle: Theme.of(context).textTheme.bodySmall,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        // borderSide: const BorderSide(color: Colors.blueAccent),
      ),
    ),
  );
}

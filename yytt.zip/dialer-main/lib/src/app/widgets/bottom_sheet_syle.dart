 
import 'package:itracker/src/core/app_colors.dart';
import 'package:flutter/material.dart';
 

import '../../../app.dart';
import 'buttom_sheet_scroll_button.dart';

class BottomSheetStyle extends StatelessWidget {
  const BottomSheetStyle({super.key, required this.child});
  final Widget? child;

  @override
  Widget build(BuildContext context) => SafeArea(
    child: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              color: AppColors.background,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            // constraints: const BoxConstraints(
            //   maxHeight: 600
            // ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                
                const SizedBox(height: 10),
                const ButtomSheetScrollButton(),
                 child ?? const SizedBox.shrink(),
    
                // const SizedBox(),
              ],
            ),
          ),
    
          Positioned(
            top: 0,
            right: 0,
            child: IconButton(
              icon: Icon(
                Icons.highlight_remove,
                color: Theme.of(context).colorScheme.primary,
              ),
              iconSize: 40,
              onPressed: () {
                 navigatorKey.currentState!.pop();
              },
            ),
          ),
        ],
      ),
  );
}

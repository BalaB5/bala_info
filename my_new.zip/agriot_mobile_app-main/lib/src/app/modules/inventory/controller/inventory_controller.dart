import 'package:argiot/src/app/modules/inventory/model/inventory_model.dart';
import 'package:argiot/src/app/modules/inventory/repostory/inventory_repository.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';

import '../../../routes/app_routes.dart';

class InventoryController extends GetxController {
  final InventoryRepository _repository = InventoryRepository();

  final Rx<InventoryModel?> inventory = Rx<InventoryModel?>(null);
  final RxBool isLoading = false.obs;
  final RxString errorMessage = ''.obs;

  @override
  void onInit() {
    super.onInit();
    loadInventory();
  }

  Future<void> loadInventory() async {
    try {
      isLoading(true);
      errorMessage('');
      final result = await _repository.getInventory();
      inventory(result);
    } catch (e) {
      errorMessage(e.toString());
      Fluttertoast.showToast(
        msg: "Failed to load inventory: ${e.toString()}",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
      );
    } finally {
      isLoading(false);
    }
  }

  void navigateToAddInventory() {
    Get.toNamed(Routes.fuelConsumption)?.then((res) {
      if (res ?? false) {
        loadInventory();
      }
    });
  }

  void navigateToCategoryDetail(String category, int id, {int tab = 0}) {
    Get.toNamed('/consumption-purchase', arguments: {"id": id, 'tab': tab});
  }
}

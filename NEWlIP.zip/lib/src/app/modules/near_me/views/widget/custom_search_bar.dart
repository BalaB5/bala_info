// widgets/search_bar.dart

import 'package:flutter/material.dart';

import '../../../../widgets/input_card_style.dart';

class CustomSearchBar extends StatelessWidget {
  final Widget label;
  final Function(String) onChanged;

  const CustomSearchBar({
    super.key,
    required this.label,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) =>  InputCardStyle(
               
      child: TextField(
        decoration: InputDecoration(
          label: label,
          prefixIcon: const Icon(Icons.search),
          border: InputBorder.none,
        ),
        onChanged: onChanged,
      ),
    );
}

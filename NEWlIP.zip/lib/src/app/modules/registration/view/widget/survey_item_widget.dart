import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../widgets/input_card_style.dart';
import '../../../../widgets/lable_text.dart';
import '../../model/dropdown_item.dart';
import '../../model/survey_model.dart';
import 'searchable_dropdown.dart';

class SurveyItemWidget extends StatelessWidget {
  final int index;
  final SurveyItem item;
  final List<AppDropdownItem> areaUnits;
  final VoidCallback onRemove;
  final void Function(SurveyItem) onChanged; 

  const SurveyItemWidget({
    super.key,
    required this.index,
    required this.item,
    required this.areaUnits,
    required this.onRemove,
    required this.onChanged, 
  });

  @override
  Widget build(BuildContext context) => Card(
    elevation: 1,
    margin: const EdgeInsets.only(bottom: 16),
    child: Padding(
      padding: const EdgeInsets.all(10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "${'survey_detail_number'.tr} ${index + 1}"
                ,
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),

              if(item.id == null)
              IconButton(
                icon: const Icon(Icons.delete, color: Colors.red),
                onPressed: onRemove,
              ),
            ],
          ),
          const SizedBox(height: 8),
          InputCardStyle(
            child: TextFormField(
              initialValue: item.surveyNo,
              decoration: InputDecoration(
                label: LableText( 'survey_number'.tr,isrequired: true,),
                border: InputBorder.none,
                isDense: true,
              ),
              onChanged: (value) => onChanged(item.copyWith(surveyNo: value)),
              validator: (value) => value!.isEmpty ? 'required_field'.tr : null,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                flex: 3,
                child: InputCardStyle(
                  child: TextFormField(
                    initialValue: item.measurement,
                    decoration: InputDecoration(
                      label: LableText( 'measurement'.tr,isrequired: true,),
                      border: InputBorder.none,
                      isDense: true,
                    ),
                    keyboardType: TextInputType.number,
                    onChanged: (value) =>
                        onChanged(item.copyWith(measurement: value)),
                    validator: (value) =>
                        value!.isEmpty ? 'required_field'.tr : null,
                  ),
                ),
              ),
              const SizedBox(width: 16),

              Expanded(
                flex: 2,
                child: SearchableDropdown<AppDropdownItem>(
                  label:  LableText( 'unit'.tr,isrequired: true,),
                  items: areaUnits,
                  displayItem: (value) => value.name.toString(),
                  selectedItem: item.unit,
                  onChanged: (value) => onChanged(item.copyWith(unit: value)),
                  validator: (value) =>
                      value == null ? 'required_field'.tr : null,
                ),
              ),
            ],
          ),
        ],
      ),
    ),
  );
}

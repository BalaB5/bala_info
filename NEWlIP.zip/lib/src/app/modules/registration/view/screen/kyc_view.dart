import 'package:argiot/src/app/widgets/lower_case_text_formatter.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';

import '../../../../widgets/input_card_style.dart';
import '../../../../widgets/lable_text.dart';
import '../../controller/kyc_controller.dart';

class KycView extends GetView<KycController> {
  const KycView({super.key});

  @override
  Widget build(BuildContext context) {
    var gap = const SizedBox(height: 14);
    return Form(
      key: controller.formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 10),
              _buildTextField(
                controller: controller.nameController,
                label: LableText('your_name'.tr, isrequired: true),
                validator: (value) =>
                    value!.isEmpty ? 'required_field'.tr : null,
              ),

              if (!controller.isEmailLogin.value) ...[
                gap,
                _buildTextField(
                  controller: controller.emailController,
                  label: LableText('email'.tr, isrequired: true),
                  inputFormatters: [LowerCaseTextFormatter()],
                  validator: (value) =>
                      !GetUtils.isEmail(value!) ? 'enter_valid_email'.tr : null,
                  keyboardType: TextInputType.emailAddress,
                ),
              ] else ...[
                gap,
                _buildTextField(
                  controller: controller.numberController,
                  label: LableText('mobile_number'.tr, isrequired: true),
                  validator: (value) =>
                      value!.isEmpty ? 'required_field'.tr : null,
                  keyboardType: TextInputType.number,
                ),
              ],
              gap,
              _buildTextField(
                controller: controller.companyController,
                label: LableText('company_name'.tr),
              ),
              gap,
              _buildTextField(
                controller: controller.taxNoController,
                label: LableText('tax_number'.tr),
                keyboardType: TextInputType.number,
              ),
            ],
          ),

          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              gap,
              _buildTextField(
                controller: controller.locationController,
                label: LableText('location_coordinates'.tr, isrequired: true),
                validator: (value) =>
                    value!.isEmpty ? 'required_field'.tr : null,
                readOnly: true,
                onTap: controller.pickLocation,
              ),
              gap,
              _buildTextField(
                controller: controller.pincodeController,
                label: LableText('pincode'.tr, isrequired: true),
                // inputFormatters: [
                //   FilteringTextInputFormatter.digitsOnly,
                //   LengthLimitingTextInputFormatter(6),
                // ],
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Required field';
                  }
                  if (value.length > 11) {
                    return 'Please enter a valid Pincode'.tr;
                  }

                  return null;
                },
                keyboardType: TextInputType.number,
              ),

              gap,
              _buildTextField(
                controller: controller.doorNoController,
                label: LableText('address'.tr,),
                maxLines: 3,
              ),
            ],
          ),

          const SizedBox(height: 32),
          _buildSubmitButton(),
          const SizedBox(height: 60),
        ],
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required Widget label,
    List<TextInputFormatter>? inputFormatters,
    String? Function(String?)? validator,
    TextInputType? keyboardType,
    bool readOnly = false,
    int? maxLines = 1,
    VoidCallback? onTap,
  }) => InputCardStyle(
    child: TextFormField(
      controller: controller,
      inputFormatters: inputFormatters,
      decoration: InputDecoration(
        label: label,
        border: InputBorder.none,
        isDense: true,
        suffixIcon: readOnly ? const Icon(Icons.location_on) : null,
      ),
      validator: validator,
      keyboardType: keyboardType,
      maxLines: maxLines,
      readOnly: readOnly,
      onTap: onTap,
    ),
  );

  Widget _buildSubmitButton() => Obx(
    () => ElevatedButton(
      onPressed: controller.isSubmitting.value ? null : controller.submitForm,
      style: ElevatedButton.styleFrom(
        padding: const EdgeInsets.symmetric(vertical: 16),
        backgroundColor: Get.theme.primaryColor,
      ),
      child: controller.isSubmitting.value
          ? const SizedBox(
              width: 20,
              height: 20,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                color: Colors.white,
              ),
            )
          : Text('save_continue'.tr),
    ),
  );
}

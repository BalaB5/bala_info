import 'package:argiot/src/app/modules/task/model/named_item.dart';
import 'package:argiot/src/app/widgets/input_card_style.dart';
import 'package:flutter/material.dart';

class MyDropdown<T extends NamedItem> extends StatelessWidget {
  final List<T> items;
  final Widget label;
  final bool disabled;
  final T? selectedItem;
  final void Function(T?) onChanged;

  final EdgeInsetsGeometry? padding;
  final InputBorder? border;
final String? Function(T?)? validator;
  const MyDropdown({
    super.key,

    required this.items,
    required this.label,
    this.disabled = false,
    required this.selectedItem,
    required this.onChanged,

    this.padding,
    this.border,
    this.validator,
  });

  @override
  Widget build(BuildContext context) => InputCardStyle(      
      padding: const EdgeInsets.symmetric(horizontal: 8),
    child: DropdownButtonFormField<T>(
      key: key,
      initialValue: selectedItem,
      decoration: InputDecoration(label: label, border: InputBorder.none),
      icon: const Icon(Icons.keyboard_arrow_down),
      // hint: labelText != null ? Text(labelText!) : null,
    
      items: items
          .map(
            (T item) => DropdownMenuItem<T>(
              value: item,
              child: Text(
                item.name,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: disabled ? Colors.grey : null),
              ),
            ),
          )
          .toList(),
      onChanged: disabled ? null : onChanged,
      isExpanded: true,
      style: Theme.of(
        context,
      ).textTheme.titleMedium?.copyWith(color: disabled ? Colors.grey : null),
      validator:validator?? (value) {
        if (value == null) {
          return 'Please select a $label';
        }
        return null;
      },
    ),
  );
}

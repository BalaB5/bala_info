

import '../../../service/utils/utils.dart';
class PermissionItem {
  String name;
  int status;
  Map<String, PermissionItem> children;

  PermissionItem({
    required this.name,
    this.status = 0,
    this.children = const {},
  });

  factory PermissionItem.fromApi(String name, dynamic json) {
    Map<String, PermissionItem> childItems = {};
    int status = 0;
    if (json is Map<String, dynamic>) {
      json.forEach((k, v) {
        if (v is int && v != 0) {
          status = v;
        } else {
          childItems[k] = PermissionItem.fromApi(k, v);
        }
      });
    } else if (json is int) {
      status = json;
    }

    return PermissionItem(
      name: capitalizeFirstLetter(name),
      status: status,
      children: childItems,
    );
  }

  /// Updated toFlatJson returns **int for leaf** or **map of children** recursively
  dynamic toFlatJson() {
    if (children.isEmpty) {
      return status; // leaf node returns status directly
    }
    final Map<String, dynamic> result = {};
    children.forEach((key, value) {
      result[key] = value.toFlatJson();
    });
    return result;
  }
}

import 'dart:io';

import 'package:argiot/src/app/modules/manager/controller/manager_controller.dart';
import 'package:argiot/src/app/modules/manager/model/dropdown_model.dart';
import 'package:argiot/src/app/modules/manager/model/permission_model.dart';
import 'package:argiot/src/app/modules/near_me/views/widget/custom_app_bar.dart';
import 'package:argiot/src/app/widgets/input_card_style.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';

import '../../../../widgets/lable_text.dart';
import '../../../../widgets/loading.dart';
import '../../../dashboad/view/widgets/buttom_sheet_scroll_button.dart';

class CreateManagerScreen extends GetView<ManagerController> {
  const CreateManagerScreen({super.key});
  final gap = const SizedBox(height: 14);
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: const CustomAppBar(title: 'Employee'),
    body: SingleChildScrollView(
      padding: const EdgeInsets.all(10),
      child: Form(
        key: controller.formKey,
        child: Column(
          children: [
            // gap,

            // Manager Photo
            // _buildImagePicker(),
            gap,

            /// Role Dropdown
            Obx(
              () =>
                  controller.appDeta.permission.value?.users?.add != 0 &&
                      controller.id.value == 0
                  ? Row(
                      children: [
                        Expanded(
                          child: InputCardStyle(
                            padding: const EdgeInsets.symmetric(horizontal: 8),
                            child: DropdownButtonFormField<DrapDown>(
                              initialValue: controller.selectedRoleType.value,
                              icon: const Icon(Icons.keyboard_arrow_down),
                              items: controller.roleTypes
                                  .map(
                                    (r) => DropdownMenuItem(
                                      value: r,
                                      child: Text(r.name),
                                    ),
                                  )
                                  .toList(),
                              onChanged: (value) =>
                                  controller.selectedRoleType.value = value,
                              decoration: const InputDecoration(
                                label:  LableText( 'Select Role ',isrequired: true,),
                                border: InputBorder.none,
                              ),
                              validator: (value) =>
                                  value == null ? 'Required field' : null,
                            ),
                          ),
                        ),
                        if (controller.appDeta.permission.value?.role?.add != 0)
                          Card(
                            color: Get.theme.primaryColor,
                            child: IconButton(
                              color: Colors.white,
                              icon: const Icon(Icons.add),
                              onPressed: () {
                                Get.bottomSheet(
                                  const AddRole(key: ValueKey("NewRole")),
                                );
                              },
                              tooltip: 'Add Survey Detail',
                            ),
                          ),
                      ],
                    )
                  : const SizedBox(),
            ),

            gap,

            //Usersname
            InputCardStyle(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: TextFormField(
                controller: controller.usernameController,
                decoration: const InputDecoration(
                  label: LableText( " Name",isrequired: true,),
                  border: InputBorder.none,
                ),
                validator: (value) =>
                    value == null || value.isEmpty ? 'Required field' : null,
              ),
            ),

            //Email
            Obx(
              () => controller.selectedRoleType.value?.id != 0
                  ? Column(
                      children: [
                        gap,
                        InputCardStyle(
                          padding: const EdgeInsets.symmetric(horizontal: 8),
                          child: TextFormField(
                            controller: controller.emailController,
                            decoration: const InputDecoration(
                              label: LableText("Email ID " ,isrequired: true,),
                              border: InputBorder.none,
                            ),
                            validator: (value) => value == null || value.isEmpty
                                ? 'Required field'
                                : null,
                          ),
                        ),
                      ],
                    )
                  : const SizedBox(),
            ),
            gap,

            // Mobile No
            InputCardStyle(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: TextFormField(
                controller: controller.mobileController,
                keyboardType: TextInputType.phone,
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly, // only digits
                  // LengthLimitingTextInputFormatter(10), // max 6 digits
                ],
                validator: (value) => value == null || value.trim().isEmpty
                    ? 'Required field'
                    : null,
                decoration: const InputDecoration(
                  label: LableText( 'Mobile No' ,isrequired: true,),
                  border: InputBorder.none,
                ),
              ),
            ),

            Obx(
              () => controller.selectedRoleType.value?.id != 0
                  ? const SizedBox()
                  : Column(
                      children: [
                        gap,

                        // Mobile No
                        InputCardStyle(
                          padding: const EdgeInsets.symmetric(horizontal: 8),
                          child: TextFormField(
                            controller: controller.salaryController,
                            keyboardType: TextInputType.phone,
                            inputFormatters: [
                              FilteringTextInputFormatter.digitsOnly,
                            ],
                            validator: (value) =>
                                value == null || value.trim().isEmpty
                                ? 'Required field'
                                : null,
                            decoration: const InputDecoration(
                              label:  LableText('Per Hour Salary' ,isrequired: true,),
                              border: InputBorder.none,
                            ),
                          ),
                        ),
                      ],
                    ),
            ),

            /// Gender Dropdown
            Obx(
              () => controller.selectedRoleType.value?.id != 0
                  ? Column(
                      children: [
                        gap,
                        InputCardStyle(
                          padding: const EdgeInsets.symmetric(horizontal: 8),
                          child: DropdownButtonFormField<DrapDown>(
                            initialValue: controller.selectedGenderType.value,
                            icon: const Icon(Icons.keyboard_arrow_down),
                            items: controller.genderTypes
                                .map(
                                  (g) => DropdownMenuItem(
                                    value: g,
                                    child: Text(g.name),
                                  ),
                                )
                                .toList(),
                            onChanged: (value) =>
                                controller.selectedGenderType.value = value,
                            decoration: const InputDecoration(
                              labelText: 'Select Gender ',
                              border: InputBorder.none,
                            ),
                          ),
                        ),
                      ],
                    )
                  : const SizedBox(),
            ),
            // Date of Birth
            Obx(
              () => controller.selectedRoleType.value?.id != 0
                  ? Column(
                      children: [
                        gap,
                        InputCardStyle(
                          padding: const EdgeInsets.symmetric(horizontal: 8),
                          child: TextFormField(
                            controller: controller.dobcontroller,
                            readOnly: true,
                            decoration: const InputDecoration(
                              labelText: 'Date of Birth ',
                              border: InputBorder.none,
                              suffixIcon: Icon(
                                Icons.calendar_today,
                                color: Colors.grey,
                              ),
                            ),
                            onTap: () async {
                              DateTime? picked = await showDatePicker(
                                context: context,
                                initialDate: DateTime.now(),
                                firstDate: DateTime(1950),
                                lastDate: DateTime.now(),
                              );
                              if (picked != null) {
                                controller.dobcontroller.text =
                                    "${picked.day}/${picked.month}/${picked.year}";
                              }
                            },
                          ),
                        ),
                      ],
                    )
                  : const SizedBox(),
            ),
            // Date of Joining
            Obx(
              () => controller.selectedRoleType.value?.id != 0
                  ? Column(
                      children: [
                        gap,
                        InputCardStyle(
                          padding: const EdgeInsets.symmetric(horizontal: 8),
                          child: TextFormField(
                            controller: controller.dojcontroller,
                            readOnly: true,
                            decoration: const InputDecoration(
                              labelText: 'Date of Joining ',
                              border: InputBorder.none,
                              suffixIcon: Icon(
                                Icons.calendar_today,
                                color: Colors.grey,
                              ),
                            ),
                            onTap: () async {
                              DateTime? picked = await showDatePicker(
                                context: context,
                                initialDate: DateTime.now(),
                                firstDate: DateTime(1990),
                                lastDate: DateTime(2100),
                              );
                              if (picked != null) {
                                controller.dojcontroller.text =
                                    "${picked.day}/${picked.month}/${picked.year}";
                              }
                            },
                          ),
                        ),
                      ],
                    )
                  : const SizedBox(),
            ),
            gap,

            /// Employee Type Dropdown
            Obx(
              () => InputCardStyle(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: DropdownButtonFormField<DrapDown>(
                  initialValue: controller.selectedEmployeeType.value,
                  icon: const Icon(Icons.keyboard_arrow_down),
                  items: controller.employeeTypes
                      .map(
                        (e) => DropdownMenuItem(value: e, child: Text(e.name)),
                      )
                      .toList(),
                  onChanged: (value) =>
                      controller.selectedEmployeeType.value = value,
                  decoration: const InputDecoration(
                    label: LableText("Employee Type", isrequired: true),
                    border: InputBorder.none,
                  ),
                  validator: (value) => value == null ? 'Required field' : null,
                ),
              ),
            ),

            // Work Type
            Obx(
              () => controller.selectedRoleType.value?.id == 0
                  ? Column(
                      children: [
                        gap,
                        InputCardStyle(
                          padding: const EdgeInsets.symmetric(horizontal: 8),
                          child: DropdownButtonFormField<DrapDown>(
                            initialValue: controller.selectedWorkType.value,
                            icon: const Icon(Icons.keyboard_arrow_down),
                            items: controller.workTypes
                                .map(
                                  (e) => DropdownMenuItem<DrapDown>(
                                    value: e,
                                    child: Text(e.name),
                                  ),
                                )
                                .toList(),
                            onChanged: (value) =>
                                controller.selectedWorkType.value = value,
                            decoration: const InputDecoration(
                              label: LableText("Work Type", isrequired: true),
                              border: InputBorder.none,
                            ),
                            validator: (value) =>
                                value == null ? 'Required field' : null,
                          ),
                        ),
                      ],
                    )
                  : const SizedBox(),
            ),

            // Assign Manager
            Obx(() {
              if (controller.selectedRoleType.value?.id == 0) {
                if (controller.isLoadingManager.value) {
                  return const Loading();
                }
                return Column(
                  children: [
                    gap,
                    InputCardStyle(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      child: DropdownButtonFormField<DrapDown>(
                        initialValue: controller.selectedManager.value,
                        icon: const Icon(Icons.keyboard_arrow_down),
                        items: controller.managers
                            .map(
                              (e) => DropdownMenuItem(
                                value: e,
                                child: Text(e.name),
                              ),
                            )
                            .toList(),
                        onChanged: (value) =>
                            controller.selectedManager.value = value,
                        decoration: const InputDecoration(
                          labelText: 'Assign Manager',
                          border: InputBorder.none,
                        ),
                        // validator: (value) =>
                        //     value == null ? 'Required field' : null,
                      ),
                    ),
                  ],
                );
              } else {
                return const SizedBox();
              }
            }),
            gap,

            // Location URL
            InputCardStyle(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: TextFormField(
                controller: controller.locationController,
                decoration: const InputDecoration(
                  label: LableText("Location ", isrequired: true),
                  border: InputBorder.none,
                ),
                validator: (value) => value == null || value.trim().isEmpty
                    ? 'Required field'
                    : null,
                readOnly: true,
                onTap: controller.pickLocation,
              ),
            ),

            // //pincode
            gap,
            InputCardStyle(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: TextFormField(
                controller: controller.pincodeController,
                // inputFormatters: [
                //   FilteringTextInputFormatter.digitsOnly,
                //   LengthLimitingTextInputFormatter(6),
                // ],
                decoration: const InputDecoration(
                  label: LableText( "Pincode",isrequired: true,),
                  border: InputBorder.none,
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Required field';
                  }
                  if (value.length > 11) {
                    return 'Please enter a valid Pincode'.tr;
                  }

                  return null;
                },
              ),
            ),

            gap,

            // Address
            InputCardStyle(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: TextFormField(
                maxLines: 3,
                controller: controller.addressController,
                decoration: const InputDecoration(
                  label: LableText('Address', isrequired: true),
                  border: InputBorder.none,
                ),
                validator: (value) => value == null || value.trim().isEmpty
                    ? 'Required field'
                    : null,
              ),
            ),

            gap,

            // Description
            InputCardStyle(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: TextFormField(
                controller: controller.descriptionController,
                maxLines: 3,
                decoration: const InputDecoration(
                  labelText: 'Description',
                  border: InputBorder.none,
                ),
              ),
            ),
            gap,

            // ---------------- Permissions Section ----------------
            Obx(
              () => controller.selectedRoleType.value?.id != 0
                  ? InputCardStyle(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      child: Obx(() {
                        if (controller.isLoading.value) {
                          return const Center(child: Loading());
                        }

                        if (controller.permissions.isEmpty) {
                          return const Center(
                            child: Text("No permissions found"),
                          );
                        }

                        return Column(
                          children: controller.permissions.values
                              .map(
                                (item) =>
                                    _buildPermissionItem(item, controller),
                              )
                              .toList(),
                        );
                      }),
                    )
                  : const SizedBox(),
            ),
            gap,

            // Submit Button
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: controller.submitForm, // ✅ no parentheses
                child: const Text('Submit'),
              ),
            ),
          ],
        ),
      ),
    ),
  );

  Widget _buildImagePicker() => Center(
    child: InkWell(
      onTap: controller.pickImage,
      child: Stack(
        children: [
          Obx(() {
            if (controller.imagePath.isNotEmpty) {
              return CircleAvatar(
                radius: 50,
                backgroundImage: controller.imagePath.startsWith('http')
                    ? CachedNetworkImageProvider(controller.imagePath.value)
                    : FileImage(File(controller.imagePath.value))
                          as ImageProvider,
              );
            }
            return const CircleAvatar(
              radius: 50,
              child: Icon(Icons.person, size: 40),
            );
          }),
          Positioned(
            bottom: 0,
            right: 0,
            child: Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: Get.theme.primaryColor,
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.camera_alt,
                size: 20,
                color: Colors.white,
              ),
            ),
          ),
        ],
      ),
    ),
  );

  Widget _buildPermissionItem(
    PermissionItem item,
    ManagerController controller,
  ) => GetBuilder<ManagerController>(
    builder: (_) => Theme(
      data: Theme.of(Get.context!).copyWith(dividerColor: Colors.transparent),
      child: ExpansionTile(
        title: Row(
          children: [
            Checkbox(
              value: item.status == 1,
              onChanged: (val) => controller.toggleStatus(item, val ?? false),
            ),
            Text(item.name),
          ],
        ),
        children: item.children.values
            .map(
              (child) => Padding(
                padding: const EdgeInsets.only(left: 16.0),
                child: _buildPermissionItem(child, controller),
              ),
            )
            .toList(),
      ),
    ),
  );
}

class AddRole extends GetView<ManagerController> {
  final int taskId;
  const AddRole({super.key, this.taskId = 0});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: Get.theme.scaffoldBackgroundColor,
      borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
    ),
    child: Form(
      key: controller.roleformKey,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const ButtomSheetScrollButton(),
          Text(
            'add_new_role'.tr,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),

          // Description
          InputCardStyle(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: TextFormField(
              decoration: InputDecoration(
                label: LableText('role_name'.tr, isrequired: true),
                border: InputBorder.none,
              ),
              validator: (value) => value == null || value.trim().isEmpty
                  ? 'Required field'
                  : null,
              onChanged: (value) => controller.newRole.value = value,
            ),
          ),

          const SizedBox(height: 16),
          Obx(
            () => ElevatedButton(
              onPressed: controller.isLoading.value
                  ? null
                  : () {
                      if (!controller.roleformKey.currentState!.validate()) {
                        return;
                      }
                      controller.addRole();
                    },
              child: controller.isLoading.value
                  ? const Loading(size: 50)
                  : Text('add'.tr),
            ),
          ),
          const SizedBox(height: 30),
        ],
      ),
    ),
  );
}

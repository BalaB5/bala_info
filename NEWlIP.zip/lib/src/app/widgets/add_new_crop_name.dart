import 'package:argiot/src/app/modules/dashboad/view/widgets/buttom_sheet_scroll_button.dart';
import 'package:argiot/src/app/modules/manager/controller/manager_controller.dart';
import 'package:argiot/src/app/widgets/input_card_style.dart';
import 'package:argiot/src/app/widgets/lable_text.dart';
import 'package:argiot/src/app/widgets/loading.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class AddNewCropName extends GetView<ManagerController> {
  // final int taskId;
  const AddNewCropName({super.key,});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: Get.theme.scaffoldBackgroundColor,
      borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
    ),
    child: Form(
      key: controller.roleformKey,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const ButtomSheetScrollButton(),
          Text(
            'add_new_role'.tr,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),

          // Description
          InputCardStyle(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: TextFormField(
              decoration: InputDecoration(
                label: LableText('role_name'.tr ,isrequired: true,),
                border: InputBorder.none,
              ),
              validator: (value) => value == null || value.trim().isEmpty
                  ? 'Required field'
                  : null,
              onChanged: (value) => controller.newRole.value = value,
            ),
          ),

          const SizedBox(height: 16),
          Obx(
            () => ElevatedButton(
              onPressed: controller.isLoading.value
                  ? null
                  : () {
                      if (!controller.roleformKey.currentState!.validate()) {
                        return;
                      }
                      controller.addRole();
                    },
              child: controller.isLoading.value
                  ? const Loading(size: 50)
                  : Text('add'.tr),
            ),
          ),
          const SizedBox(height: 30),
        ],
      ),
    ),
  );
}

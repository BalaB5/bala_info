// lib/core/app_colors.dart
import 'package:flutter/material.dart';

class AppColors {
  static const primary = Color(0xFF6366F1);
  static const secondary = Color(0xFF34D399);
  static const tertiary = Color(0xFFFBBF24);
  static const danger = Color(0xFFEF4444);

  static const background = Color(0xFFF7F8FC);
  static const card = Color(0xFFFFFFFF);

  static const textPrimary = Color(0xFF111827);
  static const textSecondary = Color(0xFF6B7280);
  static const border = Color(0xFFE5E7EB);

  // small helpers
  static Color primary10([double opacity = 0.30]) =>
      primary.withOpacity(opacity);
  static Color white10([double opacity = 0.10]) =>
      Colors.white.withOpacity(opacity);

  //Lead profile screen
  static const Color primary1 = Color(0xFF0da6f2);
  static const Color backgroundLight = Color(0xFFF5F7F8);
  static const Color backgroundDark = Color(0xFF101C22);
  static const Color textDark = Color(0xFF111618);
  static const Color textLight = Colors.white;
  static const Color accent = Color(0xFF607c8a);
}

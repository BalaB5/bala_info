// lib/modules/dashboard/view/dashboard_screen.dart
import 'package:calltrackerui/src/app/modules/dashboard/controller/dashboard_controller.dart';
import 'package:calltrackerui/src/app/modules/dashboard/views/widgets/pie_chart.dart';
import 'package:calltrackerui/src/app/modules/dashboard/views/widgets/recent_activity.dart';
import 'package:calltrackerui/src/app/modules/dashboard/views/widgets/stat_card.dart';
import 'package:calltrackerui/src/app/modules/dashboard/views/widgets/weekly_graph.dart';
import 'package:calltrackerui/src/core/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:syncfusion_flutter_gauges/gauges.dart';
import '../../../bottombar/views/widgets/nav_bar_item.dart';

class DashboardScreen extends GetView<DashboardController> {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final themeTitle = Get.textTheme.titleLarge!;
    final bodyMedium = Get.textTheme.bodyMedium!;
    final bodySmall = Get.textTheme.bodySmall!;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            // header
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              color: AppColors.background,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      // avatar
                      Container(
                        height: 48,
                        width: 48,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(999),
                          image: const DecorationImage(
                            fit: BoxFit.cover,
                            image: NetworkImage(
                              "https://lh3.googleusercontent.com/aida-public/AB6AXuC_QyOUmrO3QXMKlQyKGRC_8p3CKPTVcnuyqwzdmJP-F7LDqeNGgrB_lrYYoG9B31c4F0eUivl0_-aZCnHKsZzG0RL5yuK9X6h1QLaA2220oukmqBLIpGXpph5cNz69Ckl4HIHzgiHRerO0ML4w6wC1hwJVYvWbd9J9ChwdXhGcoVsV9T0AWc5r493Yc0re91gOIr_BqGDj9OzYdjfFZ2Is4lyXkp7TiaqonwH75bzmgGQnrH8KY-PFq-1vQcU3rOYvutBH9hCmBFqW",
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Dashboard",
                            style: themeTitle.copyWith(fontSize: 18),
                          ),
                          Text(
                            "Good morning, Alex",
                            style: bodySmall.copyWith(
                              color: AppColors.textSecondary,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  IconButton(
                    onPressed: () {},
                    icon: const Icon(Icons.notifications_outlined, size: 26),
                    color: AppColors.textSecondary,
                  ),
                ],
              ),
            ),

            // body
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                physics: const BouncingScrollPhysics(),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // Hero banner + CTA
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: AppColors.primary10(),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Good Morning!",
                                  style: themeTitle.copyWith(
                                    color: AppColors.primary,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  "Here's your sales summary for today.",
                                  style: bodyMedium.copyWith(
                                    color: AppColors.primary.withOpacity(0.8),
                                  ),
                                ),
                              ],
                            ),
                          ),

                          SizedBox(
                            width: 100,
                            height: 100,
                            child: SfRadialGauge(
                              axes: <RadialAxis>[
                                RadialAxis(
                                  minimum: 0,
                                  maximum: 100,
                                  showLabels: false,
                                  showTicks: false,
                                  pointers: <GaugePointer>[
                                    RangePointer(
                                      value: 20,
                                      cornerStyle: CornerStyle.bothCurve,
                                      width: 0.2,
                                      sizeUnit: GaugeSizeUnit.factor,
                                    ),
                                    RangePointer(
                                      value: 50,
                                      cornerStyle: CornerStyle.bothCurve,
                                      width: 0.2,
                                      sizeUnit: GaugeSizeUnit.factor,
                                    ),
                                  ],
                                  annotations: <GaugeAnnotation>[
                                    GaugeAnnotation(
                                      positionFactor: 0.1,
                                      angle: 90,
                                      widget: Text(
                                        20.toStringAsFixed(0) + ' / 100',
                                        style: TextStyle(fontSize: 11),
                                      ),
                                    ),
                                  ],
                                  axisLineStyle: AxisLineStyle(
                                    thickness: 0.2,
                                    cornerStyle: CornerStyle.bothCurve,
                                    color: Color.fromARGB(255, 255, 255, 255),
                                    thicknessUnit: GaugeSizeUnit.factor,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          // Container(
                          //   width: 100,
                          //   height: 50,
                          //   child: CheckInOutSwitch(
                          //     initialValue: false,
                          //     onChanged: (value) {
                          //       if (value) {
                          //         ScaffoldMessenger.of(context).showSnackBar(
                          //           const SnackBar(
                          //             content: Text("You have checked in!"),
                          //           ),
                          //         );
                          //       } else {
                          //         ScaffoldMessenger.of(context).showSnackBar(
                          //           const SnackBar(
                          //             content: Text("You have checked out!"),
                          //           ),
                          //         );
                          //       }
                          //     },
                          //   ),
                          // ),
                          // ElevatedButton(
                          //   onPressed: () {},
                          //   style: ElevatedButton.styleFrom(
                          //     backgroundColor: AppColors.primary,
                          //     shape: RoundedRectangleBorder(
                          //       borderRadius: BorderRadius.circular(999),
                          //     ),
                          //     padding: const EdgeInsets.symmetric(
                          //       horizontal: 16,
                          //       vertical: 10,
                          //     ),
                          //   ),
                          //   child: Text(
                          //     "View Details",
                          //     style: bodyMedium.copyWith(color: Colors.white),
                          //   ),
                          // ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 16),

                    // Stats grid (2x2)
                    Row(
                      children: [
                        Expanded(
                          child: StatCard.animated(
                            title: "Outgoing",
                            icon: Icons.call_made,
                            color: AppColors.primary,
                            countRx: controller.outgoing,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: StatCard.animated(
                            title: "Incoming",
                            icon: Icons.call_received,
                            color: AppColors.secondary,
                            countRx: controller.incoming,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: StatCard.animated(
                            title: "Missed",
                            icon: Icons.call_missed,
                            color: AppColors.tertiary,
                            countRx: controller.missed,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: StatCard.animated(
                            title: "Rejected",
                            icon: Icons.call_missed_outlined,
                            color: AppColors.danger,
                            countRx: controller.rejected,
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 16),

                    // donut + legend
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: AppColors.card,
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.03),
                            blurRadius: 8,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text("Today's Summary", style: themeTitle),
                                  const SizedBox(height: 4),
                                  Text(
                                    "October 26",
                                    style: bodySmall.copyWith(
                                      color: AppColors.textSecondary,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              // Pie/donut
                              SizedBox(
                                width: 130,
                                height: 130,
                                child: Stack(
                                  alignment: Alignment.center,
                                  children: [
                                    // ✅ Force the CustomPaint to fill full area
                                    SizedBox.expand(
                                      child: Obx(() {
                                        final totals = [
                                          controller.outgoing.value.toDouble(),
                                          controller.incoming.value.toDouble(),
                                          controller.missed.value.toDouble(),
                                          controller.rejected.value.toDouble(),
                                        ];
                                        return DonutPieChart(
                                          values: totals,
                                          colors: const [
                                            AppColors.primary,
                                            AppColors.secondary,
                                            AppColors.tertiary,
                                            AppColors.danger,
                                          ],
                                        );
                                      }),
                                    ),

                                    // ✅ Optional soft inner circle (for text contrast)
                                    Container(
                                      width: 65,
                                      height: 65,
                                      decoration: BoxDecoration(
                                        color: Colors.white.withOpacity(0.9),
                                        shape: BoxShape.circle,
                                      ),
                                    ),

                                    // ✅ Center total calls text
                                    Obx(() {
                                      return Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Text(
                                            "${controller.totalCalls.value}",
                                            style: themeTitle.copyWith(
                                              fontSize: 20,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                          Text(
                                            "Total Calls",
                                            style: bodySmall.copyWith(
                                              color: AppColors.textSecondary,
                                            ),
                                          ),
                                        ],
                                      );
                                    }),
                                  ],
                                ),
                              ),

                              const SizedBox(width: 18),
                              // legend
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    LegendItem(
                                      color: AppColors.primary,
                                      label: "Outgoing",
                                    ),
                                    LegendItem(
                                      color: AppColors.secondary,
                                      label: "Incoming",
                                    ),
                                    LegendItem(
                                      color: AppColors.tertiary,
                                      label: "Missed",
                                    ),
                                    LegendItem(
                                      color: AppColors.danger,
                                      label: "Rejected",
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 16),

                    // weekly activity (graph)
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.03),
                            blurRadius: 8,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "Weekly Activity",
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                  SizedBox(height: 4),
                                  Text(
                                    "Total 869 Calls",
                                    style: TextStyle(color: Colors.grey),
                                  ),
                                ],
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 8,
                                  vertical: 4,
                                ),
                                decoration: BoxDecoration(
                                  color: const Color(
                                    0xFF22C55E,
                                  ).withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(999),
                                ),
                                child: const Row(
                                  children: [
                                    Icon(
                                      Icons.arrow_upward,
                                      color: Color(0xFF22C55E),
                                      size: 16,
                                    ),
                                    SizedBox(width: 4),
                                    Text(
                                      "+5.2%",
                                      style: TextStyle(
                                        color: Color(0xFF22C55E),
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 16),
                          SizedBox(
                            height: 160,
                            child: WeeklyGraph(
                              data: [0.1, 0.6, 0.4, 0.7, 0.2, 0.9, 0.60],
                            ),
                          ),
                          const SizedBox(height: 8),
                          const Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text("Mon", style: TextStyle(fontSize: 12)),
                              Text("Tue", style: TextStyle(fontSize: 12)),
                              Text("Wed", style: TextStyle(fontSize: 12)),
                              Text("Thu", style: TextStyle(fontSize: 12)),
                              Text("Fri", style: TextStyle(fontSize: 12)),
                              Text("Sat", style: TextStyle(fontSize: 12)),
                              Text("Sun", style: TextStyle(fontSize: 12)),
                            ],
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 16),

                    // recent activity
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: AppColors.card,
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.03),
                            blurRadius: 8,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("Recent Activity", style: themeTitle),
                          const SizedBox(height: 12),
                          Obx(
                            () => Column(
                              children: controller.recent.map((r) {
                                return RecentActivityItem(
                                  name: r['name'] ?? '',
                                  subtitle: r['type'] ?? '',
                                  time: r['time'] ?? '',
                                  icon: r['icon'] ?? 'call_made',
                                  colorName: r['color'] ?? 'primary',
                                );
                              }).toList(),
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 90),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class LegendItem extends StatelessWidget {
  final Color color;
  final String label;
  const LegendItem({super.key, required this.color, required this.label});
  @override
  Widget build(BuildContext context) {
    final bodySmall = Get.textTheme.bodySmall!;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 10),
      child: Row(
        children: [
          Container(
            width: 10,
            height: 10,
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(4),
            ),
          ),
          const SizedBox(width: 8),
          Text(label, style: bodySmall.copyWith(fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}

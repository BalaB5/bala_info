import 'package:audio_session/audio_session.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:just_audio/just_audio.dart';

class LeadProfileScreen extends StatefulWidget {
  const LeadProfileScreen({super.key});

  @override
  State<LeadProfileScreen> createState() => _LeadProfileScreenState();
}

class _LeadProfileScreenState extends State<LeadProfileScreen> {
  late AudioPlayer _player;

  @override
  void initState() {
    super.initState();
    _initAudio();
  }

  Future<void> _initAudio() async {
    _player = AudioPlayer();
    final session = await AudioSession.instance;
    await session.configure(const AudioSessionConfiguration.music());
    await _player.setUrl(
      'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
    );
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: dark ? const Color(0xFF101C22) : const Color(0xFFF5F7F8),
      appBar: AppBar(
        backgroundColor: dark
            ? const Color(0xFF101C22)
            : const Color(0xFFF5F7F8),
        elevation: 0,
        centerTitle: true,
        title: Text(
          "Lead Profile",
          style: Get.textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.bold,
            color: dark ? Colors.white : const Color(0xFF111618),
          ),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          color: dark ? Colors.white : const Color(0xFF111618),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Profile
            Row(
              children: [
                const CircleAvatar(
                  radius: 45,
                  backgroundImage: NetworkImage(
                    "https://lh3.googleusercontent.com/aida-public/AB6AXuAX41WUHE14_m0qm-HBZkdkxqviKQRm5Yf0h8-KnBPDMd9mKxZUZkJNOYaK1iqh3LxOBoulXceV0UT2MgFVCjWt7-DdGRLpXOr8XgdUHBu_Ey1iDtW9zXxTfYsU748FMzRFse688ScQ0xDo0GLTM5QgZqUyN9R06zm4YVFF6hySBmICUaguA5kR9a6z3AAiHQPP0u91Vf94kt5mGPCY4niKHcMGsr7kS47UYUZoesVP1v37RvhLrUVahKBjCXnokWR4RUwJgRS23if-",
                  ),
                ),
                const SizedBox(width: 16),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Jordan Davies",
                      style: Get.textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                        color: dark ? Colors.white : const Color(0xFF111618),
                      ),
                    ),
                    Text(
                      "Marketing Manager at Innovate Inc.",
                      style: Get.textTheme.bodyMedium?.copyWith(
                        color: dark
                            ? Colors.grey[400]
                            : const Color(0xFF607C8A),
                      ),
                    ),
                    SizedBox(height: 10),
                    Row(
                      children: [
                        _contactIcon(
                          icon: Icons.call,
                          color: Colors.green.shade600,
                          onTap: () {}, // WhatsApp action
                        ),
                        const SizedBox(width: 8),
                        _contactIcon(
                          icon: Icons.message,
                          color: Colors.blue.shade400,
                          onTap: () {}, // Message action
                        ),
                        const SizedBox(width: 8),
                        _contactIcon(
                          icon: Icons.email,
                          color: Colors.red.shade400,
                          onTap: () {}, // Email action
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),

            const SizedBox(height: 24),

            // Lead Info
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: dark ? Colors.grey[900] : Colors.white,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                children: [
                  _infoRow(Icons.phone, "+1 (555) 123-4567"),
                  _infoRow(Icons.mail, "jordan.d@innovate.com"),
                  _infoRow(Icons.work, "Innovate Inc."),
                  _statusRow("Qualified"),
                ],
              ),
            ),

            const SizedBox(height: 24),

            Text(
              "Interaction History",
              style: Get.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
                color: dark ? Colors.white : const Color(0xFF111618),
              ),
            ),

            const SizedBox(height: 12),

            // Filter chips
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _chip("All", true),
                  _chip("Calls", false),
                  _chip("Notes", false),
                  _chip("Recordings", false),
                  _chip("Emails", false),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // Interactions
            Column(
              children: [
                _callCard(),
                const Padding(
                  padding: EdgeInsets.only(left: 60),
                  child: Divider(height: 20, thickness: 1, endIndent: 5),
                ),

                _noteCard(),
                const Padding(
                  padding: EdgeInsets.only(left: 60),
                  child: Divider(height: 20, thickness: 1, endIndent: 5),
                ),
                _emailCard(),
                const Padding(
                  padding: EdgeInsets.only(left: 60),
                  child: Divider(height: 20, thickness: 1, endIndent: 5),
                ),
                _initialContactCard(),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _contactIcon({
    required IconData icon,
    required Color color,
    VoidCallback? onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 34,
        height: 34,
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          shape: BoxShape.circle,
        ),
        child: Icon(icon, color: color, size: 18),
      ),
    );
  }

  Widget _infoRow(IconData icon, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Icon(icon, color: Colors.grey[600], size: 20),
          const SizedBox(width: 12),
          Text(
            value,
            style: Get.textTheme.bodyMedium?.copyWith(color: Colors.black87),
          ),
        ],
      ),
    );
  }

  Widget _statusRow(String label) {
    return Row(
      children: [
        const Icon(Icons.signal_cellular_alt, color: Colors.grey, size: 20),
        const SizedBox(width: 12),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          decoration: BoxDecoration(
            color: Colors.green.shade100,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(
            label,
            style: Get.textTheme.bodySmall?.copyWith(
              color: Colors.green,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ],
    );
  }

  Widget _chip(String label, bool selected) {
    return Container(
      margin: const EdgeInsets.only(right: 8),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      decoration: BoxDecoration(
        color: selected ? const Color(0xFF0DA6F2) : Colors.grey[300],
        borderRadius: BorderRadius.circular(30),
      ),
      child: Text(
        label,
        style: Get.textTheme.bodyMedium?.copyWith(
          color: selected ? Colors.white : Colors.black87,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  Widget _callCard() {
    return _interactionTile(
      icon: Icons.call,
      title: "Follow-up Call",
      subtitle:
          "Discussed pricing and next steps. Sent follow-up email with proposal.",
      time: "10:45 AM",
      color: const Color(0xFF0DA6F2),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 8),
          _audioPlayer(),
          const SizedBox(height: 6),
          Text(
            "Logged by: Alex Ray",
            style: Get.textTheme.bodySmall?.copyWith(color: Colors.grey),
          ),
        ],
      ),
    );
  }

  Widget _audioPlayer() {
    return StreamBuilder<Duration?>(
      stream: _player.durationStream,
      builder: (context, snapshot) {
        final duration = snapshot.data ?? Duration.zero;
        return StreamBuilder<Duration>(
          stream: _player.positionStream,
          builder: (context, snap) {
            final position = snap.data ?? Duration.zero;
            final progress = duration.inMilliseconds == 0
                ? 0.0
                : position.inMilliseconds / duration.inMilliseconds;

            return Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.grey.shade200,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                children: [
                  IconButton(
                    icon: Icon(
                      _player.playing ? Icons.pause : Icons.play_arrow,
                      color: const Color(0xFF0DA6F2),
                    ),
                    onPressed: () {
                      _player.playing ? _player.pause() : _player.play();
                    },
                  ),
                  Expanded(
                    child: LinearProgressIndicator(
                      value: progress,
                      color: const Color(0xFF0DA6F2),
                      backgroundColor: Colors.grey[300],
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    "${position.inSeconds}s / ${duration.inSeconds}s",
                    style: Get.textTheme.bodySmall?.copyWith(
                      color: Colors.grey,
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _noteCard() {
    return _interactionTile(
      icon: Icons.sticky_note_2,
      title: "Internal Note",
      subtitle:
          "Jordan is the key decision-maker for this account. Mentioned needing approval from VP Finance.",
      time: "Yesterday",
      color: Colors.yellow.shade700,
    );
  }

  Widget _emailCard() {
    return _interactionTile(
      icon: Icons.email,
      title: "Sent Proposal",
      subtitle: "Initial proposal sent via email.",
      time: "May 15, 2024",
      color: Colors.red.shade600,
    );
  }

  Widget _initialContactCard() {
    return _interactionTile(
      icon: Icons.call_received,
      title: "Initial Contact",
      subtitle: "First contact made, scheduled a follow-up call.",
      time: "May 12, 2024",
      color: const Color(0xFF0DA6F2),
    );
  }

  Widget _interactionTile({
    required IconData icon,
    required String title,
    required String subtitle,
    required String time,
    required Color color,
    Widget? child,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CircleAvatar(
            radius: 22,
            backgroundColor: color.withOpacity(0.2),
            child: Icon(icon, color: color),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      title,
                      style: Get.textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                      ),
                    ),
                    Text(
                      time,
                      style: Get.textTheme.bodySmall?.copyWith(
                        color: Colors.grey,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: Get.textTheme.bodyMedium?.copyWith(
                    color: Colors.grey[700],
                  ),
                ),
                if (child != null) child,
              ],
            ),
          ),
        ],
      ),
    );
  }
}

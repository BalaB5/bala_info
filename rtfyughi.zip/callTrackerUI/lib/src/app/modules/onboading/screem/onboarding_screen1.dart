import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../core/app_colors.dart';
import '../onboarding_controller.dart'; 
class OnboardingScreen1 extends StatelessWidget {
  const OnboardingScreen1({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<OnboardingController>();

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(children: [
                    Container(width: 32, height: 8, decoration: BoxDecoration(color: AppColors.primary, borderRadius: BorderRadius.circular(4))),
                    const SizedBox(width: 4),
                    Container(width: 8, height: 8, decoration: BoxDecoration(color: AppColors.primary.withOpacity(0.3), borderRadius: BorderRadius.circular(4))),
                    const SizedBox(width: 4),
                    Container(width: 8, height: 8, decoration: BoxDecoration(color: AppColors.primary.withOpacity(0.3), borderRadius: BorderRadius.circular(4))),
                  ]),
                  TextButton(
                    onPressed: controller.skip,
                    child: Text('Skip', style: Get.textTheme.bodyMedium?.copyWith(color: AppColors.primary, fontWeight: FontWeight.bold)),
                  ),
                ],
              ),
              const Spacer(),
              Image.network(
                'https://lh3.googleusercontent.com/aida-public/AB6AXuCyh-CdRW5AI5lNuiNkxQpKLVHpEqyvdZWYMd4AwIix2FJAbYQFuXeSyqaoXXALIKkn1--8v8ege1AXbGTW9vbes3PAJWTizhVZVi-ZnwjyBs1uvwA87jEHbnaWjvXjS-Q_dkW5BS9vfMMUqvW9YV74P8RZ7fiHAOwQ_NI4g8OVuRDvRAcv9K3DlYXeRgHGKHTe9haxXGXrQHtlhExYigUetJGZBf4GTvGW7OL50DhlmJiuzNfeLAYp4LH2yw2lDDf6tsBAMrlTOPA',
                height: 250,
              ),
              const SizedBox(height: 32),
              Text('Welcome to CallTrack', style: Get.textTheme.titleLarge?.copyWith(color: AppColors.textDark)),
              const SizedBox(height: 8),
              Text(
                'Track, analyze, and improve your sales calls effortlessly.',
                style: Get.textTheme.bodyMedium?.copyWith(color: AppColors.textDark),
                textAlign: TextAlign.center,
              ),
              const Spacer(),
              ElevatedButton(
                onPressed: controller.nextPage,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  shape: const StadiumBorder(),
                  minimumSize: const Size.fromHeight(56),
                ),
                child: Text('Get Started', style: Get.textTheme.bodyMedium?.copyWith(color: Colors.white, fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

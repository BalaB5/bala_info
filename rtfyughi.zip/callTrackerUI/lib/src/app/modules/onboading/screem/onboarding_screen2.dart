import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../core/app_colors.dart';
import '../../../../core/app_spacing.dart';
import '../../../../core/app_text.dart'; 
import '../onboarding_controller.dart';
import 'common_button.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
 import 'package:flutter/material.dart';
import 'package:get/get.dart';

 
import 'onboarding_screen3.dart';

class OnboardingScreen2 extends StatefulWidget {
  @override
  _OnboardingScreen2State createState() => _OnboardingScreen2State();
}

class _OnboardingScreen2State extends State<OnboardingScreen2> {
  bool callLogs = false;
  bool appOverlay = false;
  bool storage = false;
  bool notifications = false;

  void _allowAll() {
    setState(() {
      callLogs = true;
      appOverlay = true;
      storage = true;
      notifications = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Align(
                alignment: Alignment.topRight,
                child: TextButton(
                  onPressed: () => Get.offAllNamed('/home'),
                  child: Text('Skip', style: TextStyle(color: AppColors.primary)),
                ),
              ),
              SizedBox(height: 12),
              Row(
                children: [
                  Container(
                    height: 6,
                    width: 30,
                    decoration: BoxDecoration(
                      color: AppColors.primary,
                      borderRadius: BorderRadius.circular(3),
                    ),
                  ),
                  SizedBox(width: 8),
                  Container(
                    height: 6,
                    width: 6,
                    decoration: BoxDecoration(
                      color: AppColors.primary.withOpacity(0.3),
                      shape: BoxShape.circle,
                    ),
                  ),
                  SizedBox(width: 8),
                  Container(
                    height: 6,
                    width: 6,
                    decoration: BoxDecoration(
                      color: AppColors.primary.withOpacity(0.3),
                      shape: BoxShape.circle,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 24),
              Text('App Permissions', style: textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
              SizedBox(height: 8),
              Text(
                'To work correctly, CallTrack needs a few permissions. Your data is always secure and private.',
                style: textTheme.bodyMedium,
              ),
              SizedBox(height: 24),

              Expanded(
                child: ListView(
                  physics: NeverScrollableScrollPhysics(),
                  children: [
                    _permissionTile(
                      icon: Icons.call,
                      title: 'Call Logs',
                      subtitle: 'To track and analyze calls.',
                      value: callLogs,
                      onChanged: (val) => setState(() => callLogs = val),
                    ),
                    SizedBox(height: 12),
                    _permissionTile(
                      icon: Icons.layers,
                      title: 'App Overlay',
                      subtitle: 'For caller ID popups.',
                      value: appOverlay,
                      onChanged: (val) => setState(() => appOverlay = val),
                    ),
                    SizedBox(height: 12),
                    _permissionTile(
                      icon: Icons.folder,
                      title: 'Storage',
                      subtitle: 'To save call recordings.',
                      value: storage,
                      onChanged: (val) => setState(() => storage = val),
                    ),
                    SizedBox(height: 12),
                    _permissionTile(
                      icon: Icons.notifications,
                      title: 'Notifications',
                      subtitle: 'For call reminders.',
                      value: notifications,
                      onChanged: (val) => setState(() => notifications = val),
                    ),
                  ],
                ),
              ),

              SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton(
                  onPressed: () => _allowAll(),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primary,
                    foregroundColor: Colors.black,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: Text('Allow All'),
                ),
              ),
              SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton(
                  onPressed: () => Get.to(() => OnboardingScreen3()),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primary,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: Text('Continue'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _permissionTile({
    required IconData icon,
    required String title,
    required String subtitle,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: AppColors.backgroundLight,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Icon(icon, color: AppColors.primary, size: 28),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: TextStyle(fontWeight: FontWeight.w600)),
                SizedBox(height: 2),
                Text(subtitle, style: TextStyle(color: Colors.grey[600], fontSize: 13)),
              ],
            ),
          ),
          Switch(
            activeColor: AppColors.primary,
            value: value,
            onChanged: onChanged,
          )
        ],
      ),
    );
  }
}

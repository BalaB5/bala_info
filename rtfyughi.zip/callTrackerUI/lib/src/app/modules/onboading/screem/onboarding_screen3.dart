import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../core/app_colors.dart'; 
import '../onboarding_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

 

class OnboardingScreen3 extends StatefulWidget {
  @override
  _OnboardingScreen3State createState() => _OnboardingScreen3State();
}

class _OnboardingScreen3State extends State<OnboardingScreen3> {
  bool is12Hour = true;
  double fontSize = 14;
  String timezone = 'GMT-5:00';
  String language = 'English (US)';

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Align(
                alignment: Alignment.topRight,
                child: TextButton(
                  onPressed: () => Get.offAllNamed('/home'),
                  child: Text('Skip', style: TextStyle(color: AppColors.primary)),
                ),
              ),
              SizedBox(height: 12),
              Row(
                children: [
                  Container(
                    height: 6,
                    width: 30,
                    decoration: BoxDecoration(
                      color: AppColors.primary,
                      borderRadius: BorderRadius.circular(3),
                    ),
                  ),
                  SizedBox(width: 8),
                  Container(
                    height: 6,
                    width: 30,
                    decoration: BoxDecoration(
                      color: AppColors.primary,
                      borderRadius: BorderRadius.circular(3),
                    ),
                  ),
                  SizedBox(width: 8),
                  Container(
                    height: 6,
                    width: 6,
                    decoration: BoxDecoration(
                      color: AppColors.primary.withOpacity(0.3),
                      shape: BoxShape.circle,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 24),
              Text('App Settings', style: textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
              SizedBox(height: 8),
              Text(
                'Customize your experience. These settings can be changed later.',
                style: textTheme.bodyMedium,
              ),
              SizedBox(height: 24),

              // Time Format Card
              Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.card,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Time Format', style: TextStyle(fontWeight: FontWeight.w600)),
                    SizedBox(height: 4),
                    Text('Choose 12-hour or 24-hour format.', style: TextStyle(color: Colors.grey[600], fontSize: 13)),
                    SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () => setState(() => is12Hour = true),
                            style: OutlinedButton.styleFrom(
                              backgroundColor: is12Hour ? AppColors.primary : null,
                              foregroundColor: is12Hour ? Colors.white : Colors.black,
                              side: BorderSide(color: AppColors.primary),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                            ),
                            child: Text('12-hour'),
                          ),
                        ),
                        SizedBox(width: 12),
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () => setState(() => is12Hour = false),
                            style: OutlinedButton.styleFrom(
                              backgroundColor: !is12Hour ? AppColors.primary : null,
                              foregroundColor: !is12Hour ? Colors.white : Colors.black,
                              side: BorderSide(color: AppColors.primary),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                            ),
                            child: Text('24-hour'),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              SizedBox(height: 16),

              // Timezone Card
              _settingsTile(
                icon: Icons.access_time,
                title: 'Timezone',
                subtitle: 'Select your local timezone.',
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(timezone, style: TextStyle(color: Colors.grey[600])),
                    Icon(Icons.chevron_right, color: Colors.grey[600]),
                  ],
                ),
                onTap: () {
                  // Placeholder for timezone picker
                },
              ),

              SizedBox(height: 16),

              // Language Card
              _settingsTile(
                icon: Icons.language,
                title: 'Language',
                subtitle: 'Choose your preferred language.',
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(language, style: TextStyle(color: Colors.grey[600])),
                    Icon(Icons.chevron_right, color: Colors.grey[600]),
                  ],
                ),
                onTap: () {
                  // Placeholder for language picker
                },
              ),

              SizedBox(height: 16),

              // Font Size Card
              Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.card,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Font Size', style: TextStyle(fontWeight: FontWeight.w600)),
                    SizedBox(height: 4),
                    Text('Adjust text size for better readability.', style: TextStyle(color: Colors.grey[600], fontSize: 13)),
                    SizedBox(height: 12),
                    Slider(
                      value: fontSize,
                      min: 12,
                      max: 20,
                      divisions: 8,
                      label: fontSize == 14 ? 'Default' : fontSize.round().toString(),
                      onChanged: (value) {
                        setState(() {
                          fontSize = value;
                        });
                      },
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Small', style: TextStyle(fontSize: 12, color: Colors.grey[600])),
                        Text('Default', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
                        Text('Large', style: TextStyle(fontSize: 16, color: Colors.grey[600])),
                      ],
                    )
                  ],
                ),
              ),

              Spacer(),

              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton(
                  onPressed: () => Get.offAllNamed('/home'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primary,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: Text('Finish Setup'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _settingsTile({
    required IconData icon,
    required String title,
    required String subtitle,
    required Widget trailing,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: AppColors.backgroundLight,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            Icon(icon, color: AppColors.primary),
            SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: TextStyle(fontWeight: FontWeight.w600)),
                  SizedBox(height: 2),
                  Text(subtitle, style: TextStyle(color: Colors.grey[600], fontSize: 13)),
                ],
              ),
            ),
            trailing,
          ],
        ),
      ),
    );
  }
}

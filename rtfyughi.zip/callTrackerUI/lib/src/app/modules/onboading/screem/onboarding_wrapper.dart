import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../onboarding_controller.dart';
import 'onboarding_screen1.dart';
import 'onboarding_screen2.dart';
import 'onboarding_screen3.dart';
// import 'onboarding_screen3.dart';

class OnboardingFlow extends StatelessWidget {
  final controller = Get.put(OnboardingController());

  OnboardingFlow({super.key});

  final screens = [
    const OnboardingScreen1(),
      OnboardingScreen2(),
      OnboardingScreen3(),
  ];

  @override
  Widget build(BuildContext context) {
    return Obx(
      () => screens[controller.currentPage.value],
    );
  }
}
import 'package:get/get.dart';

class OnboardingController extends GetxController {
  var currentPage = 0.obs;

  void nextPage() {
    if (currentPage < 2) {
      currentPage++;
    }
  }

  void skip() {
    currentPage.value = 2;
  }

  void setPage(int index) {
    currentPage.value = index;
  }
}

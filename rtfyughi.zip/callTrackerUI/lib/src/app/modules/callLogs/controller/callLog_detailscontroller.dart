// lib/modules/call_details/controller/call_details_controller.dart
import 'package:get/get.dart';

class CallDetailsController extends GetxController {
  final contact = {
    "name": "Eleanor Vance",
    "company": "Innovate Inc.",
    "phone": "+1 (555) 123-4567",
    "image":
        "https://lh3.googleusercontent.com/aida-public/AB6AXuBrdw_52nYPkOU_ctQ9MhL0T7jkaVm3gpwXCY_VM2Ae67Y8dJMDk0fBSopuLV6VdXgPVc8NqoViiX2-g4sVwQ2XqXp7RPV5bSulh8ORGhOd1qmEI1sN4UYzWVaKLRJXxj4EdBBpX6C31KjVItGFRymcDrK6i8XpRxQZ-CNG-HesN1x2G9V0NjaASBenIyFMuX4ctwoFrsWcp0eboG0OLbCcKdgbtx78C_LK2Vs18uMuDFi_sjOo7WOPNWgU3mXfkjST1d-ZR45i8_0V",
    "callType": "Outgoing",
    "iconColor": "green",
    "dateTime": "Oct 26, 2023, 2:45 PM",
    "duration": "5m 32s",
    "notes":
        "Discussed the new product line and potential for a bulk order. Follow-up required next week to finalize the details and pricing.",
    "categories": ["Lead", "Follow-up", "Q4-Pipeline"],
  }.obs;
}

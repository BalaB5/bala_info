// lib/modules/call_logs/view/call_logs_screen.dart
import 'package:calltrackerui/src/app/modules/callLogs/controller/callLogcontroller.dart';
import 'package:calltrackerui/src/app/modules/callLogs/views/screens/callLogdetailscreen.dart';
import 'package:calltrackerui/src/core/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class CallLogsScreen extends GetView<CallLogsController> {
  const CallLogsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context).textTheme;

    return Scaffold(
      backgroundColor: AppColors.background,
      floatingActionButton: FloatingActionButton(
        onPressed: () {},
        backgroundColor: AppColors.primary,
        child: const Icon(Icons.add_call, color: Colors.white, size: 28),
      ),
      body: SafeArea(
        child: Column(
          children: [
            _appBar(theme),
            _searchBar(),
            _filterChips(controller),
            Expanded(
              child: Obx(
                () => ListView(
                  physics: const BouncingScrollPhysics(),
                  children: [
                    _sectionHeader("Today"),
                    ...controller.filteredToday
                        .map((e) => _callItem(e, theme))
                        .toList(),
                    _sectionHeader("Yesterday"),
                    ...controller.filteredYesterday
                        .map((e) => _callItem(e, theme))
                        .toList(),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _appBar(TextTheme theme) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            "Call Logs",
            style: theme.titleLarge?.copyWith(
              fontWeight: FontWeight.bold,
              color: AppColors.textPrimary,
            ),
          ),
         
        ],
      ),
    );
  }

  Widget _searchBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              decoration: InputDecoration(
                hintText: "Search by name or number...",
                prefixIcon: const Icon(Icons.search, color: AppColors.textSecondary),
                filled: true,
                fillColor: AppColors.card,
                contentPadding: const EdgeInsets.symmetric(vertical: 12),
                enabledBorder: OutlineInputBorder(
                  borderSide: const BorderSide(color: AppColors.border),
                  borderRadius: BorderRadius.circular(12),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: const BorderSide(color: AppColors.primary),
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),
          SizedBox(width: 10,),
           Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: AppColors.card,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: AppColors.textSecondary.withOpacity(0.1),
                  blurRadius: 4,
                ),
              ],
            ),
            child: const Icon(Icons.tune, color: AppColors.textPrimary),
          ),
        ],
      ),
    );
  }

  Widget _filterChips(CallLogsController controller) {
    return Obx(
      () => SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        child: Row(
          children: [
            _chip(controller, "All", CallFilter.all, AppColors.primary),
            _chip(
              controller,
              "Incoming",
              CallFilter.incoming,
              AppColors.secondary,
              Icons.south_west,
            ),
            _chip(
              controller,
              "Outgoing",
              CallFilter.outgoing,
              AppColors.primary,
              Icons.north_east,
            ),
            _chip(
              controller,
              "Missed",
              CallFilter.missed,
              AppColors.danger,
              Icons.call_missed,
            ),
          ],
        ),
      ),
    );
  }

  Widget _chip(
    CallLogsController controller,
    String label,
    CallFilter type,
    Color color, [
    IconData? icon,
  ]) {
    final bool active = controller.selectedFilter.value == type;
    return GestureDetector(
      onTap: () => controller.changeFilter(type),
      child: Container(
        margin: const EdgeInsets.only(right: 10),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: active ? color : AppColors.card,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          children: [
            if (icon != null)
              Icon(icon, color: active ? Colors.white : color, size: 18),
            if (icon != null) const SizedBox(width: 6),
            Text(
              label,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: active ? Colors.white : AppColors.textPrimary,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.bold,
          color: AppColors.textPrimary,
        ),
      ),
    );
  }

  Widget _callItem(Map<String, dynamic> call, TextTheme theme) {
    final CallFilter type = call["type"];
    final icon = switch (type) {
      CallFilter.incoming => Icons.south_west,
      CallFilter.outgoing => Icons.north_east,
      CallFilter.missed => Icons.call_missed,
      _ => Icons.call,
    };
    final color = switch (type) {
      CallFilter.incoming => AppColors.secondary,
      CallFilter.outgoing => AppColors.primary,
      CallFilter.missed => AppColors.danger,
      _ => AppColors.textSecondary,
    };

    return GestureDetector(
      onTap: () {
        Get.to(CallDetailsScreen());
      },
      child: Container(
        color: AppColors.card,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.1),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(icon, color: color, size: 22),
                ),
                const SizedBox(width: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      call["name"],
                      style: theme.bodyLarge?.copyWith(
                        fontWeight: FontWeight.w600,
                        color: type == CallFilter.missed
                            ? AppColors.danger
                            : AppColors.textPrimary,
                      ),
                    ),
                    Text(
                      "${call["number"]}${call["duration"].isNotEmpty ? " • ${call["duration"]}" : ""}",
                      style: theme.bodySmall?.copyWith(
                        color: AppColors.textSecondary,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            Text(
              call["time"],
              style: theme.bodySmall?.copyWith(color: AppColors.textSecondary),
            ),
          ],
        ),
      ),
    );
  }
}

// lib/modules/call_details/view/call_details_screen.dart
import 'package:calltrackerui/src/app/modules/callLogs/controller/callLog_detailscontroller.dart';
import 'package:calltrackerui/src/core/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class CallDetailsScreen extends GetView<CallDetailsController> {
  const CallDetailsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final data = controller.contact;
    final theme = Theme.of(context).textTheme;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            _topAppBar(theme),
            Expanded(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    _contactCard(data, theme),
                    const SizedBox(height: 16),
                    _callMetaCard(data, theme),
                    const SizedBox(height: 16),
                    _notesCard(data, theme),
                    const SizedBox(height: 16),
                    _categoriesCard(data, theme),
                  ],
                ),
              ),
            ),
            _actionBar(),
          ],
        ),
      ),
    );
  }

  // 🔹 App Bar
  Widget _topAppBar(TextTheme theme) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: AppColors.card,
        border: Border(
          bottom: BorderSide(color: AppColors.border.withOpacity(0.5)),
        ),
      ),
      child: Row(
        children: [
          InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: () => Get.back(),
            child: const Padding(
              padding: EdgeInsets.all(6.0),
              child: Icon(
                Icons.arrow_back_ios_new,
                color: AppColors.textPrimary,
                size: 22,
              ),
            ),
          ),
          const Spacer(),
          Text(
            "Call Details",
            style: theme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
              color: AppColors.textPrimary,
            ),
          ),
          const Spacer(),
          Text(
            "Edit",
            style: theme.bodyMedium?.copyWith(
              color: AppColors.primary,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  // 🔹 Contact Information Card
  Widget _contactCard(RxMap<String, dynamic> data, TextTheme theme) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 32,
                backgroundImage: NetworkImage(data['image']),
              ),
              const SizedBox(width: 14),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    data['name'],
                    style: theme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  Text(
                    data['company'],
                    style: theme.bodyMedium?.copyWith(
                      color: AppColors.textSecondary,
                    ),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            data['phone'],
            style: theme.bodyMedium?.copyWith(
              color: AppColors.textSecondary,
              fontSize: 16,
            ),
          ),
        ],
      ),
    );
  }

  // 🔹 Call Metadata
  Widget _callMetaCard(RxMap<String, dynamic> data, TextTheme theme) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: [
          _metaItem(
            Icons.call_made,
            "Call Type",
            data['callType'],
            color: Colors.green,
            theme: theme,
          ),
          const Divider(color: AppColors.border, height: 1),
          _metaItem(
            Icons.calendar_today,
            "Date & Time",
            data['dateTime'],
            theme: theme,
          ),
          const Divider(color: AppColors.border, height: 1),
          _metaItem(
            Icons.hourglass_top,
            "Duration",
            data['duration'],
            theme: theme,
          ),
        ],
      ),
    );
  }

  Widget _metaItem(
    IconData icon,
    String label,
    String value, {
    Color? color,
    required TextTheme theme,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(
        children: [
          Icon(icon, color: color ?? AppColors.textSecondary, size: 22),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: theme.bodySmall?.copyWith(
                    color: AppColors.textSecondary,
                  ),
                ),
                Text(
                  value,
                  style: theme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w500,
                    color: AppColors.textPrimary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // 🔹 Notes
  Widget _notesCard(RxMap<String, dynamic> data, TextTheme theme) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Notes",
            style: theme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            data['notes'],
            style: theme.bodyMedium?.copyWith(
              color: AppColors.textPrimary,
              height: 1.5,
            ),
          ),
        ],
      ),
    );
  }

  // 🔹 Categories
  Widget _categoriesCard(RxMap<String, dynamic> data, TextTheme theme) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Categories",
                style: theme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: AppColors.textPrimary,
                ),
              ),
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  color: AppColors.primary.withOpacity(0.15),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.add,
                  color: AppColors.primary,
                  size: 20,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: (data['categories'] as List<String>)
                .map(
                  (e) => Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 6,
                    ),
                    decoration: BoxDecoration(
                      color: _chipColor(e),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      e,
                      style: theme.bodySmall?.copyWith(
                        fontWeight: FontWeight.w600,
                        color: _chipTextColor(e),
                      ),
                    ),
                  ),
                )
                .toList(),
          ),
        ],
      ),
    );
  }

  Color _chipColor(String label) {
    switch (label) {
      case "Lead":
        return Colors.blue.shade100;
      case "Follow-up":
        return Colors.orange.shade100;
      case "Q4-Pipeline":
        return Colors.green.shade100;
      default:
        return AppColors.card;
    }
  }

  Color _chipTextColor(String label) {
    switch (label) {
      case "Lead":
        return Colors.blue.shade800;
      case "Follow-up":
        return Colors.orange.shade800;
      case "Q4-Pipeline":
        return Colors.green.shade800;
      default:
        return AppColors.textPrimary;
    }
  }

  // 🔹 Bottom Action Bar
  Widget _actionBar() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.card,
        border: Border(
          top: BorderSide(color: AppColors.border.withOpacity(0.5)),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
                shape: const StadiumBorder(),
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              onPressed: () {},
              icon: const Icon(Icons.call, color: Colors.white),
              label: const Text(
                "Call Back",
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: OutlinedButton.icon(
              style: OutlinedButton.styleFrom(
                backgroundColor: AppColors.primary.withOpacity(0.1),
                shape: const StadiumBorder(),
                side: BorderSide.none,
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              onPressed: () {},
              icon: const Icon(Icons.message, color: AppColors.primary),
              label: const Text(
                "Message",
                style: TextStyle(
                  color: AppColors.primary,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

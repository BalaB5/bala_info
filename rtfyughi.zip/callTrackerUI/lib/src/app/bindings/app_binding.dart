import 'package:calltrackerui/src/app/modules/bottom/controller/bottom_controller.dart';
import 'package:calltrackerui/src/app/modules/callLogs/controller/callLog_detailscontroller.dart';
import 'package:calltrackerui/src/app/modules/callLogs/controller/callLogcontroller.dart';
import 'package:calltrackerui/src/app/modules/dashboard/controller/dashboard_controller.dart';
import 'package:get/get.dart';

import '../modules/bottombar/contoller/bottombar_contoller.dart';
import '../modules/onboading/onboarding_controller.dart';

class AppBinding implements Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => BottomNavController(), fenix: true);
    Get.lazyPut(() => DashboardController(), fenix: true);
    Get.lazyPut(() => CallLogsController(), fenix: true);
    Get.lazyPut(() => OnboardingController(), fenix: true);
    Get.lazyPut(() => BottomBarContoller(), fenix: true);
    Get.lazyPut(() => CallDetailsController(), fenix: true);
  }
}

import 'package:calltrackerui/src/app/bindings/app_binding.dart';
import 'package:calltrackerui/src/app/modules/bottom/views/screens/bottom_screen.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'src/app/modules/bottombar/views/screens/home.dart';
import 'src/app/modules/onboading/screem/onboarding_wrapper.dart';

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      home: Home(),
      debugShowCheckedModeBanner: false,
      initialBinding: AppBinding(),
    );
  }
}

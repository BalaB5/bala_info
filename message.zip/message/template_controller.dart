import 'package:call_tracker/src/app/modules/message/message.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'dart:io';

import 'package:image_picker/image_picker.dart';
import 'package:url_launcher/url_launcher.dart';

class TemplateControlle2 extends GetxController {
  final TemplateRepository repository = Get.find();

  // TemplateController({required this.repository});

  // Form fields
  final titleController = TextEditingController();
  final messageController = TextEditingController();

  final FocusNode focusNode = FocusNode();
  RxBool isActive = false.obs;

  // Observables
  final isLoading = false.obs;
  final templates = <TemplateModel>[].obs;
  final selectedImage = Rx<File?>(null);
  final titleError = RxString('');
  final messageError = RxString('');
  final isFormValid = false.obs;

  // Available placeholders
  final List<Map<String, String>> placeholders = [
    {'label': 'Name', 'value': '#name'},
    {'label': 'Address', 'value': '#address'},
    {'label': 'my name', 'value': '#my_name'},
    {'label': 'Phone', 'value': '#phone'},
    {'label': 'Email', 'value': '#email'},
  ];

  // Available text styles
  final List<Map<String, dynamic>> textStyles = [
    {'label': 'Bold', 'icon': Icons.format_bold, 'style': '*'},
    {'label': 'Italic', 'icon': Icons.format_italic, 'style': '_'},
    {'label': 'Underline', 'icon': Icons.format_underlined, 'style': '~'},
  ];

  @override
  void onInit() {
    super.onInit();
    loadTemplates() ;
    titleController.addListener(validateForm);
    messageController.addListener(validateForm);
    focusNode.addListener(() {
      isActive.value = focusNode.hasFocus;
    });
  }

  @override
  void onClose() {
    titleController.dispose();
    messageController.dispose();
    focusNode.dispose();
    super.onClose();
  }

  void validateForm() {
    if (titleController.text.isEmpty) {
      titleError.value = 'template_validation_title_required'.tr;
    } else if (titleController.text.length < 3) {
      titleError.value = 'template_validation_title_min'.tr;
    } else {
      titleError.value = '';
    }

    if (messageController.text.isEmpty) {
      messageError.value = 'template_validation_message_required'.tr;
    } else if (messageController.text.length < 5) {
      messageError.value = 'template_validation_message_min'.tr;
    } else {
      messageError.value = '';
    }

    isFormValid.value =
        titleError.value.isEmpty &&
        messageError.value.isEmpty &&
        titleController.text.isNotEmpty &&
        messageController.text.length >= 5;
  }

  Future<void> pickImage() async {
    try {
      final ImagePicker picker = ImagePicker();
      final XFile? image = await picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 800,
        maxHeight: 800,
        imageQuality: 80,
      );

      if (image != null) {
        selectedImage.value = File(image.path);
      }
    } catch (e) {
      // Get.showSnackBar(
      //   GetSnackBar(
      //     message: 'Failed to pick image: $e',
      //     duration: const Duration(seconds: 3),
      //     backgroundColor: Colors.red,
      //   ),
      // );
    }
  }

  void removeImage() {
    selectedImage.value = null;
  }

  void insertPlaceholder(String placeholder) {
    final text = messageController.text;
    final selection = messageController.selection;

    final newText = text.replaceRange(
      selection.start,
      selection.end,
      placeholder,
    );

    messageController.text = newText;
    final newPosition = selection.start + placeholder.length;
    messageController.selection = TextSelection.collapsed(offset: newPosition);
    validateForm();
  }

  void applyTextStyle(String style) {
    final text = messageController.text;
    final selection = messageController.selection;

    if (selection.isValid && selection.isCollapsed) {
      final newText = text.replaceRange(
        selection.start,
        selection.start,
        '$style$style',
      );
      messageController.text = newText;
      messageController.selection = TextSelection.collapsed(
        offset: selection.start + 1,
      );
    } else if (selection.isValid) {
      final selectedText = text.substring(selection.start, selection.end);
      final newText = text.replaceRange(
        selection.start,
        selection.end,
        '$style$selectedText$style',
      );
      messageController.text = newText;
      messageController.selection = TextSelection.collapsed(
        offset: selection.end + 2,
      );
    }
    validateForm();
  }

  Future<void> saveTemplate() async {
    if (!isFormValid.value) return;

    try {
      isLoading.value = true;

      final template = TemplateModel(
        title: titleController.text.trim(),
        message: messageController.text.trim(),
        localImagePath: selectedImage.value?.path,
      );

      await repository.createTemplate(template);

      isLoading.value = false;
      selectedImage.value = null;

      // Get.showSnackBar(
      //   GetSnackBar(
      //     message: 'template_save_success'.tr,
      //     duration: const Duration(seconds: 2),
      //     backgroundColor: Colors.green,
      //   ),
      // );

      Get.back(result: true);
    } catch (e) {
      isLoading.value = false;

      // Get.showSnackBar(
      //   GetSnackBar(
      //     message: 'template_save_error'.trParams({'error': e.toString()}),
      //     duration: const Duration(seconds: 3),
      //     backgroundColor: Colors.red,
      //   ),
      // );
    }
  }

  Future<void> loadTemplates() async {
    try {
      isLoading.value = true;
      final fetchedTemplates = await repository.getTemplates();
      templates.assignAll(fetchedTemplates);
      isLoading.value = false;
    } catch (e) {
      isLoading.value = false;
      // Get.showSnackBar(
      //   GetSnackBar(
      //     message: 'Failed to load templates: $e',
      //     duration: const Duration(seconds: 3),
      //     backgroundColor: Colors.red,
      //   ),
      // );
    }
  }

  Future<void> deleteTemplate(String templateId) async {
    try {
      await repository.deleteTemplate(templateId);
      templates.removeWhere((template) => template.id == templateId);
      // Get.showSnackBar(
      //   GetSnackBar(
      //     message: 'Template deleted successfully',
      //     duration: const Duration(seconds: 2),
      //     backgroundColor: Colors.green,
      //   ),
      // );
    } catch (e) {
      // Get.showSnackBar(
      //   GetSnackBar(
      //     message: 'Failed to delete template: $e',
      //     duration: const Duration(seconds: 3),
      //     backgroundColor: Colors.red,
      //   ),
      // );
    }
  }

  Future<void> shareToWhatsApp(TemplateModel template) async {
    String message = template.message;

    // You can use whatsapp_share2 package or url_launcher
    // For now, we'll just show a toast
    // Get.showSnackBar(
    //   GetSnackBar(
    //     message: 'Sharing to WhatsApp: ${template.title}',
    //     duration: const Duration(seconds: 2),
    //     backgroundColor: Colors.green,
    //   ),
    // );

    // Example with url_launcher:
    final url = "https://wa.me/?text=${Uri.encodeComponent(message)}";
    if (await canLaunchUrl(Uri.parse(url))) {
      await launchUrl(Uri.parse(url));
    }
  }

  void clearForm() {
    titleController.clear();
    messageController.clear();
    selectedImage.value = null;
    titleError.value = '';
    messageError.value = '';
    isFormValid.value = false;
  }

  void editTemplate(TemplateModel template) {
    titleController.text = template.title;
    messageController.text = template.message;
    // For editing, you might want to navigate to edit screen
    Get.toNamed('/whatsapp-template/edit', arguments: template);
  }
}

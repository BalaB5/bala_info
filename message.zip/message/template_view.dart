import 'package:call_tracker/src/app/widgets/input_card_style.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../widgets/lable_text.dart';
import 'template_controller.dart';

class TemplateView extends GetView<TemplateControlle2> {
  const TemplateView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Get.back(),
        ),
        title: Text('template_title'.tr),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 8,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildImageField(),
                    const SizedBox(height: 16),
                    _buildTitleField(),
                    const SizedBox(height: 16),
                    _buildMessageField(),
                    // const SizedBox(height: 24),
                    // _buildStyleOptions(),
                  ],
                ),
              ),
            ),
            _buildSaveButton(),
          ],
        ),
      ),
      bottomSheet: _buildPlaceholderBar(),
    );
  }
  // Add this widget to the TemplateView after _buildTitleField()

  Widget _buildImageField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Text(
        //   'template_field_image'.tr,
        //   style: Get.textTheme.titleMedium?.copyWith(
        //     fontWeight: FontWeight.w500,
        //   ),
        // ),
        // const SizedBox(height: 8),
        Obx(() {
          if (controller.selectedImage.value != null) {
            return Stack(
              children: [
                Container(
                  height: 150,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    image: DecorationImage(
                      image: FileImage(controller.selectedImage.value!),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                Positioned(
                  right: 5,
                  top: 5,
                  child: CircleAvatar(
                    child: IconButton(
                      onPressed: controller.removeImage,
                      icon: Icon(Icons.delete, color: Colors.red),
                    ),
                  ),
                ),
              ],
            );
          } else {
            return OutlinedButton(
              onPressed: controller.pickImage,
              style: OutlinedButton.styleFrom(
                minimumSize: const Size(double.infinity, 48),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.add_photo_alternate_outlined),
                  const SizedBox(width: 8),
                  Text('template_add_image'.tr),
                ],
              ),
            );
          }
        }),
      ],
    );
  }

  Widget _buildTitleField() {
    return InputCardStyle(
      padding: EdgeInsets.symmetric(horizontal: 8),
      child: TextFormField(
        controller: controller.titleController,
        decoration: InputDecoration(
          // hintText: 'template_hint_title'.tr,
          label: LableText('template_field_title'.tr),
          border: InputBorder.none,
          // errorText:
          //     controller.titleError.value.isNotEmpty
          //         ? controller.titleError.value
          //         : null,
        ),
        validator:
            (value) =>
                value == null || value.trim().isEmpty ? 'Required field' : null,
        // maxLength: 100,
        textInputAction: TextInputAction.next,
      ),
    );
  }

  Widget _buildMessageField() {
    return InputCardStyle(
      padding: EdgeInsets.symmetric(horizontal: 8),
      child: Column(
        children: [
          TextFormField(
            focusNode: controller.focusNode,
            controller: controller.messageController,
            decoration: InputDecoration(
              label: LableText('template_field_message'.tr),

              border: InputBorder.none,
              // errorText:
              //     controller.messageError.value.isNotEmpty
              //         ? controller.messageError.value
              //         : null,
              contentPadding: const EdgeInsets.all(16),
            ),
            maxLines: 6,
            // maxLength: 1000,
            textInputAction: TextInputAction.newline,
          ),
          Container(
            // padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              // color: Get.theme.colorScheme.surfaceVariant.withOpacity(0.3),
              // borderRadius: BorderRadius.circular(8),
              // border: Border.all(
              //   color: Get.theme.colorScheme.outline.withOpacity(0.2),
              // ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children:
                  controller.textStyles.map((style) {
                    return IconButton(
                      icon: Icon(style['icon'] as IconData),
                      onPressed:
                          () => controller.applyTextStyle(
                            style['style'] as String,
                          ),
                      tooltip: style['label'] as String,
                    );
                  }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStyleOptions() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'template_style_options'.tr,
          style: Get.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Get.theme.colorScheme.surfaceVariant.withOpacity(0.3),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: Get.theme.colorScheme.outline.withOpacity(0.2),
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children:
                controller.textStyles.map((style) {
                  return IconButton(
                    icon: Icon(style['icon'] as IconData),
                    onPressed:
                        () =>
                            controller.applyTextStyle(style['style'] as String),
                    tooltip: style['label'] as String,
                  );
                }).toList(),
          ),
        ),
      ],
    );
  }

  Widget _buildPlaceholderBar() {
    return controller.isActive.value
        ? Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Get.theme.colorScheme.surface,
            border: Border(
              top: BorderSide(
                color: Get.theme.colorScheme.outline.withOpacity(0.2),
              ),
            ),
          ),
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children:
                  controller.placeholders.map((placeholder) {
                    return Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      child: InputChip(
                        label: Text(placeholder['label']!),
                        onPressed:
                            () => controller.insertPlaceholder(
                              placeholder['value']!,
                            ),
                        backgroundColor: Get.theme.colorScheme.surfaceVariant,
                      ),
                    );
                  }).toList(),
            ),
          ),
        )
        : SizedBox();
  }

  Widget _buildSaveButton() {
    return Obx(() {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16),
        child: ElevatedButton(
          onPressed:
              controller.isFormValid.value && !controller.isLoading.value
                  ? controller.saveTemplate
                  : null,
          style: ElevatedButton.styleFrom(
            backgroundColor: Get.theme.colorScheme.primary,
            foregroundColor: Get.theme.colorScheme.onPrimary,
            padding: const EdgeInsets.symmetric(vertical: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          ),
          child:
              controller.isLoading.value
                  ? SizedBox(
                    height: 20,
                    width: 20,
                    child: CircularProgressIndicator(
                      color: Get.theme.colorScheme.onPrimary,
                      strokeWidth: 2,
                    ),
                  )
                  : Text(
                    'template_button_save'.tr,
                    style: Get.textTheme.labelLarge?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
        ),
      );
    });
  }
}

import 'package:get/get.dart';

import 'message.dart';
import 'template_controller.dart';

class TemplateBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<TemplateRepository>(() => TemplateRepository(
    
    ));
    
    Get.lazyPut<TemplateControlle2>(() => TemplateControlle2(
     
    ));
  }
}

import 'package:get/get.dart';

import '../../utils/http/http_service.dart';

//    GetPage(
//   name: '/whatsapp-templates',
//   page: () => const TemplateListView(),
//   binding: TemplateBinding(),
// ),
// GetPage(
//   name: '/whatsapp-template/create',
//   page: () => const TemplateView(),
//   binding: TemplateBinding(),
// ),


class TemplateModel {
  final String? id;
  final String title;
  final String message;
  final String? imageUrl;
  final String? localImagePath;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  TemplateModel({
    this.id,
    required this.title,
    required this.message,
    this.imageUrl,
    this.localImagePath,
    this.createdAt,
    this.updatedAt,
  });

  factory TemplateModel.fromJson(Map<String, dynamic> json) {
    return TemplateModel(
      id: json['id'],
      title: json['title'],
      message: json['message'],
      imageUrl: json['imageUrl'],
      localImagePath: json['localImagePath'],
      createdAt: json['createdAt'] != null ? DateTime.parse(json['createdAt']) : null,
      updatedAt: json['updatedAt'] != null ? DateTime.parse(json['updatedAt']) : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      if (id != null) 'id': id,
      'title': title,
      'message': message,
      if (imageUrl != null) 'imageUrl': imageUrl,
      if (localImagePath != null) 'localImagePath': localImagePath,
      if (createdAt != null) 'createdAt': createdAt!.toIso8601String(),
      if (updatedAt != null) 'updatedAt': updatedAt!.toIso8601String(),
    };
  }

  TemplateModel copyWith({
    String? id,
    String? title,
    String? message,
    String? imageUrl,
    String? localImagePath,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return TemplateModel(
      id: id ?? this.id,
      title: title ?? this.title,
      message: message ?? this.message,
      imageUrl: imageUrl ?? this.imageUrl,
      localImagePath: localImagePath ?? this.localImagePath,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}

class TemplateRepository extends GetxService {
  final HttpService httpService =Get.find();

  // TemplateRepository({required this.httpService});

  // Get all templates
  Future<List<TemplateModel>> getTemplates() async {
    try {
      await Future.delayed(const Duration(seconds: 1));
      
      // Mock templates list
      final mockResponse = {
        'status': true,
        'message': 'Templates fetched successfully',
        'data': [
          {
            'id': '1',
            'title': 'Welcome Message',
            'message': 'Hello #name, welcome to our service!',
            'imageUrl': null,
            'createdAt': '2024-01-15T10:30:00Z',
            'updatedAt': '2024-01-15T10:30:00Z',
          },
          {
            'id': '2', 
            'title': 'Order Confirmation',
            'message': 'Hi #name, your order #order_id has been confirmed.',
            'imageUrl': null,
            'createdAt': '2024-01-16T14:20:00Z',
            'updatedAt': '2024-01-16T14:20:00Z',
          }
        ]
      };
      
      if (mockResponse['status'] == true) {
        return (mockResponse['data'] as List)
            .map((item) => TemplateModel.fromJson(item))
            .toList();
      } else {
        throw Exception(mockResponse['message'] ?? 'Failed to fetch templates');
      }
    } catch (e) {
      throw Exception('Failed to fetch templates: $e');
    }
  }

  Future<TemplateModel> createTemplate(TemplateModel template) async {
    try {
      await Future.delayed(const Duration(seconds: 2));
      
      final mockResponse = {
        'status': true,
        'message': 'Template created successfully',
        'data': {
          'id': 'temp_${DateTime.now().millisecondsSinceEpoch}',
          'title': template.title,
          'message': template.message,
          'imageUrl': template.imageUrl,
          'localImagePath': template.localImagePath,
          'createdAt': DateTime.now().toIso8601String(),
          'updatedAt': DateTime.now().toIso8601String(),
        }
      };
      
      if (mockResponse['status'] == true) {
        return TemplateModel.fromJson(mockResponse['data'] as Map<String, dynamic>);
      } else {
        throw Exception(mockResponse['message'] ?? 'Failed to create template');
      }
    } catch (e) {
      throw Exception('Failed to create template: $e');
    }
  }

  Future<TemplateModel> updateTemplate(TemplateModel template) async {
    try {
      await Future.delayed(const Duration(seconds: 2));
      
      final mockResponse = {
        'status': true,
        'message': 'Template updated successfully',
        'data': {
          'id': template.id,
          'title': template.title,
          'message': template.message,
          'imageUrl': template.imageUrl,
          'localImagePath': template.localImagePath,
          'createdAt': template.createdAt?.toIso8601String(),
          'updatedAt': DateTime.now().toIso8601String(),
        }
      };
      
      if (mockResponse['status'] == true) {
        return TemplateModel.fromJson(mockResponse['data'] as Map<String, dynamic>);
      } else {
        throw Exception(mockResponse['message'] ?? 'Failed to update template');
      }
    } catch (e) {
      throw Exception('Failed to update template: $e');
    }
  }

  Future<bool> deleteTemplate(String templateId) async {
    try {
      await Future.delayed(const Duration(seconds: 1));
      
      final mockResponse = {
        'status': true,
        'message': 'Template deleted successfully',
        'data': null
      };
      
      return mockResponse['status'] == true;
    } catch (e) {
      throw Exception('Failed to delete template: $e');
    }
  }
}
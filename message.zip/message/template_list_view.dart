import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
// import '../controllers/template_controller.dart';
import 'message.dart';
import 'template_controller.dart';

class TemplateListView extends GetView<TemplateControlle2> {
  const TemplateListView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('template_list_title'.tr),
        actions: [
          // IconButton(
          //   icon: const Icon(Icons.add),
          //   onPressed: () => Get.toNamed('/whatsapp-template/create'),
          // ),
        ],
      ),
      body: Obx(() {
        if (controller.isLoading.value && controller.templates.isEmpty) {
          return const Center(child: CircularProgressIndicator());
        }

        if (controller.templates.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.message_outlined,
                  size: 64,
                  color: Get.theme.colorScheme.onSurface.withOpacity(0.3),
                ),
                const SizedBox(height: 16),
                Text(
                  'template_list_empty'.tr,
                  style: Get.textTheme.titleMedium?.copyWith(
                    color: Get.theme.colorScheme.onSurface.withOpacity(0.5),
                  ),
                ),
                // const SizedBox(height: 16),
                // ElevatedButton(
                //   onPressed: () => Get.toNamed('/whatsapp-template/create'),
                //   child: Text('template_create_first'.tr),
                // ),
              ],
            ),
          );
        }

        return RefreshIndicator(
          onRefresh: () => controller.loadTemplates(),
          child: ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: controller.templates.length,
            itemBuilder: (context, index) {
              final template = controller.templates[index];
              return _buildTemplateCard(template);
            },
          ),
        );
      }),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Get.toNamed('/whatsapp-template/create'),
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildTemplateCard(TemplateModel template) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    template.title,
                    style: Get.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                PopupMenuButton<String>(
                  onSelected: (value) => _handleMenuAction(value, template),
                  itemBuilder: (context) => [
                    PopupMenuItem(
                      value: 'share',
                      child: Row(
                        children: [
                          const Icon(Icons.share, size: 20),
                          const SizedBox(width: 8),
                          Text('template_action_share'.tr),
                        ],
                      ),
                    ),
                    PopupMenuItem(
                      value: 'edit',
                      child: Row(
                        children: [
                          const Icon(Icons.edit, size: 20),
                          const SizedBox(width: 8),
                          Text('template_action_edit'.tr),
                        ],
                      ),
                    ),
                    PopupMenuItem(
                      value: 'delete',
                      child: Row(
                        children: [
                          const Icon(Icons.delete, size: 20),
                          const SizedBox(width: 8),
                          Text('template_action_delete'.tr),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
            if (template.localImagePath != null || template.imageUrl != null)
              Padding(
                padding: const EdgeInsets.only(top: 8, bottom: 8),
                child: Container(
                  height: 120,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    image: DecorationImage(
                      image: template.localImagePath != null
                          ? FileImage(File(template.localImagePath!))
                          : NetworkImage(template.imageUrl!) as ImageProvider,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            const SizedBox(height: 8),
            Text(
              template.message,
              style: Get.textTheme.bodyMedium,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
            ),
            // const SizedBox(height: 8)
           
          ],
        ),
      ),
    );
  }

  void _handleMenuAction(String action, TemplateModel template) {
    switch (action) {
      case 'share':
        controller.shareToWhatsApp(template);
        break;
      case 'edit':
        controller.editTemplate(template);
        break;
      case 'delete':
        _showDeleteDialog(template);
        break;
    }
  }

  void _showDeleteDialog(TemplateModel template) {
    Get.dialog(
      AlertDialog(
        title: Text('template_delete_title'.tr),
        content: Text('template_delete_message'.trParams({'title': template.title})),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: Text('template_cancel'.tr),
          ),
          TextButton(
            onPressed: () {
              Get.back();
              controller.deleteTemplate(template.id!);
            },
            style: TextButton.styleFrom(
              foregroundColor: Get.theme.colorScheme.error,
            ),
            child: Text('template_delete'.tr),
          ),
        ],
      ),
    );
  }

  String _formatDate(DateTime? date) {
    if (date == null) return 'Unknown';
    return '${date.day}/${date.month}/${date.year}';
  }
}
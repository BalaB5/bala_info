abstract class Routes {
  // Auth routes
  static const splash = '/splash';
  static const walkthrough = '/walkthrough';
  static const login = '/login';
  static const otp = '/otp';
  static const register = '/register';

  // Main app routes
  static const home = '/home';

  // Land management
  static const addLand = '/add-land';
  static const landDetail = '/land-detail';

  // Crop management
  static const addCrop = '/add-crop';
  static const cropOverview = '/crop-overview';

  // Sales
  static const sales = '/sales';

  //temp
  static const salesDetails = '/sales-details';
  static const newSales = '/new-sales';
  static const addDeduction = '/add-deduction';

  // Expenses
  static const expense = '/expense';

  static const purchaseItems = '/purchaseItems';
  static const addExpense = '/addExpense';

  // Vendor/Customer
  static const vendorCustomer = '/vendor-customer';
  static const addVendorCustomer = '/add-vendor-customer';
  static const vendorCustomerDetails = '/vendor-customer-details';

  // Other features
  static const notification = '/notification';
  static const locationViewer = '/location-viewer';
  static const docViewer = '/document-viewer';
  static const nearMe = '/near-me';
  static const marketList = '/market-list';
  static const placeDetailsList = '/place-list';
  static const workersList = '/man-power-workers';
  static const rentalDetailsList = '/rental-list';

  // Profile
  static const profile = '/profile';
  static const profileEdit = '/profile/edit';

  // Tasks
  static const task = '/task';
  static const taskDetail = '/task-detail';

  // Subscription
  static const subscriptionUsage = '/subscription/usage';
  static const subscriptionPlans = '/subscription/plans';
  static const subscriptionPayment = '/subscription/payment';
  static const paymentSuccess = '/subscription/payment/success';
  static const paymentFailed = '/subscription/payment/failed';

  //
  static const guidelines = '/guidelines';

  //
  static const inventory = '/inventory';

  static const String landEdit = '/land/edit';
  static const String fuelConsumption = '/fuel-consumption';

  static const String landMapView = '/land-map';
}

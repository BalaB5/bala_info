from django.urls import path,include
from api.views import *
from drf_spectacular.views import (
 SpectacularAPIView,
 SpectacularRedocView,
 SpectacularSwaggerView,
)

urlpatterns = [
 
    # path('verify_otp', verify_otp, name='verify_otp'), 
    path('get_id', get_id, name="get_id"),
    path('refresh_access_token', refresh_access_token, name="refresh_access_token"),
    path('countries', country_list, name='country_list'),
    path('states', state_list, name='state_list'), 
    path('cities', city_list, name='city_list'),
    path('taluks', taluk_list, name='taluk_list'),  
    path('villages', village_list, name='village_list'), 
    path('notification_list/<int:id>', notification_list, name='notification_list'),
    path('crop_types', crop_type_list, name='crop_type_list'), 
    path('crops', crop_list, name='get_crops_by_type'),
    path('soil_types', soil_type_list, name='soil_type_list'),
    path('area_units', area_unit_list, name='area_unit_list'),
    path('product_types', product_type_list, name='product_type_list'),
    path('schedules', schedule_list, name='schedule_list'),
    path('land_units', land_unit_list, name='land_unit_list'),
    path('expenses_categories', expenses_category_list, name='expenses_category_list'),
    path('expenses/<int:id>', expenses_list, name='expenses_list'),
    path('expenses/', expenses_list, name='expenses_list'), 
    path('inventory_types', inventory_type_list, name='inventory_type_list'),
    path('inventory_categories', inventory_category_list, name='inventory_category_list'),
    path('inventory_items', inventory_items_list, name='inventory_items_list'),
    path('harvesting_types', harvesting_type_list, name='harvesting_type_list'),
    path('schedule_activity_types', schedule_activity_type_list, name='schedule_activity_type_list'),
    path('detections', detection_list, name='detection_list'),
    path('document_categories', document_category_list, name='document_category_list'),
    path('nearby_location_categories', nearby_location_category_list, name='nearby_location_category_list'),
    path('guidelines_categories', guidelines_category_list, name='guidelines_category_list'),
#     path('add_farmer', manage_farmer, name='add_farmer'),
    path('edit_farmer/<int:id>', manage_farmer, name='edit_farmer'),
    path('delete_farmer/<int:id>', manage_farmer, name='delete_farmer'),
    path('get_farmer/<int:id>', manage_farmer, name='get_farmer'),  
    path('add_my_land/', manage_my_land, name='add_my_land'),
    path('verify-otp/',  verify_otp, name='verify_otp'),
    path('edit_my_land/<int:farmer_id>', update_my_land, name='update_my_land'), 
    path('customers-as-vendors/<int:farmer_id>/', get_customers_as_vendors, name='get_customers_as_vendors'),
    path('get_vendors_customer/<int:farmer_id>/', get_vendors_customer, name='get_vendors_customer'), # try is_customer-is_vendor in MyVendor set afnd filter them 
    path('customers-as-vendors-details/<int:farmer_id>/', get_customers_as_vendors_details, name='get_customers_as_vendors_details'),
    path('customers_and_vendors/<int:farmer_id>', get_customer_vendor_details, name='get_customers_and_vendors_details'),
    path('vendors_and_customers/<int:farmer_id>', get_vendors_and_purchase_details, name='get_vendors_and_purchase_details'),
    path('lands/<int:farmer_id>/', get_farmer_lands, name='get_farmer_lands'),
    # path('lands/with-survey-details/<int:land_id>/', get_land_with_survey_details, name='get_land_with_survey_details'),
    path('lands/with-survey-details/<int:farmer_id>/<int:land_id>/', get_land_with_survey_details, name='get_specific_land_for_farmer'),
    path('lands/geo-marks/<int:farmer_id>/<int:land_id>/',get_land_with_crop_geo_marks_details,name='get_land_with_crop_geo_marks_details'),
    path('add_crop/<int:farmer_id>/', add_crop, name='add_my_crop'),
    path('edit_crop/<int:id>', manage_my_crop, name='add_my_crop'),
    path('delete_crop/<int:id>', delete_my_crop, name='add_my_crop'),
    path('delete_my_land/<int:id>', delete_my_land, name='delete_my_land'), 
    path('get_land_list/<int:id>', get_land_list, name='get_land_list'),
    path('get_land_with_crop_list/<int:id>', get_land_with_crop_list, name='get_land_with_crop_list'),
    path('get_land_details/<int:id>', get_land_details, name='get_land_details'),
    path('manage_my_crop/<int:id>', manage_my_crop, name='manage_my_crop'),
    path('add_customer/<int:id>', manage_customer, name='manage_customer'),
    # path('update_customer_and_vendor/<int:farmer_id>/<int:customer_id>/', update_manage_customer, name='update_customer_and_vendor'),
    # path('update_manage_customer/<int:customer_id>/', update_manage_customer, name='update_manage_customer'),
    path('update_manage_customer/<int:farmer_id>/<int:customer_id>/', update_manage_customer, name='update_manage_customer'),
    path('deactivate_customer_and_vendor/<int:farmer_id>/<int:customer_id>/', deactivate_customer_and_vendor, name='deactivate_customer_and_vendor'),

    path('delete_customer/<int:id>', manage_customer, name='manage_customer'),
    path('delete_customer/<int:id>', delete_customer, name='manage_customer'),
    path('list_customers/<int:id>', list_customers, name='list_customers'),  
    path('customer_details/<int:id>',customer_details, name='customer_details'),
    path('add_vendor/<int:id>',  manage_vendor, name='add_vendor'),
    path('edit_vendor/<int:id>',  manage_vendor, name='edit_vendor'),
    path('delete_vendor/<int:id>',  delete_vendor, name='delete_vendor'),
    path('list_vendors/<int:id>',  list_vendors, name='list_vendors'),
    path('vendor_details/<int:id>',  vendor_details, name='vendor_details'),
    path('list_customers_and_vendors/<int:id>',  list_customers_and_vendors, name='vendor_details'),
    path('get_customer_balances_view/<int:farmer_id>', get_customer_balances_view, name='get_customer_balances_view'),
    path('delete_task/<int:id>', delete_my_schedule, name='add_task'), 
    path('list_market_names',  list_market_names, name='list_market_names'),
    
    path('get_inventory_summary/<int:id>',  get_inventory_summary, name='get_inventory_summary'),
    path('fuel_inventory/<int:id>', get_fuel_inventory_list, name='get_fuel_inventory_list'),
    path('machinery_inventory/<int:id>', get_machinery_inventory_list, name='get_machinery_inventory_list'),
    path('tools_inventory/<int:id>', get_tools_inventory_list, name='get_tools_inventory_list'),
    path('vehicle_inventory/<int:id>', get_vehicle_inventory_list, name='get_vehicle_inventory_list'),
    path('pesticides_inventory/<int:id>', get_pesticide_inventory_list, name='get_pesticides_inventory_list'),
    path('fertilizer_inventory/<int:id>', get_fertilizer_inventory_list, name='get_fertilizer_inventory_list'),
    path('seeds_inventory/<int:id>', get_seed_inventory_list, name='get_seeds_inventory_list'), 
    path('list_consumptions/<int:id>/', list_consumptions, name='list_consumptions'), 
    path('fuel_consumption_items/<int:id>', fuel_consumption_items, name='fuel_consumption_items'), 
    path('vehicle_consumption_items/<int:id>', vehicle_consumption_items, name='vehicle_consumption_items'),
    path('machinery_consumption_items/<int:id>', machinery_consumption_items, name='machinery_consumption_items'),
    path('tools_consumption_items/<int:id>', tools_consumption_items, name='tools_consumption_items'),
    path('pesticides_consumption_items/<int:id>', pesticides_consumption_items, name='pesticides_consumption_items'),
    path('fertilizers_consumption_items/<int:id>', fertilizers_consumption_items, name='fertilizers_consumption_items'),
    path('seeds_consumption_items/<int:id>', seeds_consumption_items, name='seeds_consumption_items'),
    path('add_consumption/<int:id>', manage_consumption, name='add_consumption'),
    path('edit_consumption/<int:id>', manage_consumption, name='edit_consumption'),
    path('delete_consumption/<int:id>', manage_consumption, name='delete_consumption'), 
    path('inventory/<int:inventory_id>/',  get_inventory_and_crop_details, name='inventory_details'),
    path('add_task/<int:id>', add_task, name='add_task'),
    path('get_task_date/<int:id>', get_task_date, name='get_task_date'), 
    path('view_fuel', view_fuel, name='view_fuel'),
    path('get_purchase_expense/<int:farmer_id>', get_purchase_expense, name="get_purchase_expense"),
    path('both_customers_and_vendors/<int:id>',  both_customers_and_vendors, name='both_customers_and_vendors'),
    path('edit_task/<int:id>', update_my_schedule, name='add_task'), 
    path('task_year_list/<int:id>', get_task_list_for_month, name='get_task_list_for_year'),  
    # path('task_year_lists/<int:id>', get_task_list_for_months, name='get_task_list_for_years'),    
    path('get_task_list/<int:id>', get_task_list, name='get_task_list'),
    path('get_task_detail/<int:id>', get_task_detail, name='get_task_detail'),
    path('task_completed/<int:id>',task_completed,name='task_completed'),
    path('lands/monthly-schedules/', monthly_schedules, name='monthly_schedules'),
    path('add_comments/<int:id>', add_comments, name='add_comments'),
    path('get_purchase_list/<int:farmer_id>', get_purchase_list, name="get_purchase_list"), 
    path('view_vehicle', view_vehicle, name='view_vehicle'), 
    path('get_purchase/<int:farmer_id>', get_purchase, name="get_purchase"), 
    # path('get_inventory_items/<int:inventory_category_id>/', get_inventory_items, name='get_inventory_items_by_category'), 
    path('get_inventory_items/<int:inventory_type_id>/', get_inventory_items,
name='get_inventory_items_by_category'),

    path('get_inventory_category/<int:inventory_type_id>', get_inventory_category , name='get_inventory_category'),
    path('get_Expenses',get_Expenses,name="get_Expenses"), 
    path('get_vendor/<int:farmer_id>', get_vendor, name="get_vendor"),
    path('get_customer_list/<int:farmer_id>',get_customer_list,name="get_customer_list"),
    path('get_crop_list',get_crop_list,name="get_crop_list"),
    path('get_kilo_list',get_kilo_list,name="get_kilo_list"),
    path('get_maket_name_list',get_maket_name_list,name="get_maket_name_list"),
    path('get_sales_list/<int:farmer_id>',get_sales_list,name="get_sales_list"), 
    path('add_expense/<int:farmer_id>',add_expense,name="add_expense"), 
    path('edit_purchase/<int:farmer_id>/', edit_purchase, name='edit_purchase'),   
    path('add_fuel/<int:farmer_id>', add_fuel, name="add_fuel"), 
    path('add_vehicle/<int:farmer_id>/',  add_vehicle, name='add_vehicle'), 
    path('add_machinery/<int:farmer_id>',  add_machinery, name='add_machinery'),
    path('add_tools/<int:farmer_id>',add_tools,name="add_tools"),
    path('add_pesticides/<int:farmer_id>',add_pesticides,name="add_pesticides"),
    path('add_fertilizer/<int:farmer_id>',add_fertilizer,name="add_fertilizer"),
    path('add_seeds/<int:farmer_id>',add_seeds,name="add_seeds"), 
    path('add_sales_with_deductions/<int:farmer_id>',add_sales_with_deductions,name="add_sales_with_deductions"),
    # path('update_sales_with_deductions/<int:sales_id>', update_sales_with_deductions, name="update_sales_with_deductions"),
    # path('update_sales_with_deductions/<int:farmer_id>/', update_sales_with_deductions, name='update_sales_with_deductions'),
    path('update_sales_with_deductions/<int:farmer_id>/<int:sale_id>/', update_sales_with_deductions, name='update_sales_with_deductions'),
    path('delete_sales/<int:sales_id>', delete_sales, name="delete_sales"), 
    path('add_customer_sales/<int:farmer_id>',add_customer,name="add_customer"),
    path('add_deduction',add_deduction,name="add_deduction"),
    path('view_sales/<int:farmer_id>',view_sales,name="view_sales"),
    path('expenses_dashboard/<int:farmer_id>',expenses_dashboard,name="expenses_dashboard"), 
    path('get_places',get_places,name="get_places"),
    path('get_man_power',get_man_power,name="get_man_power"),
    path('get_package_management/<int:farmer_id>/',get_package_management,name="get_package_management"),
    path('get_purchase_fuel',get_purchase_fuel,name="get_purchase_fuel"),
    path('get_guidelines',get_guidelines,name="get_guidelines"), 
    path('help_desk_list', helpdesk_list, name='help_desk_list'),  
    path('weekly_sales_expenses/<int:farmer_id>', get_weekly_sales_expenses, name='weekly_sales_expenses'),
    path('customer_balances/<int:farmer_id>', get_customer_balances, name='customer_balances'),
    path('widget_config/<int:farmer_id>', get_widget_config, name='get_widget_config'), 
    path('update_widget_config/<int:farmer_id>', update_widget_config, name='update_widget_config'), 
    path('get_notifications_by_farmer/<int:farmer_id>', get_notifications, name='get_notifications_by_farmer'),
    path('get_otp', get_otp, name='get_otp'),
    path('farmer_update/<int:id>', manage_farmer, name='edit_farmer'),  # Edit farmer URL  
    path('farmer-crops/<int:farmer_id>', get_farmer_crops, name='get_farmer_crops'), 
    path('get_crop_types_with_crops/', get_crop_types_with_crops, name='get_crop_types_with_crops'), 
    path('schedule_weekly/',  get_schedule_weekly, name='get_schedule_weekly'),
    path('schedule_monthly/', get_schedule_monthly, name='get_schedule_monthly'),
    path('schedule_year/',  get_schedule_year, name='get_schedule_year'), 
    path('new_task/', new_task, name='new_task'),
    path('get_all_details_view/<int:id>', get_all_details_view, name='get_all_details'),
    path('places_detail/<int:farmer_id>/<int:id>/', get_near_by_locations, name='places_detail'),
    path('places_detail/<int:farmer_id>/<int:id>/<int:manage_nearby_location_id>/', get_near_by_locations_details, name='get_near_by_locations_details'),
    # path('get_near_by_users_workers/<int:id>', get_near_by_users_workers, name='get_near_by_users_workers'),
    path('get_near_by_users_workers/<int:farmer_id>/<int:id>/', get_near_by_users_workers, name='get_near_by_users_workers'),
    path('nearby-workers/<int:farmer_id>/<int:id>/<int:user_id>/',  get_near_by_users_workerss, name='get_near_by_users_workers_with_id'),
    path('get_users_workers_details/<int:id>', get_users_workers_details, name='get_users_workers_details'),
    path('get_near_by_rentals/<int:farmer_id>/<int:land_id>/', get_near_by_rentals, name='get_near_by_rentals'),
    path('get_near_by_rentals/<farmer_id>/<land_id>/<inventory_item_id>/', get_near_by_rentals_details, name='get_near_by_rentals_details'),
    path('get_near_by_markets/<int:farmer_id>/<int:id>', get_near_by_markets, name='get_near_by_markets'),
    path('get_near_by_markets/<int:farmer_id>/<int:id>/<market_id>/', get_near_by_markets_details, name='get_near_by_markets_details'),
    path('guidelines_list',  guidelines_list, name='guidelines_list'),
    path('schedules/<int:farmer_id>', get_schedules_by_month, name='get_schedules_by_month'), 
    path('get_guidelines_list', get_guidelines_list, name='get_guidelines_list'),
    path('guidelines_filter', filter_guidelines_by_keyword, name='guidelines_filter'),


    path('deactivate_my_land/<int:id>/', deactivate_my_land, name='deactivate_my_land'),
    path('deactivate_my_crop/<int:id>/', deactivate_my_crop, name='deactivate_my_crop'),
    path('land-and-crop-details/<int:farmer_id>', farmer_land_and_crop_details, name='farmer_land_and_crop_details'),
    path('land_details_with_crop/<int:farmer_id>', full_land_details, name='full_land_details'),
    path('land_with_survey_details/<int:farmer_id>', land_with_survey_details, name='land_with_survey_details'),
    path('crop_details_land/<int:farmer_id>', get_land_crop_details, name='get_land_crop_details'), 

    path('deactivate_my_sale/<int:id>', deactivate_my_sale, name='deactivate_my_sale'),
    path('get_sales_details/<int:farmer_id>/', get_sales_details, name='get_sales_details'),
    path('get_sales_by_crop/<int:farmer_id>/', get_sales_by_crop, name='get_sales_by_crop'),
    path('deactivate-my-schedule/<int:id>/',  deactivate_my_schedule, name='deactivate-my-schedule'),
    path('get_schedule_details/<int:farmer_id>/', get_schedule_details, name='get_schedule_details'),
    path('crop_expenses/<int:farmer_id>/', get_crop_expenses, name='get_crop_expenses'),

    # path('get_crop_details/<int:farmer_id>/', get_crop_details, name='get_crop_details')
    path('get_vendor_details/<int:farmer_id>/', get_vendor_details, name='get_vendor_details'),
    path('get_customer_details/<int:farmer_id>/', get_customer_details, name='get_customer_details'),
    path('deactivate_my_vendor/<int:id>/', deactivate_my_vendor, name='deactivate_my_vendor'),
    path('deactivate_my_customer/<int:id>/', deactivate_my_customer, name='deactivate_my_customer'),
    path('deactivate_my_customer_vendor/<int:id>/', deactivate_my_customer_vendor, name='deactivate_my_customer_vendor'),
    path('update_vendor/<int:id>/', update_vendor, name='update_vendor'),
    path('update_customer/<int:id>/', update_customer, name='update_customer'),
    path('update_customer_vendor/<int:id>/', update_customer_vendor, name='update_customer_vendor'),
    path('customer_sales_details/<int:id>/',  customer_sales_details, name='customer_sales_details'),
    path('get_vendor_purchase_details/<int:farmer_id>',get_vendor_purchase_details, name="get_vendor_purchase_details"),
    path('farmer_profile/<int:farmer_id>/',  get_farmer_profile, name='get_farmer_profile'),
    path('delete_expense_file/<int:id>/', delete_expense_file, name='delete_expense_file'),
    path('purchase_list/<int:farmer_id>/', purchase_list, name='purchase_list'),
    path('fuel_list/<int:farmer_id>', get_fuels_by_inventory_type, name='get_fuels_by_inventory_type'),
    path('fuel_list_with_items/<int:farmer_id>', get_fuels_by_inventory_items, name='get_fuels_by_inventory_items'),

    path('vehicle_list/<int:farmer_id>', get_vehicles_by_inventory_type, name='get_vehicles_by_inventory_type'),
    path('vehicle_list_with_items/<int:farmer_id>', get_vehicles_by_inventory_items, name='get_vehicles_by_inventory_items'),

    path('machinery_list/<int:farmer_id>', get_machinery_by_inventory_type, name='get_machinery_by_inventory_type'),
    path('machinery_list_with_items/<int:farmer_id>', get_machinery_by_inventory_items, name='get_machinery_by_inventory_items'),

    path('tools_list/<int:farmer_id>/', get_tools_by_inventory_type, name='get_tools_by_inventory_type'), 
    path('tools_list_with_items/<int:farmer_id>', get_tools_by_inventory_items, name='get_tools_by_inventory_items'),


    path('pesticides_list/<int:farmer_id>/', get_pesticides_by_inventory_type, name='get_pesticides_by_inventory_type'),
    path('pesticides_list_with_items/<int:farmer_id>/', get_pesticides_by_inventory_items, name='get_pesticides_by_inventory_items'),


    path('seeds_list/<int:farmer_id>/', get_seeds_by_inventory_type, name='get_seeds_by_inventory_type'),
    path('seeds_list_with_items/<int:farmer_id>/', get_seeds_by_inventory_items, name='get_seeds_by_inventory_items'),

    path('fertilizers_list/<int:farmer_id>/', get_fertilizers_by_inventory_type, name='get_fertilizers_by_inventory_type'),
    path('fertilizers_list_with_items/<int:farmer_id>/', get_fertilizers_by_inventory_items, name='get_fertilizers_by_inventory_items'),



    path('get_myfuel/<int:farmer_id>/', get_my_fuel, name='get_my_fuel'),
    path('get_myvehicle/<int:farmer_id>/', get_my_vehicle, name='get_my_vehicle'),
    path('get_my_machinery/<int:farmer_id>/', get_my_machinery, name='get_my_machinery'),
    path('get_my_tools/<int:farmer_id>/', get_my_tools, name='get_my_tools'),
    path('get_my_pesticides/<int:farmer_id>/', get_my_pesticides, name='get_my_pesticides'),
    path('get_my_fertilizers/<int:farmer_id>/', get_my_fertilizers, name='get_my_fertilizers'), 
    path('get_my_seeds/<int:farmer_id>/', get_my_seeds, name='get_my_seeds'),
    path('deactivate_fuel/<int:id>/', deactivate_my_fuel, name='deactivate_my_fuel'),  
    path('deactivate_vehicle/<int:id>/', deactivate_my_vehicle, name='deactivate_my_vehicle'), 
    path('deactivate_tools/<int:id>/', deactivate_my_tools, name='deactivate_my_tools'), 
    path('deactivate_machinery/<int:id>/', deactivate_my_machinery, name='deactivate_my_machinery'), 
    path('deactivate_seeds/<int:id>/', deactivate_my_seeds, name='deactivate_my_seeds'), 
    path('deactivate_fertilizers/<int:id>/', deactivate_my_fertilizers, name='deactivate_my_fertilizers'),
    path('deactivate_pesticides/<int:id>/', deactivate_pesticides, name='deactivate_pesticides'),
    path('update_fuel/<int:farmer_id>/', update_fuel, name='update_fuel'),
    path('update_vehicle/<int:farmer_id>/', update_vehicle, name='update_vehicle'),
    path('update_machinery/<int:farmer_id>/', update_machinery, name='update_machinery'),
    path('update_tools/<int:farmer_id>/<int:tool_id>', update_tools, name='update_tools'),
    path('update_pesticides/<int:farmer_id>/<int:pesticide_id>', update_pesticides, name='update_pesticides'),
    path('update_fertilizers/<int:farmer_id>/<int:fertilizer_id>', update_fertilizers, name='update_fertilizers'),
    path('update_seeds/<int:farmer_id>/<int:seed_id>', update_seeds, name='update_seeds'),
    path('list_farmer_expenses/<int:farmer_id>/', list_farmer_expenses, name='list_farmer_expenses'),
    path('list_farmer_purchase/<int:farmer_id>/', list_farmer_purchase, name='list_farmer_purchase'),
    path('both_farmer_expense_purchase_list/<int:farmer_id>/', both_farmer_expense_purchase_list, name='both_farmer_expense_purchase_list'),
    path('total_expense_and_purchase/<int:farmer_id>/',  total_expense_and_purchase_amount, name='total_expense_and_purchase'),
    path('land-details/<int:farmer_id>/', get_farmer_land_details, name='farmer_land_details'), 
    path('create_consumption/', create_inventory_with_documents, name='create_inventory_with_documents'), 
    path('create_soil_test/<int:farmer_id>', create_soil_test, name='create_soil_test'), #Post(Soil Test)
    path('soil_test/<int:farmer_id>/', get_soil_test_report, name='get_soil_test_report'), #Get(Soil Test)
    path('filter_land_with_crops/<int:farmer_id>/',  filter_crops, name='filter_crops'),#land with crop list
    path('dashboard_task_list/<int:farmer_id>/', dashboard_task_list, name='dashboard_task_list'),
    path('get_product_market_report/<int:farmer_id>/',  get_product_market_report, name='get_product_market_report'), #dashboard market price list
    path('monthly_sales_expenses/<int:farmer_id>/', get_monthly_expenses_and_sales, name='monthly_sales_expenses'),
    # path('customers_payables_receivables/<int:farmer_id>/',  get_customer_and_vendor_payables_and_receivables, name='get_customer_payables_and_receivables'),
    path('payables_receivables_count/<int:farmer_id>/',  payables_receivables_count, name='payables_receivables_count'),
    path('vendor_purchase_list/<int:farmer_id>/', vendor_purchase_list, name='vendor-purchase-list'),
    path('crop_details/<farmer_id>/<land_id>/<crop_id>/', crop_details, name='crop_details'),
    path('deactivate_my_expense/<int:farmer_id>/', deactivate_my_expense, name='deactivate_my_expense'),  
    path('my_land_survey_details_delete/', delete_my_land_survey, name='my_land_survey_details_delete'),
    # path('my_land_document_delete/<int:pk>/', delete_my_land_document, name='my_land_document_delete'),
    path('my_land_document_delete/', delete_my_land_document, name='delete_my_land_document'),
    path('my_sales_document_delete/', delete_my_sales_document, name='my_sales_document_delete'), 
    path('deduction_reason_delete/', delete_my_sales_deduction_reason, name='deduction_reason_delete'), 
    path('delete-fuel-document/', delete_my_fuel_document, name='delete_my_fuel_document'),
    path('get_farmer_usage/<int:farmer_id>/', get_farmer_land_usage, name='farmer-land-usage'),
    path('reasons/', get_all_reasons, name='get_all_reasons'),
    path('rupees/', get_all_rupees, name='get_all_rupees'),
    path('create_outstanding/', create_outstanding, name='create_outstanding'),
    path('vendor_purchase_payables_list/<int:farmer_id>', vendor_purchase_payables_list, name='vendor_purchase_payables_list'),
    # path('create_customer_outstandings/<int:farmer_id>',create_customer_outstandings,name='create_customer_outstandings'),
    # path('get_outstanding/<int:farmer_id>/', get_outstanding, name='get_outstanding'),
    # path('get_outstanding_details/<int:farmer_id>/',get_outstanding_details,name='get_outstanding_details'),
    # path('get_outstanding_customer/<int:farmer_id>/',get_outstanding_market,name='get_outstanding_market'),
    # path('get_outstanding_customer_details/<int:farmer_id>/',get_outstanding_market_details,name='get_outstanding_market_details'),
    path('expense-totals/', get_expense_totals, name='get_expense_totals'),
    path('fuel_inventory_and_consumption/<int:farmer_id>/<int:inventory_type_id>/<int:inventory_items_id>/', get_fuel_inventory_details, name='get_fuel_inventory_details'),
    path('machinery-inventory-details/<int:farmer_id>/<int:inventory_type_id>/<int:inventory_items_id>/', get_machinery_inventory_details, name='machinery_inventory_details'),
    path('pesticides-inventory-details/<int:farmer_id>/<int:inventory_type_id>/<int:inventory_items_id>/', 
         get_pesticides_inventory_details, 
         name='get_pesticides_inventory_details'),
    path('vehicle-inventory-details/<int:farmer_id>/<int:inventory_type_id>/<int:inventory_items_id>/', 
         get_vehicle_inventory_details, name='vehicle_inventory_details'),
    path('tools-inventory-details/<int:farmer_id>/<int:inventory_type_id>/<int:inventory_items_id>/',get_tools_inventory_details, name='get_tools_inventory_details'),
    path('fertilizers-inventory-details/<int:farmer_id>/<int:inventory_type_id>/<int:inventory_items_id>/', get_fertilizers_inventory_details, name='get_fertilizers_inventory_details'),
    path('seeds-inventory-details/<int:farmer_id>/<int:inventory_type_id>/<int:inventory_items_id>/', get_seeds_inventory_details, name='get_seeds_inventory_details'),
    path('update_consumption/<int:inventory_id>/', update_inventory_with_documents, name='update_inventory_with_documents'),
    path('verify_payment_mobile/', verify_payment_mobile, name='verify_payment_mobile'),
    path('general-settings/', get_general_settings, name='get-general-settings'),
    path('user-language/<int:farmer_id>/', user_language, name='user-language'),

    path('payables_receivables_list/<int:farmer_id>/', payables_receivables_list, name='payables_receivables_list'),
    path('customer_sales_payables_list/<int:farmer_id>/', customer_sales_payables_list, name='customer_sales_payables_list'),
    path('customer_sales_receivables_list/<int:farmer_id>/', customer_sales_receivables_list, name='customer_sales_receivables_list'),
    path('vendor_purchase_payables_list/<int:farmer_id>', vendor_purchase_payables_list, name='vendor_purchase_payables_list'),
    path('vendor_purchase_receivables_list/<int:farmer_id>',vendor_purchase_receivables_list, name='vendor_purchase_receivables_list'),
    path('customer_vendor_receivables_list/<int:farmer_id>',customer_vendor_receivables_list,name='customer_vendor_receivables_list'),
    path('customer_vendor_payables_list/<int:farmer_id>',customer_vendor_payables_list, name='customer_vendor_payables_list'),

    path('pay_sales_outstanding/<int:farmer_id>/<int:customer_id>/', pay_sales_outstanding, name='pay_sales_outstanding'),
    path('pay_sales_payables_outstanding/<int:farmer_id>/<int:customer_id>/', pay_sales_payables_outstanding, name='pay_sales_payables_outstanding'),
    path('pay_purchase_outstanding/<int:farmer_id>/<int:vendor_id>/', pay_purchase_outstanding, name='pay_purchase_outstanding'),
    path('vendor_purchase_Payables_outstanding/<int:farmer_id>/<int:vendor_id>/',vendor_purchase_Payables_outstanding, name='vendor_purchase_Payables_outstanding'),

    
    path('customer_sales_receivables_outstanding_history/<int:farmer_id>/', get_sales_outstanding_history, name='sales-outstanding-history'),
    path('get_sales_payables_outstanding_history/<int:farmer_id>/',get_sales_payables_outstanding_history,name ='get_sales_payables_outstanding_history'),
    path( 'vendor_purchase_payables_outstanding_history/<int:farmer_id>/', get_farmer_vendor_outstanding_history, name='farmer-vendor-fuel-outstanding'
    ),
    path( 'vendor_purchase_receivables_outstanding_history/<int:farmer_id>/', get_farmer_vendor_received_outstanding_history, name='get_farmer_vendor_received_outstanding_history'
    ),
    path('get_farmer_both_receivables_outstanding_history/<int:farmer_id>/', get_farmer_both_receivables_outstanding_history, name='get_farmer_both_receivables_outstanding_history'),
    path('get_farmer_both_payables_outstanding_history/<int:farmer_id>/',get_farmer_both_payables_outstanding_history, name='get_farmer_both_payables_outstanding_history'),

    path('farmer_notifications_count/<int:farmer_id>/', get_farmer_notification_count, name='farmer-notification-count'),
    path('farmer_notifications_all/<int:farmer_id>/', get_farmer_notifications, name='get-farmer-notification'),
    path('farmer_notifications_get/<int:farmer_id>/<int:notification_id>', get_farmer_notification, name='get-farmer-notifications'),
    path('farmer_notification_update/<int:farmer_id>/<int:notification_id>', mark_notification_read, name='mark_notification_read'),

    #land View
    path('land_view/<int:farmer_id>/<int:land_id>/', land_view, name='land_view'),
    path('crop_view/<int:farmer_id>/<int:land_id>/<int:crop_id>/', crop_view, name='crop_view'),
    path('tasks/for-month-and-crop/<int:farmer_id>/', get_task_calender_list_for_month_and_crop, name='task-list-month-crop'),
    path('tasks_list/for-month-and-crop/<int:id>/', get_task_list_for_month_and_crop, name='task-list-month-crop-list'),
    path('land-vs-crop-chart/<int:farmer_id>/', land_vs_crop_chart, name='land-vs-crop-chart'),

    # land unit measurement
    path('convert-land-unit/', convert_land_unit, name="convert_land_unit"), 
    path('best_practice_schedule/<int:farmer_id>/<int:land_id>/<int:my_crop_id>/', get_crop_schedule, name='get_crop_schedule'),
    path('best_practice_schedule/<int:farmer_id>/<int:land_id>/<int:my_crop_id>/<int:schedule_id>/',get_schedule_detail, name='get_schedule_detail'),

    path('crop_summary/<int:farmer_id>/<int:land_id>/<int:crop_id>/', get_crop_summary, name='crop-summary'),
    # path('inventory_purchase_list/<int:farmer_id>/<int:inventory_type_id>/<int:inventory_items_id>/', get_inventory_purchase_list, name='get_inventory_purchase_list'),
    # path('inventory_cunsumption_list/<int:farmer_id>/<int:inventory_type_id>/<int:inventory_items_id>/', get_inventory_cusumption_list, name='get_inventory_cusumption_list'),

#bala 
    path("schema/", SpectacularAPIView.as_view(), name="schema"),
    path("docs/", SpectacularSwaggerView.as_view(url_name="schema"),name="swagger-ui"),
    path("redoc/", SpectacularRedocView.as_view(url_name="schema"),name="redoc"),

    path('inventory_types_quantity/<int:farmer_id>/',
    get_inventory_types_quantity, name='get_inventory_types_quantity'),

    path('inventory_item_quantity/<int:farmer_id>/<int:inventory_type_id>/<int:inventory_items_id>/', get_inventory_item_quantity,name='get_inventory_item_quantity'),


    path('inventory_purchase_list/<int:farmer_id>/<int:inventory_type_id>/<int:inventory_items_id>/', get_inventory_purchase_list,name='get_inventory_purchase_list'),

    path('inventory_purchase_details/<int:farmer_id>/<int:inventory_type_id>/<int:id>', get_inventory_purchase_details,name='get_inventory_purchase_details'),


    path('inventory_cunsumption_list/<int:farmer_id>/<int:inventory_type_id>/<int:inventory_items_id>/', get_inventory_consumption_list,name='get_inventory_consumption_list'),

    path('inventory_cunsumption_details/<int:farmer_id>/<int:inventory_type_id>/<int:id>', get_inventory_cusumption_details,name='get_inventory_cusumption_details'),

    #customer Outstanding
    path('customer_payables_list/<int:farmer_id>',get_customer_payables_list, name='get_customer_payables_list'),
    path('customer_receivables_list/<int:farmer_id>/',get_customer_receivables_list, name='get_customer_receivables_list'),

    #vendors Outstanding
    path('vendors_payables_list/<int:farmer_id>',get_vendors_payables_list, name='get_vendors_payables_list'),
    path('vendors_receivables_list/<int:farmer_id>/',get_vendors_receivables_list, name='get_vendors_receivables_list'),
   

   #employee
   # CREATE
    path("employees/create/", create_employee, name="create_employee"),

    # # UPDATE
    # path("employees/<int:employee_id>/update/", update_employee, name="update_employee"),

    # # DELETE
    # path("employees/<int:employee_id>/delete/", delete_employee, name="delete_employee"),

    # # STATUS UPDATE
    # path("employees/<int:employee_id>/status/", update_employee_status, name="update_employee_status"),

    # # GET EMPLOYEE LIST (by farmer)
    # path("farmers/<int:farmer_id>/employees/", get_employees_list, name="get_employees_list"),

    # # GET EMPLOYEE DETAILS
    # path("employees/<int:employee_id>/", get_employee_details, name="get_employee_details"),

    # # # GET EMPLOYEE DETAILS
    # path("employees/<int:employee_id>/<int:employee_id>/", get_employee_details, name="get_employee_details"),

    # GET EMPLOYEE DETAILS
    path("managers_with_employees/<int:farmer_id>", get_manager_user_list, name="get_employee_details"),
    # GET mangerEMPLOYEE DETAILS
    path("create_manager_user/<int:farmer_id>", create_manager_user, name="get_employee_details"),
    
    
    path('employee_types', get_employee_types, name='get_employee_types'),
]



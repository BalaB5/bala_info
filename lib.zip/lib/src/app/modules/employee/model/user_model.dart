class UserModel {
  final int id;
  final String name;
  final String role;
  final String number;
  final String address;
  final String profile;
  final int? status;

  UserModel({
    required this.id,
    required this.name,
    required this.role,
    required this.number,
    required this.address,
    required this.profile,
     this.status,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) => UserModel(
      id: json['id'] ?? 0,
      name: json['name'] ?? '',
      role: json['role'] ?? '',
      number: json['number']?.toString() ?? '',
      address: json['address'] ?? '',
      profile: json['profile'] ?? '',
      status: json['status'],
    );

  Map<String, dynamic> toJson() => {
      'id': id,
      'name': name,
      'role': role,
      'number': number,
      'address': address,
      'profile': profile,
    };
}
class ManagerEmployeeGroup {
  final Manager manager;
  final List<Employee> employees;

  ManagerEmployeeGroup({
    required this.manager,
    required this.employees,
  });

  factory ManagerEmployeeGroup.fromJson(Map<String, dynamic> json) => ManagerEmployeeGroup(
      manager: json['manager']!= null ? Manager.fromJson(json['manager']) :Manager(address:"",email:"",employeeTypeName:"" ,id: 0,mobileNo: "",name:"" ),
      employees: (json['employees'] as List)
          .map((e) => Employee.fromJson(e))
          .toList(),
    );
}

class Manager {
  final int id;
  final String name;
  final String mobileNo;
  final String email;
  final String address;
  final String employeeTypeName;

  Manager({
    required this.id,
    required this.name,
    required this.mobileNo,
    required this.email,
    required this.address,
    required this.employeeTypeName,
  });

  factory Manager.fromJson(Map<String, dynamic> json) => Manager(
      id: json['id'] ?? 0,
      name: json['name'] ?? '',
      mobileNo: (json['mobile_no'] ?? '').toString(),
      email: json['email'] ?? '',
       address: json['address'] ?? '',
       employeeTypeName: json['employee_type_name'] ?? '',
    );

  // Convert to UserModel for compatibility
  UserModel toUserModel() => UserModel(
      id: id,
      name: name,
      role: 'Manager',
      number: mobileNo,
      address: address,
      profile: '',
    );
}


class Employee {
  final int id;
  final String name;
  final String mobileNo;
  final String? employeeType;
  final String? workType;
  final int status;

  Employee({
    required this.id,
    required this.name,
    required this.mobileNo,
    this.employeeType,
    this.workType,
    required this.status,
  });

  factory Employee.fromJson(Map<String, dynamic> json) => Employee(
        id: json['id'] ?? 0,
        name: json['name'] ?? '',
        mobileNo: (json['mobile_no'] ?? '').toString(),
        employeeType: json['employee_type_name'],
        workType: json['work_type_name'],
        status: json['status'] ?? 0,
      );

 Employee copyWith({
  int? id,
  String? name,
  String? mobileNo,
  String? employeeType,
  String? workType,
  int? status,
}) => Employee(
    id: id ?? this.id,
    name: name ?? this.name,
    mobileNo: mobileNo ?? this.mobileNo,
    employeeType: employeeType ?? this.employeeType,
    workType: workType ?? this.workType,
    status: status ?? this.status,
  );


  UserModel toUserModel() => UserModel(
        id: id,
        name: name,
        role: 'Employee',
        number: mobileNo,
        address: workType ?? '',
        profile: '',
        status: status
      );
}

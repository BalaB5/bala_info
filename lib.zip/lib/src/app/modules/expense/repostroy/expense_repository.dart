import 'dart:convert';
import 'package:argiot/src/app/modules/expense/model/chart.dart';
import 'package:argiot/src/app/controller/app_controller.dart';
import 'package:argiot/src/app/modules/expense/model/total_expense.dart';
import 'package:argiot/src/app/modules/task/model/crop_model.dart';
import 'package:argiot/src/app/service/http/http_service.dart';
import 'package:get/get.dart';

import '../model/customer.dart';
import '../model/expense.dart';

class ExpenseRepository {
  final HttpService _httpService = Get.find<HttpService>();
  final AppDataController appDeta = Get.find();

  Future<TotalExpense> getTotalExpense(String timePeriod) async {
    final farmerId = appDeta.farmerId.value;
    try {
      final response = await _httpService.post(
        '/total_expense_and_purchase/$farmerId/',
        {'time_period': timePeriod},
      );
      return TotalExpense.fromJson(json.decode(response.body));
    } catch (e) {
      throw Exception('Failed to load total expense: $e');
    }
  }

  Future<List<CropModel>> getCropList() async {
    final farmerId = appDeta.farmerId;
    final isManager = appDeta.isManager.value;
    final managerId = appDeta.managerID.value;
    String manager = isManager ? "?manager_id=$managerId" : "";
    try {
      final response = await _httpService.get(
        '/land-and-crop-details/$farmerId$manager',
      );
      final lands = json.decode(response.body)['lands'] as List;

      final allCrops = lands
          .expand((land) => land['crops'] as List)
          .map((crop) => CropModel.fromJson(crop))
          .toSet()
          .toList();

      return allCrops;
    } catch (e) {
      throw Exception('Failed to load crops: ${e.toString()}');
    }
  }

  // Updated method for all expenses and sales
  Future<List<GroupedExpenseRecord>> getBothExpensesAndSales(
    String timePeriod,
  ) async {
    final farmerId = appDeta.farmerId.value;
    try {
      final response = await _httpService.get(
        '/both_expense_sales_list/$farmerId/$timePeriod',
      );
      final List<dynamic> data = json.decode(response.body);
      return data.map((json) => GroupedExpenseRecord.fromJson(json)).toList();
    } catch (e) {
      throw Exception('Failed to load expenses and sales: $e');
    }
  }

  // Method for expenses only
  Future<List<GroupedExpenseRecord>> getExpensesOnly(String timePeriod) async {
    final farmerId = appDeta.farmerId.value;
    try {
      final response = await _httpService.get(
        '/myexpenses_list/$farmerId/$timePeriod',
      );
      final List<dynamic> data = json.decode(response.body);
      return data.map((json) => GroupedExpenseRecord.fromJson(json)).toList();
    } catch (e) {
      throw Exception('Failed to load expenses: $e');
    }
  }

  // Method for sales only
  Future<List<GroupedExpenseRecord>> getSalesOnly(String timePeriod) async {
    final farmerId = appDeta.farmerId.value;
    try {
      final response = await _httpService.get(
        '/mysales_list/$farmerId/$timePeriod',
      );
      final List<dynamic> data = json.decode(response.body);
      return data.map((json) => GroupedExpenseRecord.fromJson(json)).toList();
    } catch (e) {
      throw Exception('Failed to load sales: $e');
    }
  }

  Future<List<Customer>> getVendorList() async {
    try {
      final farmerId = appDeta.farmerId;
      final response = await _httpService.get('/get_vendor/$farmerId');
      var decode = json.decode(response.body);
      var map = decode
          .map<Customer>((item) => Customer.fromJson(item))
          .toList();
      return map;
    } catch (e) {
      rethrow;
    }
  }

  Future<List<Chart>> getExpenseSummary(String timePeriod) async {
    final farmerId = appDeta.farmerId.value;
    try {
      final response = await _httpService.post('/expense-totals/', {
        'farmer_id': farmerId,
        'time_period': timePeriod,
      });
      return List<Chart>.from(
        json.decode(response.body).map((x) => Chart.fromJson(x)),
      );
    } catch (e) {
      throw Exception('Failed to load expense summary: $e');
    }
  }

  Future addExpense({
    int? myCrop,
    required int amount,
    required String createdDay,
    int? vendor,
    int? paidamonut,
    String? description,
    List<Map<String, dynamic>>? documents,
  }) async {
    final farmerId = appDeta.farmerId;
    try {
      final response = await _httpService.post('/add_expense/$farmerId', {
        'my_crop': myCrop,
        'amount': amount,
        'created_day': createdDay,
        'vendor': vendor,
        'paid_amount': paidamonut,
        'description': description,
        if (documents != null) 'document': documents,
      });
      return json.decode(response.body);
    } catch (e) {
      throw Exception('Failed to add expense: $e');
    }
  }
}

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter_colorpicker/flutter_colorpicker.dart';
import 'package:hive_flutter/hive_flutter.dart';

class Tag {
  String label;
  Color color;
  bool isSelected;
  Tag({required this.label, required this.color, this.isSelected = false});
}

class TagController extends GetxController {
  var tags = <Tag>[].obs;
  final Box box = Hive.box('tagsBox');

  @override
  void onInit() {
    super.onInit();
    loadTagsFromLocal();
  }

  /// Load saved tags (Map<String, String>) from Hive
  void loadTagsFromLocal() {
    Map<String, String> savedMap =
        Map<String, String>.from(box.get('tags', defaultValue: {}));
    tags.value = savedMap.entries
        .map((e) => Tag(label: e.key, color: _colorFromHex(e.value)))
        .toList();

    // Add some defaults if box is empty
    if (tags.isEmpty) {
      tags.addAll([
        Tag(label: 'Interior Design', color: Colors.teal),
        Tag(label: 'Pets', color: Colors.orange),
        Tag(label: 'Skin Care', color: Colors.pink),
        Tag(label: 'Party Planning', color: Colors.grey),
        Tag(label: 'Hair Care & Styling', color: Colors.blue),
        Tag(label: 'Makeup', color: Colors.purple),
        Tag(label: 'Gardening', color: Colors.green),
      ]);
      saveTagsToLocal();
    }
  }

  /// Save tags to Hive as Map<String, String>
  void saveTagsToLocal() {
    Map<String, String> map = {
      for (var tag in tags) tag.label: _colorToHex(tag.color)
    };
    box.put('tags', map);
  }

  void toggleTag(Tag tag) {
    tag.isSelected = !tag.isSelected;
    tags.refresh();
  }

  void addTag(String label, Color color) {
    tags.add(Tag(label: label, color: color));
    saveTagsToLocal();
  }

  /// Helpers
  String _colorToHex(Color color) =>
      '#${color.value.toRadixString(16).padLeft(8, '0')}';

  Color _colorFromHex(String hexColor) {
    hexColor = hexColor.replaceAll('#', '');
    if (hexColor.length == 6) hexColor = 'ff$hexColor';
    return Color(int.parse(hexColor, radix: 16));
  }
}

class TagBottomSheet extends StatelessWidget {
  final TagController controller = Get.put(TagController());

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text("Popular Interests",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          Obx(() => Wrap(
                spacing: 8,
                runSpacing: 8,
                children: controller.tags.map((tag) {
                  return FilterChip(
                    label: Text(tag.label),
                    selected: tag.isSelected,
                    selectedColor: tag.color.withOpacity(0.2),
                    checkmarkColor: tag.color,
                    onSelected: (_) => controller.toggleTag(tag),
                    shape: StadiumBorder(
                      side: BorderSide(
                        color: tag.isSelected
                            ? tag.color
                            : Colors.grey.shade400,
                      ),
                    ),
                  );
                }).toList(),
              )),
          const SizedBox(height: 12),
          TextButton.icon(
            icon: const Icon(Icons.add),
            label: const Text("Add New Tag"),
            onPressed: () {
              Get.bottomSheet(
                AddTagSheet(controller: controller),
                isScrollControlled: true,
              );
            },
          ),
        ],
      ),
    );
  }
}

class AddTagSheet extends StatefulWidget {
  final TagController controller;
  const AddTagSheet({super.key, required this.controller});

  @override
  State<AddTagSheet> createState() => _AddTagSheetState();
}

class _AddTagSheetState extends State<AddTagSheet> {
  final TextEditingController labelController = TextEditingController();
  Color selectedColor = Colors.blue;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
          bottom: MediaQuery.of(context).viewInsets.bottom,
          top: 16,
          left: 16,
          right: 16),
      child: Wrap(
        children: [
          const Text("Add New Tag",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          TextField(
            controller: labelController,
            decoration: const InputDecoration(
              labelText: 'Label',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              const Text("Pick Color:"),
              const SizedBox(width: 10),
              GestureDetector(
                onTap: () {
                  showDialog(
                    context: context,
                    builder: (_) => AlertDialog(
                      title: const Text("Pick a color"),
                      content: BlockPicker(
                        pickerColor: selectedColor,
                        onColorChanged: (color) =>
                            setState(() => selectedColor = color),
                      ),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: const Text("Done"),
                        )
                      ],
                    ),
                  );
                },
                child: CircleAvatar(backgroundColor: selectedColor),
              )
            ],
          ),
          const SizedBox(height: 24),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              minimumSize: const Size(double.infinity, 45),
              backgroundColor: selectedColor,
            ),
            onPressed: () {
              if (labelController.text.trim().isNotEmpty) {
                widget.controller
                    .addTag(labelController.text.trim(), selectedColor);
                Get.back();
              }
            },
            child: const Text("Add Tag"),
          ),
        ],
      ),
    );
  }
}

void showTagBottomSheet() {
  Get.bottomSheet(
    TagBottomSheet(),
    isScrollControlled: true,
  );
}

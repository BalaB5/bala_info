// app_pages.dart

import 'package:call_tracker/src/app/modules/auth/views/screens/login_page.dart';
import 'package:call_tracker/src/app/modules/auth/views/screens/otp_page.dart';
import 'package:call_tracker/src/app/modules/auth/views/screens/splash.dart';
import 'package:call_tracker/src/app/modules/calls/views/screens/dial_pad.dart';
import 'package:call_tracker/src/app/modules/followups/views/screens/add_followup_page.dart';
import 'package:call_tracker/src/app/modules/followups/views/screens/followups_page.dart';
import 'package:call_tracker/src/app/modules/followups/views/screens/today_followups_page.dart';
import 'package:call_tracker/src/app/modules/leads/views/screens/add_lead_page.dart';
import 'package:call_tracker/src/app/modules/leads/views/screens/leads_page.dart';
import 'package:call_tracker/src/app/modules/bottombar/views/screens/home.dart';
import 'package:call_tracker/src/app/modules/notification/views/screens/notifications.dart';
import 'package:call_tracker/src/app/utils/routes/app_pages.dart';
import 'package:get/get.dart';

import '../../modules/calls/binding/client_detail_binding.dart';
import '../../modules/calls/views/screens/call_record.dart';
import '../../modules/calls/views/screens/client_detail_screen.dart';
import '../../modules/whatsapp/bindings/note_bindings.dart';
import '../../modules/whatsapp/view/my_notes_screen.dart';
import '../../modules/whatsapp/view/note_detail_screen.dart';

class Routes {
  static final pages = [
    GetPage(name: AppPages.splash, page: () => const SplashScreen()),
    GetPage(name: AppPages.login, page: () => LoginPage()),
    GetPage(name: AppPages.otp, page: () => OtpPage()),
    GetPage(name: AppPages.home, page: () => Home()),
    GetPage(name: AppPages.leads, page: () => const LeadsPage()),
    GetPage(name: AppPages.addLead, page: () => const AddLeadPage()),

    GetPage(name: AppPages.dialPad, page: () =>  DialPad()),

    GetPage(
      name: AppPages.todayFollowups,
      page: () => const TodayFollowUpsPage(),
    ),
    GetPage(name: AppPages.followups, page: () => const FollowUpsPage()),
    GetPage(name: AppPages.notification, page: () => const Notifications()),
    GetPage(name: AppPages.addFollowup, page: () => const AddFollowUpPage()),
    GetPage(name: AppPages.callRecord, page: () => CallRecordingScreen()),
    // GetPage(name: Routes.test, page: () => const DetailPage()),
    GetPage(
      name: AppPages.callLogDetails,
      page: () {
        return ClientDetailScreen();
      },
      binding: BindingsBuilder(() {
        ClientDetailBinding().dependencies();
      }),
    ),
        GetPage(
      name:  AppPages.notes,
      page: () => MyNotesScreen(),
      binding: MyNotesBinding(),
    ),
    GetPage(
      name:  AppPages.notesDetails,
      page: () {
        return NoteDetailScreen();
      },
      binding: BindingsBuilder(() {
        NoteDetailBinding().dependencies();
      }),
    ),
  ];
}

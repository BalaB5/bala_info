class English {
  static Map<String, String> list = {
    "title": "Client Details",
    "no_data": "No client data available",
    "lead_type": "Lead Temperature",
    "assigned_to": "Assigned To",
    "reassign": "Re-assign Lead",
    "lead_status": "Lead Status",
    "change_status": "Change Status",
    "recordings": "IVR Call Recordings",
    "view_all": "View All",
    "no_recordings": "No recordings available",
    "no_notes": "No notes available",
    "updated_on": "Updated on",
    "created_info": "Created by",

    "retry": "Retry",
    "search_hint": "Search notes",
    "add_note": "Add New Note",
    
      "title": "My Notes",
      "no_data": "No note data available",
      "title_hint": "Enter note title",
      "content_hint": "Write your note here...",
      "save": "Save",
      "edit": "Edit",
    
    "retry": "Retry",
    "cancel": "Cancel",
  };
}

import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ToggleBar extends StatelessWidget {
  const ToggleBar({super.key, required this.onTap, required this.activePageIndex});
  final void Function(int)? onTap;
  final int activePageIndex;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 300.0,
      height: 38.0,
      decoration: BoxDecoration(
        color: Colors.grey[200],
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: <Widget>[
          Expanded(
            child: InkWell(
              borderRadius: BorderRadius.all(Radius.circular(10)),
              onTap: () => onTap?.call(0),
              child: Container(
                // width: width2,
                // padding: EdgeInsets.symmetric(vertical: 15),
                alignment: Alignment.center,
                decoration:
                    
                         BoxDecoration(
                          color: (activePageIndex == 0)?Get.theme.primaryColorLight :Colors.grey[200],
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                child: Text('Follow Ups'),
              ),
            ),
          ),
          Expanded(
            child: InkWell(
              borderRadius: BorderRadius.all(Radius.circular(10)),
              onTap: () => onTap?.call(1),
              child: Container(
                // width: width2,
                // padding: EdgeInsets.symmetric(vertical: 15),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                          color: (activePageIndex == 1)?Get.theme.primaryColorLight :Colors.grey[200],
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                child: Text("Call logs"),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

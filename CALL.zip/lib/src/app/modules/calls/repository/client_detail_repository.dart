import 'package:get/get.dart';

import '../../../utils/service/http/http_service.dart';
import '../model/client_detail_model.dart';
class ClientDetailRepository {
  final HttpService httpService = Get.find<HttpService>();

  ClientDetailRepository();

  Future<ClientDetailResponse> getClientDetail(String clientId) async {
    try {
      // final response = await httpService.get(
      //   '/clients/$clientId',
      //   // queryParams: {'include': 'status_history,recordings,assigned_agent'},
      // );
      
      // // Hot code response simulation
      // if (response is Map<String, dynamic>) {
      //   // return ClientDetailResponse.fromJson(response);
      // }
      
      // Fallback hot response for development
      return ClientDetailResponse.fromJson({
        "status": true,
        "message": "Success",
        "data": {
          "id": clientId,
          "name": "John Doe",
          "email": "john.doe@example.com",
          "phone": "+1234567890",
          "lead_type": "Warm",
          "assigned_agent": {
            "id": "agent_123",
            "name": "Sarah Wilson",
            "email": "sarah@company.com",
            "avatar": null
          },
          "current_status": {
            "status": "Contacted",
            "notes": "Client showed interest in our premium package. Needs to discuss with team before decision. Will follow up next week.",
            "updated_at": "2024-01-15T10:30:00Z",
            "updated_by": "Sarah Wilson"
          },
          "status_history": [
            {
              "status": "New Lead",
              "notes": "Initial contact made",
              "updated_at": "2024-01-10T09:15:00Z",
              "updated_by": "System"
            },
            {
              "status": "Contacted",
              "notes": "Client showed interest in our premium package",
              "updated_at": "2024-01-15T10:30:00Z",
              "updated_by": "Sarah Wilson"
            }
          ],
          "recordings": [
            {
              "id": "rec_1",
              "url": "https://example.com/recording1.mp3",
              "duration": 180,
              "recorded_at": "2024-01-15T10:30:00Z"
            },
            {
              "id": "rec_2",
              "url": "https://example.com/recording2.mp3",
              "duration": 245,
              "recorded_at": "2024-01-10T09:15:00Z"
            }
          ],
          "created_by": "Auto Import",
          "created_at": "2024-01-10T08:00:00Z",
          "notes": "High value client - enterprise background"
        }
      });
    } catch (e) {
      throw Exception('Failed to load client details: $e');
    }
  }

  Future<bool> updateLeadType(String clientId, String leadType) async {
    try {
      // final response = await httpService.put(
      //   '/clients/$clientId/lead-type',
      //    {'lead_type': leadType},
      // );
      
      // // Hot code response
      // return response['status'] ?? true;
      return  true; 
    } catch (e) {
      await Future.delayed(Duration(milliseconds: 500));
      return true;
    }
  }

  Future<bool> reassignAgent(String clientId, String agentId) async {
    try {
      // final response = await httpService.put(
      //   '/clients/$clientId/reassign',
      //    {'agent_id': agentId},
      // );
      
      // // Hot code response
      // return response['status'] ?? true; 
      return  true; 
    } catch (e) {
      // For development, simulate success
      await Future.delayed(Duration(milliseconds: 500));
      return true;
    }
  }

  Future<bool> updateLeadStatus(String clientId, String status, String notes) async {
    try {
      // final response = await httpService.post(
      //   '/clients/$clientId/status',
      //    {
      //     'status': status,
      //     'notes': notes,
      //   },
      // );
      
      // // Hot code response
      // return response['status'] ?? true;
      return  true;
    } catch (e) {
      // For development, simulate success
      await Future.delayed(Duration(milliseconds: 500));
      return true;
    }
  }

  Future<List<Agent>> getAvailableAgents() async {
    try {
      // final response = await httpService.get('/agents/available');
      
      // // Hot code response with sample agents
      // if (response is List) {
      //   return response.map((agent) => Agent.fromJson(agent)).toList();
      // }
      
      // Fallback hot response
      return [
        Agent(id: 'agent_1', name: 'Sarah Wilson', email: 'sarah@company.com'),
        Agent(id: 'agent_2', name: 'Mike Johnson', email: 'mike@company.com'),
        Agent(id: 'agent_3', name: 'Emily Chen', email: 'emily@company.com'),
        Agent(id: 'agent_4', name: 'David Brown', email: 'david@company.com'),
      ];
    } catch (e) {
      // Fallback for development
      return [
        Agent(id: 'agent_1', name: 'Sarah Wilson', email: 'sarah@company.com'),
        Agent(id: 'agent_2', name: 'Mike Johnson', email: 'mike@company.com'),
      ];
    }
  }
}
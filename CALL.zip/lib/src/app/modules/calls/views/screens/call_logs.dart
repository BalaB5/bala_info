import 'package:call_log/call_log.dart';
import 'package:call_tracker/src/core/app_data.dart';
import 'package:call_tracker/src/core/app_icons.dart';
import 'package:call_tracker/src/core/app_style.dart';
import 'package:flutter/material.dart';
import 'package:flutter_phone_direct_caller/flutter_phone_direct_caller.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../../../../../core/enums.dart';
import '../../contoller/call_log_contoller.dart';
import '../../contoller/call_recording_controller.dart';
import '../widgets/call_box.dart';
import '../widgets/call_log_card.dart';

class CallLogs extends GetView<CallLogController> {
  const CallLogs({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        children: [
          const SizedBox(width: 10),
          _buildFilterDropdown(),
          const SizedBox(height: 8),
          _buildCallTypeFilters(),
          const SizedBox(height: 8),
          Expanded(child: _buildCallLogList()),
        ],
      ),
    );
  }

  Widget _buildFilterDropdown() {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(vertical: 4),
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: const BorderRadius.all(Radius.circular(10)),
        boxShadow: AppStyle.boxShadow,
      ),
      child: Obx(
        () => DropdownButton<DateFilterType>(
          value: controller.dateFilter.value,
          underline: const SizedBox(),
          isExpanded: true,
          hint: Text(AppData.callFilterByDay[0]['title']),
          items:
              AppData.callFilterByDay.map<DropdownMenuItem<DateFilterType>>((
                data,
              ) {
                return DropdownMenuItem<DateFilterType>(
                  value: data['value'] as DateFilterType,
                  child: Text(data['title']),
                );
              }).toList(),
          onChanged: (value) => controller.setFilter(selectedDate: value!),
          icon: Icon(
            Icons.keyboard_arrow_down_outlined,
            color: Get.theme.primaryColor,
          ),
        ),
      ),
    );
  }

  Widget _buildCallTypeFilters() {
    return Obx(
      () => Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          CallBox(
            icon: AppIcons.call,
            iconColor: Colors.orange,
            isSelected: controller.filter.value == null,
            count: controller.totalCallsCount.value,
            onTap: () => controller.setFilter(),
          ),
          CallBox(
            icon: AppIcons.incoming,
            iconColor: Colors.green,
            isSelected: controller.filter.value == CallType.incoming,
            count: controller.incomingCallsCount.value,
            onTap: () => controller.setFilter(selectedType: CallType.incoming),
          ),
          CallBox(
            icon: AppIcons.ougoing,
            iconColor: Colors.green,
            isSelected: controller.filter.value == CallType.outgoing,
            count: controller.outgoingCallsCount.value,
            onTap: () => controller.setFilter(selectedType: CallType.outgoing),
          ),
          CallBox(
            icon: AppIcons.missedCall,
            iconColor: Colors.red,
            isSelected: controller.filter.value == CallType.missed,
            count: controller.missedCallsCount.value,
            onTap: () => controller.setFilter(selectedType: CallType.missed),
          ),
        ],
      ),
    );
  }

  Widget _buildCallLogList() {
    final callrecordController = Get.put(
      CallRecordingController(),
    ); // Only once

    return Obx(() {
      if (controller.isLoadCallLog.value) {
        return const Center(child: CircularProgressIndicator());
      }

      final grouped = controller.filteredLogs;
      if (grouped.isEmpty) {
        return const Center(child: Text("No call logs found."));
      }

      return RefreshIndicator(
        onRefresh: () => controller.refreshLog(),
        child: ListView.separated(
          physics: const AlwaysScrollableScrollPhysics(),
          itemCount: grouped.length,
          separatorBuilder: (_, __) => const SizedBox(height: 8),
          itemBuilder: (context, index) {
            final date = grouped.keys.elementAt(index);
            final entries = grouped[date]!;

            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.all(10),
                  child: Text(
                    date,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                ...entries.map((entry) {
                  return FutureBuilder<String?>(
                    future: callrecordController.findRecordingByCallLog(
                      number: entry.number ?? '',
                      timestamp: entry.timestamp ?? 0,
                      duration: entry.duration,
                      name: entry.name,
                      dateKey:
                          date, // pass the date string like "July 08, 2025"
                    ),
                    builder: (context, snapshot) {
                      final audioPath =
                          snapshot.connectionState == ConnectionState.done
                              ? snapshot.data
                              : null;

                      return CallLogCard(
                        name:
                            entry.name?.isNotEmpty == true
                                ? entry.name!
                                : entry.number.toString(),
                        duration: entry.duration.toString(),
                        startTime: DateFormat('hh:mm a').format(
                          DateTime.fromMillisecondsSinceEpoch(
                            entry.timestamp ?? 0,
                          ),
                        ),
                        ontop: () {
                          FlutterPhoneDirectCaller.callNumber(
                            entry.number.toString(),
                          );
                        },
                        endTime: entry.timestamp.toString(),
                        callType: entry.callType!,
                        audioPath: audioPath,
                      );
                    },
                  );
                 
                }),
              ],
            );
          },
        ),
      );
    });
  }
}

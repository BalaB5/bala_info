import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../../contoller/client_detail_controller.dart';
import '../../model/client_detail_model.dart';

class ClientDetailScreen extends GetView<ClientDetailController> {
  const ClientDetailScreen({super.key, });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('title'.tr),
        actions: [
          IconButton(
            onPressed: controller.navigateToEditScreen,
            icon: Icon(Icons.edit),
            tooltip: 'Edit',
          ),
        ],
      ),
      body: Obx(() {
        if (controller.isLoading.value) {
          return Center(child: CircularProgressIndicator());
        }

        if (controller.error.value.isNotEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(controller.error.value),
                SizedBox(height: 16),
                ElevatedButton(
                  onPressed: controller.loadClientDetail,
                  child: Text('retry'.tr),
                ),
              ],
            ),
          );
        }

        final client = controller.clientData.value;
        if (client == null) {
          return Center(child: Text('no_data'.tr));
        }

        return _buildContent(client);
      }),
    );
  }

  Widget _buildContent(ClientDetailData client) {
    return SingleChildScrollView(
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildProfileSection(client),
          SizedBox(height: 16),
          _buildContactActions(),
          SizedBox(height: 16),
          _buildLeadTypeSection(client),
          SizedBox(height: 16),
          _buildAssignedAgentSection(client.assignedAgent),
          SizedBox(height: 16),
          _buildLeadStatusSection(client.currentStatus),
          SizedBox(height: 16),
          _buildRecordingsSection(client.recordings),
          SizedBox(height: 16),
          _buildCreationInfo(client),
        ],
      ),
    );
  }

  Widget _buildProfileSection(ClientDetailData client) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Row(
          children: [
            CircleAvatar(
              radius: 30,
              backgroundColor: Get.theme.primaryColor,
              child: Text(
                _getInitials(client.name),
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    client.name,
                    style: Get.theme.textTheme.titleLarge,
                  ),
                  SizedBox(height: 4),
                  Text(
                    client.email,
                    style: Get.theme.textTheme.bodyMedium,
                  ),
                  SizedBox(height: 4),
                  Text(
                    client.phone,
                    style: Get.theme.textTheme.bodyMedium,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContactActions() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _buildActionButton(Icons.call, 'Call', controller.launchPhoneCall),
            _buildActionButton(Icons.sms, 'SMS', controller.launchSMS),
            _buildActionButton(Icons.chat, 'WhatsApp', controller.launchWhatsApp),
            _buildActionButton(Icons.email, 'Mail', controller.launchEmail),
          ],
        ),
      ),
    );
  }

  Widget _buildActionButton(IconData icon, String label, VoidCallback onTap) {
    return Column(
      children: [
        IconButton(
          onPressed: onTap,
          icon: Icon(icon),
          color: Get.theme.primaryColor,
          iconSize: 28,
        ),
        SizedBox(height: 4),
        Text(
          label,
          style: Get.theme.textTheme.bodySmall,
        ),
      ],
    );
  }

  Widget _buildLeadTypeSection(ClientDetailData client) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'lead_type'.tr,
              style: Get.theme.textTheme.titleMedium!.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 12),
            Wrap(
              spacing: 8,
              children: [
                'Hot',
                'Warm', 
                'Cold',
                'Highlight',
                'Escalated',
              ].map((type) {
                return FilterChip(
                  label: Text(type),
                  selected: client.leadType == type,
                  onSelected: (_) => controller.updateLeadType(type),
                  selectedColor: Get.theme.primaryColor.withOpacity(0.2),
                  checkmarkColor: Get.theme.primaryColor,
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAssignedAgentSection(Agent agent) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'assigned_to'.tr,
                  style: Get.theme.textTheme.titleMedium!.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                TextButton(
                  onPressed: controller.openAgentSelectionSheet,
                  child: Text('reassign'.tr),
                ),
              ],
            ),
            SizedBox(height: 12),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: CircleAvatar(
                radius: 20,
                backgroundColor: Get.theme.primaryColor,
                child: Text(
                  _getInitials(agent.name),
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                  ),
                ),
              ),
              title: Text(agent.name),
              subtitle: Text(agent.email),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLeadStatusSection(LeadStatus status) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'lead_status'.tr,
                  style: Get.theme.textTheme.titleMedium!.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                TextButton(
                  onPressed: controller.openStatusUpdateSheet,
                  child: Text('change_status'.tr),
                ),
              ],
            ),
            SizedBox(height: 12),
            Text(
              status.status,
              style: Get.theme.textTheme.bodyLarge!.copyWith(
                fontWeight: FontWeight.w500,
              ),
            ),
            SizedBox(height: 8),
            Obx(() {
              final isExpanded = controller.isNotesExpanded.value;
              final notes = status.notes;
              
              if (notes.isEmpty) {
                return Text(
                  'no_notes'.tr,
                  style: Get.theme.textTheme.bodySmall,
                );
              }

              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    notes,
                    maxLines: isExpanded ? null : 3,
                    overflow: TextOverflow.ellipsis,
                  ),
                  if (notes.length > 100) ...[
                    SizedBox(height: 8),
                    GestureDetector(
                      onTap: controller.toggleNotesExpanded,
                      child: Text(
                        isExpanded ? 'Read less' : 'Read more',
                        style: TextStyle(
                          color: Get.theme.primaryColor,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ],
                ],
              );
            }),
            SizedBox(height: 8),
            Text(
              '${'updated_on'.tr} ${_formatDate(status.updatedAt)}',
              style: Get.theme.textTheme.bodySmall,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRecordingsSection(List<Recording> recordings) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'recordings'.tr,
                  style: Get.theme.textTheme.titleMedium!.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                if (recordings.length > 3)
                  TextButton(
                    onPressed: controller.navigateToRecordings,
                    child: Text('view_all'.tr),
                  ),
              ],
            ),
            SizedBox(height: 12),
            if (recordings.isEmpty)
              Text(
                'no_recordings'.tr,
                style: Get.theme.textTheme.bodySmall,
              )
            else
              ...recordings.take(3).map((recording) => _buildRecordingItem(recording)),
          ],
        ),
      ),
    );
  }

  Widget _buildRecordingItem(Recording recording) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: Icon(Icons.audiotrack, color: Get.theme.primaryColor),
      title: Text(_formatDuration(recording.duration)),
      subtitle: Text(_formatDate(recording.recordedAt)),
      trailing: IconButton(
        icon: Icon(Icons.play_arrow),
        onPressed: () {
          // Implement playback
          // controller.showToast('Playing recording');
        },
      ),
    );
  }

  Widget _buildCreationInfo(ClientDetailData client) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'created_info'.tr,
              style: Get.theme.textTheme.bodySmall,
            ),
            SizedBox(height: 4),
            Text(client.createdBy),
            Text(_formatDate(client.createdAt)),
          ],
        ),
      ),
    );
  }

  String _getInitials(String name) {
    return name.isNotEmpty
        ? name.trim().split(' ').map((l) => l[0]).take(2).join()
        : '?';
  }

  String _formatDate(DateTime date) {
    return DateFormat('MMM dd, yyyy - HH:mm').format(date);
  }

  String _formatDuration(int seconds) {
    final duration = Duration(seconds: seconds);
    return '${duration.inMinutes}:${(duration.inSeconds % 60).toString().padLeft(2, '0')}';
  }
}
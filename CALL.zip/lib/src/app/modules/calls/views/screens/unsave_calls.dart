import 'package:call_tracker/src/app/modules/calls/contoller/call_log_contoller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../../../../utils/routes/app_pages.dart';
import '../widgets/call_log_card.dart';

class UnsaveCalls extends GetView<CallLogController> {
  const UnsaveCalls({super.key});

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: () async => controller.fetchUnsavedCallLogs(),
      child: Obx(() {
        if (controller.isLoadUnsaveCallLog.value) {
          return const Center(child: CircularProgressIndicator());
        }

        final grouped = controller.groupedUnSaveLogsByDate();
        if (grouped.isEmpty) {
          return const Center(child: Text("No call logs found."));
        }

        return ListView.separated(
          padding: const EdgeInsets.symmetric(vertical: 0, horizontal: 10),
          itemCount: grouped.length * 2 - 1,
          separatorBuilder: (_, index) => const SizedBox(height: 5),
          itemBuilder: (context, index) {
            if (index.isOdd) return const SizedBox.shrink();

            final dateIndex = index ~/ 2;
            final date = grouped.keys.elementAt(dateIndex);
            final entries = grouped[date]!;

            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.all(10),
                  child: Text(
                    date,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                ...entries.map(
                  (entry) => CallLogCard(
                    name:
                        entry.name?.isNotEmpty == true
                            ? entry.name!
                            : entry.number.toString(),
                    duration: entry.duration.toString(),
                    startTime: DateFormat('hh:mm a').format(
                      DateTime.fromMillisecondsSinceEpoch(entry.timestamp ?? 0),
                    ),
                    endTime: entry.timestamp.toString(),
                    callType: entry.callType!,
                    save:
                        () => Get.toNamed(
                          AppPages.addLead,
                          arguments: entry.number.toString(),
                        ),
                  ),
                ),
              ],
            );
          },
        );
      }),
    );
  }
}

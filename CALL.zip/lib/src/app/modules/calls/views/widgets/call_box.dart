import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../../core/app_style.dart';

class CallBox extends StatelessWidget {
  const CallBox({
    super.key,
    required this.icon,
    required this.iconColor,
    required this.count,
    this.isSelected = false,
    this.onTap,
    this.color,
  });

  final String icon;
  final Color? color;
  final bool isSelected;
  final MaterialColor iconColor;
  final int count;
  final Function()? onTap;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        child: LayoutBuilder(
          builder: (context, constraints) {
            return SizedBox(
              height: Get.size.width > 600 ? 150 : constraints.maxWidth - 10,
              width: Get.size.width > 600 ? 150 : constraints.maxWidth,

              child: Container(
                margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 10),
                padding: const EdgeInsets.all(5),
                decoration: BoxDecoration(
                  color:
                      isSelected
                          ? Get.theme.colorScheme.secondaryContainer
                          : Colors.white,

                  borderRadius: BorderRadius.circular(10),
                  boxShadow: (!isSelected) ? AppStyle.boxShadow : [],
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Image.asset(
                      icon,
                      width: AppStyle.iconsize,
                      height: AppStyle.iconsize,
                    ),

                    const SizedBox(height: 5),
                    Text(
                      count.toString(),
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

import 'package:call_log/call_log.dart';
import 'package:call_tracker/src/core/app_data.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../core/app_colors.dart';
import '../../../../../core/app_icons.dart';
import '../../../../../core/app_style.dart';
import '../../../../utils/routes/app_pages.dart';
import '../../../../utils/utils.dart';

class CallLogCard extends StatelessWidget {
  const CallLogCard({
    super.key,
    required this.name,
    required this.duration,
    required this.callType,
    required this.startTime,
    this.save,
    this.ontop,
    this.audioPath,
    required this.endTime,
  });

  final String name;
  final String duration;
  final Function()? save;
  final Function()? ontop;
  final CallType callType;

  final String startTime;
  final String endTime;
  final String? audioPath;
 void _showBottomSheet() {
    Get.bottomSheet(
      Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.light_mode),
              title: const Text('Light Theme'),
              onTap: () {
                Get.changeTheme(ThemeData.light());
                Get.back(); // close bottom sheet
              },
            ),
            ListTile(
              leading: const Icon(Icons.dark_mode),
              title: const Text('Dark Theme'),
              onTap: () {
                Get.changeTheme(ThemeData.dark());
                Get.back();
              },
            ),
          ],
        ),
      ),
      backgroundColor: Colors.transparent,
      isScrollControlled: false,
    );
  }
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap:(){
        Get.toNamed( AppPages.callLogDetails);
      },
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 4),
        padding: const EdgeInsets.all(5),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.all(Radius.circular(10)),
          boxShadow: AppStyle.boxShadow,
        ),
        child: Column(
          children: [
            Row(
              children: [
                // const SizedBox(width: 10),
                //  if (save != null)
                InkWell(
                  onTap: save,
                  child: Stack(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(5),
                        child: CircleAvatar(
                          backgroundColor: Get.theme.primaryColor.withAlpha(50),
                          child: Image.asset(
                            AppIcons.user3,
                            width: AppStyle.iconsize,
                            height: AppStyle.iconsize,
                          ),
                        ),
                      ),
                      Positioned(bottom: 0, right: 0, child: Text("😊")),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  flex: 3,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        name,
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: Get.theme.textTheme.titleMedium!.fontSize,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 3),
                        child: Row(
                          children: [
                            Icon(
                              Icons.access_time,
                              color: Get.theme.primaryColor,
                            ),
                            // Image.asset(AppIcons.time2,width: AppStyle.iconsize2,height: AppStyle.iconsize2,),
                            Row(
                              children: [
                                Text(
                                  callType == CallType.missed
                                      ? "00:00"
                                      : Utils.formatDuration(
                                        int.tryParse(duration) ?? 0,
                                      ),
                                ),
                                if (audioPath != null) ...[
                                  Container(
                                    decoration: AppStyle.decoration.copyWith(
                                      color: Colors.red.withAlpha(50),
                                      boxShadow: [],
                                    ),
                                    padding: EdgeInsets.symmetric(
                                      horizontal: 4,
                                      vertical: 2,
                                    ),
                                    margin: EdgeInsets.symmetric(horizontal: 4),
                                    child: Row(
                                      children: [
                                        Icon(
                                          Icons.circle,
                                          color: Colors.red,
                                          size: 8,
                                        ),
                                        Text(
                                          "RCE",
                                          style: TextStyle(
                                            color: Colors.black,
                                            fontSize: 9,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  // LocalAudioPlayer(audioPath: audioPath!),
                                ],
                              ],
                            ),
                          ],
                        ),
                      ),
                      Row(
                        children: [
                          InkWell(
                            onTap: (){
                              _showBottomSheet();
                            },
                            child: Container(
                              decoration: AppStyle.decoration.copyWith(
                                color: Colors.green.withAlpha(50),
                                boxShadow: [],
                              ),
                              padding: EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 4,
                              ),
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.add,
                                    color: Colors.green,
                                    size: 15,
                                  ),
                                  Text(
                                    "Add Tag",
                                    style: TextStyle(
                                      color: Colors.green,
                                      fontWeight: FontWeight.w600,
                                      fontSize: 13,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Spacer(),

                          // Row(
                          //   children: [
                          //     IconButton(onPressed: (){}, icon: Icon(Icons.mic)),
                          //   ],
                          // )
                        ],
                      ),
                    ],
                  ),
                ),
                Expanded(
                  flex: 1,
                  child: Column(
                    children: [
                      AppColors.getCallTypeIcon(callType),
                      Text(startTime),
                    ],
                  ),
                ),
              ],
            ),

            // if (audioPath != null) LocalAudioPlayer(audioPath: audioPath!),
          ],
        ),
      ),
    );
  }
}

class ClientDetailResponse {
  final bool status;
  final String message;
  final ClientDetailData data;

  ClientDetailResponse({
    required this.status,
    required this.message,
    required this.data,
  });

  factory ClientDetailResponse.fromJson(Map<String, dynamic> json) {
    return ClientDetailResponse(
      status: json['status'] ?? false,
      message: json['message'] ?? '',
      data: ClientDetailData.fromJson(json['data'] ?? {}),
    );
  }
}

class ClientDetailData {
  final String id;
  final String name;
  final String email;
  final String phone;
  final String leadType;
  final Agent assignedAgent;
  final LeadStatus currentStatus;
  final List<LeadStatus> statusHistory;
  final List<Recording> recordings;
  final String createdBy;
  final DateTime createdAt;
  final String? notes;

  ClientDetailData({
    required this.id,
    required this.name,
    required this.email,
    required this.phone,
    required this.leadType,
    required this.assignedAgent,
    required this.currentStatus,
    required this.statusHistory,
    required this.recordings,
    required this.createdBy,
    required this.createdAt,
    this.notes,
  });

  factory ClientDetailData.fromJson(Map<String, dynamic> json) {
    return ClientDetailData(
      id: json['id'] ?? '',
      name: json['name'] ?? '',
      email: json['email'] ?? '',
      phone: json['phone'] ?? '',
      leadType: json['lead_type'] ?? 'Warm',
      assignedAgent: Agent.fromJson(json['assigned_agent'] ?? {}),
      currentStatus: LeadStatus.fromJson(json['current_status'] ?? {}),
      statusHistory: List<LeadStatus>.from(
          (json['status_history'] ?? []).map((x) => LeadStatus.fromJson(x))),
      recordings: List<Recording>.from(
          (json['recordings'] ?? []).map((x) => Recording.fromJson(x))),
      createdBy: json['created_by'] ?? '',
      createdAt: DateTime.parse(json['created_at'] ?? DateTime.now().toString()),
      notes: json['notes'],
    );
  }
}

class Agent {
  final String id;
  final String name;
  final String email;
  final String? avatar;

  Agent({
    required this.id,
    required this.name,
    required this.email,
    this.avatar,
  });

  factory Agent.fromJson(Map<String, dynamic> json) {
    return Agent(
      id: json['id'] ?? '',
      name: json['name'] ?? '',
      email: json['email'] ?? '',
      avatar: json['avatar'],
    );
  }
}

class LeadStatus {
  final String status;
  final String notes;
  final DateTime updatedAt;
  final String updatedBy;

  LeadStatus({
    required this.status,
    required this.notes,
    required this.updatedAt,
    required this.updatedBy,
  });

  factory LeadStatus.fromJson(Map<String, dynamic> json) {
    return LeadStatus(
      status: json['status'] ?? '',
      notes: json['notes'] ?? '',
      updatedAt: DateTime.parse(json['updated_at'] ?? DateTime.now().toString()),
      updatedBy: json['updated_by'] ?? '',
    );
  }
}

class Recording {
  final String id;
  final String url;
  final int duration;
  final DateTime recordedAt;

  Recording({
    required this.id,
    required this.url,
    required this.duration,
    required this.recordedAt,
  });

  factory Recording.fromJson(Map<String, dynamic> json) {
    return Recording(
      id: json['id'] ?? '',
      url: json['url'] ?? '',
      duration: json['duration'] ?? 0,
      recordedAt: DateTime.parse(json['recorded_at'] ?? DateTime.now().toString()),
    );
  }
}
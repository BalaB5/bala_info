import 'package:get/get.dart';

import '../contoller/client_detail_controller.dart';
import '../repository/client_detail_repository.dart';

class ClientDetailBinding extends Bindings {
  ClientDetailBinding();

  @override
  void dependencies() {
    Get.lazyPut<ClientDetailController>(() => ClientDetailController());
    Get.lazyPut<ClientDetailRepository>(() => ClientDetailRepository());
  }
}

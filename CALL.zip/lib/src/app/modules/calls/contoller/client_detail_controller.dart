import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../model/client_detail_model.dart';
import '../repository/client_detail_repository.dart';

class ClientDetailController extends GetxController {
  final ClientDetailRepository repository = Get.find();
  RxString clientId = "0".obs;

  ClientDetailController();

  final Rx<ClientDetailData?> clientData = Rx<ClientDetailData?>(null);
  final RxBool isLoading = false.obs;
  final RxString error = ''.obs;
  final RxBool isNotesExpanded = false.obs;

  final RxList<Agent> availableAgents = <Agent>[].obs;
  @override
  void onInit() {
    super.onInit();

    loadAvailableAgents();
    loadClientDetail();
  }

  Future<void> loadClientDetail() async {
    try {
      isLoading.value = true;
      error.value = '';

      final response = await repository.getClientDetail(clientId.value);

      if (response.status) {
        clientData.value = response.data;
      } else {
        error.value = response.message;
        _showToast(response.message, isError: true);
      }
    } catch (e) {
      error.value = e.toString();
      _showToast('Failed to load client details', isError: true);
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> updateLeadType(String leadType) async {
    try {
      final success = await repository.updateLeadType(clientId.value, leadType);

      if (success) {
        // Update local state
        final currentData = clientData.value;
        if (currentData != null) {
          clientData.value = ClientDetailData(
            id: currentData.id,
            name: currentData.name,
            email: currentData.email,
            phone: currentData.phone,
            leadType: leadType,
            assignedAgent: currentData.assignedAgent,
            currentStatus: currentData.currentStatus,
            statusHistory: currentData.statusHistory,
            recordings: currentData.recordings,
            createdBy: currentData.createdBy,
            createdAt: currentData.createdAt,
            notes: currentData.notes,
          );
        }
        _showToast('Lead type updated successfully');
      } else {
        _showToast('Failed to update lead type', isError: true);
      }
    } catch (e) {
      _showToast('Failed to update lead type', isError: true);
    }
  }

  Future<void> loadAvailableAgents() async {
    try {
      final agents = await repository.getAvailableAgents();
      availableAgents.value = agents;
    } catch (e) {
      // Silent fail for agents, as it's not critical
      print('Failed to load agents: $e');
    }
  }

  Future<void> reassignAgent(String agentId) async {
    try {
      final success = await repository.reassignAgent(clientId.value, agentId);

      if (success) {
        await loadClientDetail(); // Reload to get updated agent data
        _showToast('Agent reassigned successfully');
      } else {
        _showToast('Failed to reassign agent', isError: true);
      }
    } catch (e) {
      _showToast('Failed to reassign agent', isError: true);
    }
  }

  Future<void> updateLeadStatus(String status, String notes) async {
    try {
      final success = await repository.updateLeadStatus(
        clientId.value,
        status,
        notes,
      );

      if (success) {
        await loadClientDetail(); // Reload to get updated status
        Get.back(); // Close the bottom sheet
        _showToast('Status updated successfully');
      } else {
        _showToast('Failed to update status', isError: true);
      }
    } catch (e) {
      _showToast('Failed to update status', isError: true);
    }
  }

  void toggleNotesExpanded() {
    isNotesExpanded.value = !isNotesExpanded.value;
  }

  void launchPhoneCall() {
    final phone = clientData.value?.phone;
    if (phone != null && phone.isNotEmpty) {
      // Use url_launcher in real implementation
      _showToast('Launching call to $phone');
    } else {
      _showToast('Phone number not available', isError: true);
    }
  }

  void launchSMS() {
    final phone = clientData.value?.phone;
    if (phone != null && phone.isNotEmpty) {
      _showToast('Launching SMS to $phone');
    } else {
      _showToast('Phone number not available', isError: true);
    }
  }

  void launchWhatsApp() {
    final phone = clientData.value?.phone;
    if (phone != null && phone.isNotEmpty) {
      _showToast('Launching WhatsApp to $phone');
    } else {
      _showToast('Phone number not available', isError: true);
    }
  }

  void launchEmail() {
    final email = clientData.value?.email;
    if (email != null && email.isNotEmpty) {
      _showToast('Launching email to $email');
    } else {
      _showToast('Email not available', isError: true);
    }
  }

  void navigateToEditScreen() {
    final client = clientData.value;
    if (client != null) {
      Get.toNamed('/client-edit', arguments: {'client': client});
    }
  }

  void navigateToRecordings() {
    final client = clientData.value;
    if (client != null) {
      Get.toNamed('/client-recordings', arguments: {'clientId': client.id});
    }
  }

  void openStatusUpdateSheet() {
    Get.bottomSheet(
      StatusUpdateSheet(controller: this),
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
    );
  }

  void openAgentSelectionSheet() {
    Get.bottomSheet(
      AgentSelectionSheet(controller: this),
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
    );
  }

  void _showToast(String message, {bool isError = false}) {
    // Fluttertoast.showToast(
    //   msg: message,
    //   toastLength: Toast.LENGTH_SHORT,
    //   gravity: ToastGravity.BOTTOM,
    //   backgroundColor: isError ? Colors.red : Colors.green,
    //   textColor: Colors.white,
    // );
  }
}

class AgentSelectionSheet extends StatelessWidget {
  final ClientDetailController controller;

  const AgentSelectionSheet({Key? key, required this.controller})
    : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      child: Container(
        padding: EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            SizedBox(height: 16),
            Text('Reassign Lead', style: Get.theme.textTheme.titleLarge),
            SizedBox(height: 8),
            Text(
              'Select a new agent for this client',
              style: Get.theme.textTheme.bodyMedium,
            ),
            SizedBox(height: 16),
            Obx(() {
              final agents = controller.availableAgents;
              final currentAgentId =
                  controller.clientData.value?.assignedAgent.id;

              if (agents.isEmpty) {
                return Center(child: CircularProgressIndicator());
              }

              return ListView.builder(
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                itemCount: agents.length,
                itemBuilder: (context, index) {
                  final agent = agents[index];
                  return Card(
                    margin: EdgeInsets.symmetric(vertical: 4),
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundColor: Get.theme.primaryColor,
                        child: Text(
                          _getInitials(agent.name),
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                      title: Text(agent.name),
                      subtitle: Text(agent.email),
                      trailing:
                          currentAgentId == agent.id
                              ? Icon(Icons.check_circle, color: Colors.green)
                              : null,
                      onTap: () {
                        if (currentAgentId != agent.id) {
                          controller.reassignAgent(agent.id);
                        }
                      },
                    ),
                  );
                },
              );
            }),
            SizedBox(height: 16),
            OutlinedButton(
              onPressed: () => Get.back(),
              child: Center(child: Text('Cancel')),
            ),
            SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  String _getInitials(String name) {
    return name.isNotEmpty
        ? name.trim().split(' ').map((l) => l[0]).take(2).join()
        : '?';
  }
}

class StatusUpdateSheet extends StatefulWidget {
  final ClientDetailController controller;

  const StatusUpdateSheet({Key? key, required this.controller})
    : super(key: key);

  @override
  _StatusUpdateSheetState createState() => _StatusUpdateSheetState();
}

class _StatusUpdateSheetState extends State<StatusUpdateSheet> {
  final _formKey = GlobalKey<FormState>();
  final _notesController = TextEditingController();
  String _selectedStatus = 'Contacted';

  final List<String> statusOptions = [
    'New Lead',
    'Contacted',
    'Qualified',
    'Proposal Sent',
    'Negotiation',
    'Closed Won',
    'Closed Lost',
    'On Hold',
  ];

  @override
  void dispose() {
    _notesController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      child: Container(
        padding: EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            SizedBox(height: 16),
            Text('Update Lead Status', style: Get.theme.textTheme.titleLarge),
            SizedBox(height: 16),
            Form(
              key: _formKey,
              child: Column(
                children: [
                  DropdownButtonFormField<String>(
                    value: _selectedStatus,
                    decoration: InputDecoration(
                      labelText: 'Status',
                      border: OutlineInputBorder(),
                    ),
                    items:
                        statusOptions.map((String status) {
                          return DropdownMenuItem<String>(
                            value: status,
                            child: Text(status),
                          );
                        }).toList(),
                    onChanged: (String? newValue) {
                      setState(() {
                        _selectedStatus = newValue!;
                      });
                    },
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please select a status';
                      }
                      return null;
                    },
                  ),
                  SizedBox(height: 16),
                  TextFormField(
                    controller: _notesController,
                    maxLines: 4,
                    decoration: InputDecoration(
                      labelText: 'Notes',
                      border: OutlineInputBorder(),
                      alignLabelWithHint: true,
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter notes';
                      }
                      if (value.length < 10) {
                        return 'Notes should be at least 10 characters';
                      }
                      return null;
                    },
                  ),
                  SizedBox(height: 24),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () => Get.back(),
                          child: Text('Cancel'),
                        ),
                      ),
                      SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton(
                          onPressed: _submitForm,
                          child: Text('Update Status'),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      widget.controller.updateLeadStatus(
        _selectedStatus,
        _notesController.text,
      );
    }
  }
}

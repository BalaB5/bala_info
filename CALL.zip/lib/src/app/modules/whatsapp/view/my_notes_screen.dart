import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../controller/my_notes_controller.dart';
import '../model/note_model.dart';

class MyNotesScreen extends GetView<MyNotesController> {
  const MyNotesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('title'.tr),
        actions: [
          IconButton(
            icon: CircleAvatar(
              radius: 16,
              backgroundColor: Get.theme.primaryColor,
              child: Text(
                'U',
                style: TextStyle(color: Colors.white, fontSize: 12),
              ),
            ),
            onPressed: () {
              // Navigate to profile
            },
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            _buildSearchSection(),
            _buildCategoryFilter(),
            _buildNotesList(),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => controller.navigateToNoteEditor(),
        child: Icon(Icons.add),
        backgroundColor: Get.theme.primaryColor,
      ),
    );
  }

  Widget _buildSearchSection() {
    return Padding(
      padding: EdgeInsets.all(16),
      child: TextField(
        onChanged: controller.onSearchChanged,
        decoration: InputDecoration(
          hintText: 'search_hint'.tr,
          prefixIcon: Icon(Icons.search),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          contentPadding: EdgeInsets.symmetric(vertical: 12, horizontal: 16),
        ),
      ),
    );
  }

  Widget _buildCategoryFilter() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 16),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: controller.categories.map((category) {
            final isSelected = controller.selectedCategory.value == category;
            return Padding(
              padding: EdgeInsets.only(right: 8),
              child: FilterChip(
                label: Text(category),
                selected: isSelected,
                onSelected: (_) => controller.onCategoryChanged(category),
                selectedColor: Get.theme.primaryColor.withOpacity(0.2),
                checkmarkColor: Get.theme.primaryColor,
                backgroundColor: Colors.grey[100],
                labelStyle: TextStyle(
                  color: isSelected ? Get.theme.primaryColor : Colors.grey[700],
                ),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }

  Widget _buildNotesList() {
    return Expanded(
      child: Obx(() {
        if (controller.isLoading.value) {
          return Center(child: CircularProgressIndicator());
        }

        if (controller.error.value.isNotEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(controller.error.value),
                SizedBox(height: 16),
                ElevatedButton(
                  onPressed: controller.loadNotes,
                  child: Text('retry'.tr),
                ),
              ],
            ),
          );
        }

        if (controller.filteredNotes.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.note_add, size: 64, color: Colors.grey[400]),
                SizedBox(height: 16),
                Text(
                  'no_notes'.tr,
                  style: Get.theme.textTheme.bodyMedium,
                ),
              ],
            ),
          );
        }

        return Padding(
          padding: EdgeInsets.all(16),
          child: ListView.builder(
            itemCount: controller.filteredNotes.length,
            itemBuilder: (context, index) {
              final note = controller.filteredNotes[index];
              return _buildNoteCard(note);
            },
          ),
        );
      }),
    );
  }

  Widget _buildNoteCard(Note note) {
    return Card(
      elevation: 2,
      margin: EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ListTile(
        contentPadding: EdgeInsets.all(16),
        leading: Icon(
          _getCategoryIcon(note.category),
          color: _getCategoryColor(note.category),
          size: 32,
        ),
        title: Text(
          note.title,
          style: Get.theme.textTheme.titleMedium!.copyWith(
            fontWeight: FontWeight.w600,
          ),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 4),
            Text(
              note.content,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: Get.theme.textTheme.bodyMedium,
            ),
            SizedBox(height: 8),
            Row(
              children: [
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: _getCategoryColor(note.category).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    note.category,
                    style: TextStyle(
                      color: _getCategoryColor(note.category),
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
                Spacer(),
                if (note.isBookmarked)
                  Icon(Icons.bookmark, color: Colors.amber, size: 16),
                SizedBox(width: 4),
                Text(
                  _formatDate(note.updatedAt),
                  style: Get.theme.textTheme.bodySmall,
                ),
              ],
            ),
          ],
        ),
        onTap: () => controller.navigateToNoteDetail(note),
        onLongPress: () {
          _showDeleteDialog(note);
        },
      ),
    );
  }

  void _showDeleteDialog(Note note) {
    Get.dialog(
      AlertDialog(
        title: Text('Delete Note'),
        content: Text('Are you sure you want to delete "${note.title}"?'),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Get.back();
              controller.deleteNote(note.id);
            },
            child: Text(
              'Delete',
              style: TextStyle(color: Colors.red),
            ),
          ),
        ],
      ),
    );
  }

  IconData _getCategoryIcon(String category) {
    switch (category) {
      case 'Work':
        return Icons.work;
      case 'Personal':
        return Icons.person;
      case 'Family':
        return Icons.family_restroom;
      default:
        return Icons.note;
    }
  }

  Color _getCategoryColor(String category) {
    switch (category) {
      case 'Work':
        return Colors.blue;
      case 'Personal':
        return Colors.green;
      case 'Family':
        return Colors.orange;
      default:
        return Get.theme.primaryColor;
    }
  }

  String _formatDate(DateTime date) {
    return DateFormat('MMM dd, yyyy').format(date);
  }
}
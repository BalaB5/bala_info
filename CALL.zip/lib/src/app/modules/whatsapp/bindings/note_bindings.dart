import 'package:get/get.dart';

import '../controller/my_notes_controller.dart';
import '../controller/note_detail_controller.dart';
import '../repository/note_repository.dart';

class MyNotesBinding extends Bindings {
  @override
  void dependencies() {
     Get.lazyPut<NoteRepository>(
      () => NoteRepository( ),
    );
    
    Get.lazyPut<MyNotesController>(
      () => MyNotesController(),
    );
  }
}

class NoteDetailBinding extends Bindings {
  

  NoteDetailBinding();

  @override
  void dependencies() {
     Get.lazyPut<NoteRepository>(
      () => NoteRepository( ),
    );
    Get.lazyPut<NoteDetailController>(
      () => NoteDetailController( ),
    ); 
   
  }
}
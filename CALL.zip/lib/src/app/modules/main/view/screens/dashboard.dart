import 'package:call_tracker/src/core/app_icons.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../utils/routes/app_pages.dart';
import '../../../../../core/app_style.dart';
import '../../../calls/contoller/call_log_contoller.dart';
import '../../../followups/contoller/followup_controller.dart';
import '../../../followups/views/widgets/followup_card.dart';
import '../../../followups/views/screens/followup_detail_page.dart';
import '../widgets/action_button.dart';
import '../widgets/summary_card.dart';

class Dashboard extends StatefulWidget {
  const Dashboard({super.key});

  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  final followUpController = Get.put(FollowUpController());
  final callLogsController = Get.put(CallLogController());
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 8, horizontal: 10),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          InkWell(
            onTap: (){
              Get.toNamed(AppPages.notes);
            },
            child: Padding(
              padding: EdgeInsets.symmetric(vertical: 4),
              child: Text(
                "Hi  Bala!🖐..",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
              ),
            ),
          ),

          // Summary Cards
          Obx(() {
            return Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                SummaryCard(
                  title: 'Today Calls',
                  value: callLogsController.todayOverallCallCount.value.toString(),
                  icon: AppIcons.call,
                  color:  Get.theme.primaryColor,
                ),
                SummaryCard(
                  title: 'FollowUps',
                  value:
                      '${followUpController.todayUpdatedFollowUpsCount.value} / ${followUpController.todayOverallFollowUpsCount.value}',
                  icon:AppIcons.analitics ,
                  color:  Colors.blue,
                ),
                SummaryCard(
                  title: 'Pending',
                  value:
                      followUpController.todayPendingFollowUpsCount.value
                          .toString(),
                          color: Colors.indigo,
                  icon:AppIcons.chart
                ),
              ],
            );
          }),
          const SizedBox(height: 5),

          // Quick Actions
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              ActionButton(
                icon: AppIcons.addCall,
                label: 'Add Follow Up',
                  color:   Get.theme.primaryColor,
                onTap: () {
                  Get.toNamed(AppPages.addFollowup);
                },
              ),
              ActionButton(
                icon:  AppIcons.userAdd2,
                label: 'Add Lead',
                  color: Colors.blue,
                onTap: () {
                  Get.toNamed(AppPages.addLead);
                },
              ),
              ActionButton(
                icon:  AppIcons.calendar,
                label: 'Follow Ups',
                 color: Colors.indigo,
                onTap: () {
                  Get.toNamed(AppPages.followups);
                },
              ),
            ],
          ),
          // const SizedBox(height: 10),

          // Lead List Title
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Today\'s remainder',
                style: Get.theme.textTheme.titleLarge!.copyWith(
                  color: Get.theme.primaryColor,
                  fontWeight: FontWeight.bold,
                ),
              ),
              IconButton(
                onPressed: () {
                  Get.toNamed(AppPages.todayFollowups);
                },
                icon: Image.asset(AppIcons.list1,width: AppStyle.iconsize2,height: AppStyle.iconsize2,),
              ),
            ],
          ),
          const SizedBox(height: 5),

          // Lead List
          Expanded(
            child: Obx(() {
              return ListView.builder(
                padding: const EdgeInsets.only(bottom: 16),
                itemCount: followUpController.todayFollowUps.length,
                itemBuilder: (context, index) {
                  final followUp = followUpController.todayFollowUps[index];
                  return FollowUpCard(
                    followUp: followUp,
                    onTap:
                        () => Get.to(
                          () => FollowUpDetailPage(followUp: followUp),
                        ),
                  );
                },
              );
            }),
          ),
        ],
      ),
    );
  }
}

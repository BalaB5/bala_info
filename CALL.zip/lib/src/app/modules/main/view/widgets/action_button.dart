import 'package:flutter/material.dart';

import '../../../../../core/app_style.dart';

class ActionButton extends StatelessWidget {
  final String icon;
  final String label;
  final Function()? onTap;
  final Color color;
  const ActionButton({
    super.key,
    required this.icon,
    required this.label,
    required this.onTap,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        InkWell(
          onTap: onTap,
          child: Container(
            decoration: AppStyle.decoration.copyWith(
              color: color.withAlpha(30),
              boxShadow: [],
              borderRadius: BorderRadius.all(
                Radius.circular(AppStyle.borderRadiusbottom),
              ),
            ),
            padding: const EdgeInsets.all(15),
            child: Image.asset(
              icon,
              width: AppStyle.iconsize2,
              height: AppStyle.iconsize2,
              color: color,
            ),
          ),
        ),
        const SizedBox(height: 6),
        Text(label, style: TextStyle(fontSize: 12, color: color)),
      ],
    );
  }
}

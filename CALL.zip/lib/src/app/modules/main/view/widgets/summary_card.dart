import 'package:flutter/material.dart';

import '../../../../../core/app_style.dart';

class SummaryCard extends StatelessWidget {
  final String title;
  final String value;
  final String icon;
  final Color color;

  const SummaryCard({
    super.key,
    required this.title,
    required this.value,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: LayoutBuilder(
        builder: (context, constraints) {
          return Container(
            margin: const EdgeInsets.all(10),
            decoration: AppStyle.decoration.copyWith(
              color: color.withAlpha(30),
              boxShadow: [],
            ),
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  // Icon(icon, color: Get.theme.primaryColor),
                  Image.asset(
                    icon,
                    width: AppStyle.iconsize,
                    height: AppStyle.iconsize,
                    color: color,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    value,
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: color,
                    ),
                  ),
                  Text(
                    title,
                    textAlign: TextAlign.center,
                    style: TextStyle(color: color),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

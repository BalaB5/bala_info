// lead_controller.dart
import 'package:get/get.dart';

import '../../../utils/repository/lead_repository.dart';
import '../model/lead_model.dart';

class LeadController extends GetxController {
  final LeadRepository _leadRepository = Get.find();
  final RxList<LeadModel> leads = <LeadModel>[].obs;
  final RxString searchQuery = ''.obs;
  final RxString selectedType = 'All'.obs;

  @override
  void onInit() {
    loadLeads();
    super.onInit();
  }

  void loadLeads() {
    leads.value = _leadRepository.getAllLeads();
  }

  LeadModel? getLeadById(String leadId) {
    return leads.firstWhereOrNull((lead) => lead.id == leadId);
  }

  void searchLeads(String query) {
    searchQuery.value = query;
    if (query.isEmpty && selectedType.value == 'All') {
      loadLeads();
    } else if (query.isEmpty) {
      leads.value = _leadRepository.filterLeadsByType(selectedType.value);
    } else if (selectedType.value == 'All') {
      leads.value = _leadRepository.searchLeads(query);
    } else {
      leads.value =
          _leadRepository
              .filterLeadsByType(selectedType.value)
              .where(
                (lead) => lead.name.toLowerCase().contains(query.toLowerCase()),
              )
              .toList();
    }
  }

  void filterByType(String type) {
    selectedType.value = type;
    if (type == 'All') {
      loadLeads();
    } else {
      leads.value = _leadRepository.filterLeadsByType(type);
    }
  }

  Future<void> addLead(LeadModel lead) async {
    await _leadRepository.addLead(lead);
    loadLeads();
  }

  Future<void> updateLead(LeadModel lead) async {
    await _leadRepository.updateLead(lead);
    loadLeads();
  }

  Future<void> updateLeadStatus(String leadId, String newStatus) async {
    try {
      final lead = _leadRepository.getLeadById(leadId);
      if (lead != null) {
        final updatedLead = lead.copyWith(type: newStatus);
        await _leadRepository.updateLead(updatedLead);   loadLeads();
      }
    } catch (e) {
      Get.snackbar('Warning', 'Failed to update lead status: ${e.toString()}');
    }
  }

  List<LeadModel> searchLeadsForFollowUp(String query) {
    return _leadRepository.searchLeads(query);
  }

  Future<void> deleteLead(String leadId) async {
    await _leadRepository.deleteLead(leadId);
    loadLeads();
  }
}

import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../core/app_colors.dart';
import '../../../../../core/app_data.dart';
import '../../../../../core/app_icons.dart';
import '../../../../../core/app_style.dart';
import '../../contoller/lead_controller.dart';
import '../../../../widgets/app_text_field.dart';
import '../../../../widgets/empty_state.dart';
import '../../model/lead_model.dart';
import '../widgets/lead_card.dart';
import 'lead_detail_page.dart';

class Leads extends GetView<LeadController> {
  const Leads({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Search and Filter Section
        _buildSearchFilterSection(context),
        
        // Leads List Section
        Expanded(
          child: Obx(() {
            final leads = controller.leads;
            if (leads.isEmpty) {
              return _buildEmptyState();
            }
            return _buildLeadsList(leads);
          }),
        ),
      ],
    );
  }

  Widget _buildSearchFilterSection(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          AppTextField(
            hintText: 'Search leads...',
            prefixIcon:  Image.asset(AppIcons.search,width: AppStyle.iconsize3,height: AppStyle.iconsize3,),
               
            onChanged: controller.searchLeads,
          ),
          const SizedBox(height: 10),
          _buildTypeFilterDropdown(),
          const SizedBox(height: 10),
        ],
      ),
    );
  }

  Widget _buildTypeFilterDropdown() {
    return Obx(
      () => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: const BorderRadius.all(Radius.circular(10)),
          boxShadow: AppStyle.boxShadow,
        ),
        child: DropdownButton<String>(
          value: controller.selectedType.value,
          items: ['All', ...AppData.leadTypes].map((type) {
            return DropdownMenuItem<String>(
              value: type,
              child: Text(
                type,
                style: TextStyle(
                  color: AppColors.getLeadTypeColor(type),
                ),
              ),
            );
          }).toList(),
          onChanged: (value) => controller.filterByType(value!),
          underline: const SizedBox(),
          isExpanded: true,
          icon: Icon(
            Icons.keyboard_arrow_down_outlined,
            color: Get.theme.primaryColor,
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return const EmptyState(
      icon: Icons.people_alt_outlined,
      title: 'No Leads Found',
      subtitle: 'Add your first lead to get started',
    );
  }

  Widget _buildLeadsList(List<LeadModel> leads) {
    return RefreshIndicator(
      onRefresh: () async => controller.loadLeads(),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: const BorderRadius.only(topLeft: Radius.circular(20),topRight: Radius.circular(20)),
          color: Colors.white,
          boxShadow: AppStyle.boxShadow
        ),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        child: ListView.custom(
          padding: const EdgeInsets.only(bottom: 16),
          childrenDelegate: SliverChildBuilderDelegate(
            (context, index) {
              final lead = leads[index];
              return LeadCard(
                lead: lead,
                onTap: () => Get.to(() => LeadDetailPage(lead: lead)),
              );
            },
            childCount: leads.length,
            // Better estimation for dynamic item heights
            findChildIndexCallback: (Key key) {
              final ValueKey valueKey = key as ValueKey;
              final int index = int.parse(valueKey.value);
              return index;
            },
          ),
        ),
      ),
    );
  }
}
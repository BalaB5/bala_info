import 'package:flutter/material.dart';
import 'package:flutter_phone_direct_caller/flutter_phone_direct_caller.dart';
import 'package:get/get.dart';

import '../../../../../core/app_colors.dart';
import '../../../../../core/app_icons.dart';
import '../../../../../core/app_style.dart';
import '../../../../utils/utils.dart';
import '../../model/lead_model.dart';

class LeadCard extends StatelessWidget {
  final LeadModel lead;
  final VoidCallback onTap;

  const LeadCard({super.key, required this.lead, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      margin: const EdgeInsets.symmetric(vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
        border: Border(
          left: BorderSide(
            color: AppColors.getLeadTypeColor(lead.type),
            width: 5.0,
          ),
        ),
        boxShadow:  AppStyle.boxShadow,
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [

                    Text(
                      Utils.capitalizeFirstLetter(lead.name),
                      style: Get.theme.textTheme.bodyMedium!.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      '${lead.city}, ${lead.state}',
                      style: Get.theme.textTheme.bodyMedium,
                    ),
                  ],
                ),
                IconButton(
                  padding: EdgeInsets.all(0),
                  onPressed: () {
                    FlutterPhoneDirectCaller.callNumber(lead.phone);
                  },
                  icon: 
                  Image.asset(AppIcons.call,width: AppStyle.iconsize,height: AppStyle.iconsize,),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

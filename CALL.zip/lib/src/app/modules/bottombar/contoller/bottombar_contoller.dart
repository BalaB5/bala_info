import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../calls/views/screens/call_logs.dart';
import '../../calls/views/screens/unsave_calls.dart';
import '../../leads/views/screens/leads.dart';
import '../../main/view/screens/dashboard.dart';

class BottomBarContoller extends GetxController {
  final RxList<Widget> pages =
      <Widget>[Dashboard(), CallLogs(), Leads(), UnsaveCalls()].obs;
  final RxInt selectedIndex = 0.obs;
  late final PageController pageController;

  @override
  void onInit() {
    super.onInit();
    pageController = PageController(initialPage: selectedIndex.value);
  }

  @override
  void onClose() {
    pageController.dispose();
    super.onClose();
  }
}

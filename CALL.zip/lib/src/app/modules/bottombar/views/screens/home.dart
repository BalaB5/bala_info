import 'package:call_tracker/src/core/app_icons.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../utils/routes/app_pages.dart';
import '../../../../../core/app_style.dart';
import '../../contoller/bottombar_contoller.dart';
import '../../model/bottom_nav_bar_item.dart';
import '../widgets/bottom_nav_bar.dart';

class Home extends GetView<BottomBarContoller> {
  const Home({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              const Color.fromARGB(255, 217, 152, 228).withAlpha(40),
              const Color.fromARGB(255, 96, 171, 194).withAlpha(40),
              const Color.fromARGB(255, 149, 207, 255).withAlpha(40),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Scaffold(
          backgroundColor:  Colors.transparent,
          drawer: Drawer(),
          appBar: AppBar(
            
            title: Text(
              "Call Tracker",
              style: Get.theme.textTheme.titleLarge!.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),

            backgroundColor:  Colors.white,
            // leading: Padding(
            //   padding: const EdgeInsets.symmetric(horizontal: 10),
            //   child: CircleAvatar(),
            // ),
            actions: [
              // IconButton(
              //   onPressed: () {
              //     Get.toNamed(AppPages.callRecord);
              //   },
              //   icon: Image.asset(
              //     AppIcons.callRing,
              //     width: AppStyle.iconsize,
              //     height: AppStyle.iconsize,
              //   ),
              // ),
              IconButton(
                onPressed: () {
                  Get.toNamed(AppPages.notification);
                },
                icon: Image.asset(
                  AppIcons.notification,
                  width: AppStyle.iconsize,
                  color: Get.theme.primaryColor,
                  height: AppStyle.iconsize,
                ),
              ),
              Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: CircleAvatar(),
            ),
            ],
          ),
          body: SafeArea(
            child: PageView.builder(
              controller: controller.pageController,
              itemCount: controller.pages.length,
              itemBuilder: (context, index) {
                return controller.pages[index];
              },
              onPageChanged: (index) {
                controller.selectedIndex.value = index;
              },
            ),
          ),
          floatingActionButton: Obx(() {
            return controller.selectedIndex.value == 1
                ? FloatingActionButton(
                  elevation: 2,
                  onPressed: () {
                    Get.toNamed(AppPages.dialPad);
                  },
                  child: Icon(Icons.dialpad),
                )
                : Container();
          }),
          bottomNavigationBar: Obx(() {
            return BottomNavBar(
              key: ValueKey("ButtomBar"),
              curentIndex: controller.selectedIndex.value,
              backgroundColor:  Colors.white,
            
              selectColor: Get.theme.colorScheme.secondaryContainer,
              onTap: (index) {
                controller.selectedIndex.value = index;
                controller.pageController.jumpToPage(index);
              },
              children: [
                BottomNavBarItem(
                  title: 'Dashboard',
                  icon: AppIcons.menu,
                  color: Colors.deepOrange,
                ),
                BottomNavBarItem(
                  title: 'Call Log',
                  icon: AppIcons.call,
                  color: Get.theme.primaryColor,
                ),
                // BottomNavBarItem(
                //   title: 'Message',
                //   icon: AppIcons.userlist,
                //   color: Colors.green,
                // ),
                BottomNavBarItem(
                  title: 'Leads',
                  icon: AppIcons.userlist,
                  color: Colors.pink,
                ),
                BottomNavBarItem(
                  title: "Unsave",
                  icon: AppIcons.unknownUser,
                  color: Colors.blue,
                ),
              ],
            );
          }),
        ),
      ),
    );
  }
}

import 'package:call_tracker/src/core/app_data.dart';
import 'package:get/get.dart';

import '../../../utils/repository/followup_repository.dart';
import '../../../utils/repository/lead_repository.dart';
import '../model/followup_model.dart';
import '../../leads/model/lead_model.dart';

class FollowUpController extends GetxController {
  final FollowUpRepository _followUpRepository = Get.find();
  final LeadRepository _leadRepository = Get.find();

  final RxList<FollowUpModel> followUps = <FollowUpModel>[].obs;
  final RxList<FollowUpModel> todayFollowUps = <FollowUpModel>[].obs;
  final RxList<FollowUpModel> upcomingFollowUps = <FollowUpModel>[].obs;
  final RxString searchQuery = ''.obs;
  final RxString fillter = 'All'.obs;
  final RxString todayListFillter = 'All'.obs;
  final RxBool isLoading = false.obs;

  //Today's follow-up counts
  final RxInt todayOverallFollowUpsCount = 0.obs;
  final RxInt todayUpdatedFollowUpsCount = 0.obs;

  final RxInt todayPendingFollowUpsCount = 0.obs;

  @override
  void onInit() {
    _loadInitialData();
    super.onInit();
  }

  Future<void> _loadInitialData() async {
    isLoading.value = true;
    try {
      await Future.wait([
        loadFollowUps(),
        loadTodayFollowUps(),
        loadUpcomingFollowUps(),
      ]);
      // Update the counts after loading data
      updateTodayFollowUpCounts();
    } catch (e) {
      Get.snackbar('Error', 'Failed to load follow-ups: ${e.toString()}');
    } finally {
      isLoading.value = false;
    }
  }

  // New method to update today's follow-up counts
  void updateTodayFollowUpCounts() {
    todayOverallFollowUpsCount.value = todayFollowUps.length;
    todayUpdatedFollowUpsCount.value =
        todayFollowUps
            .where((followUp) => followUp.status != AppData.followupStatus[0])
            .length;
    todayPendingFollowUpsCount.value =
        todayFollowUps
            .where((followUp) => followUp.status == AppData.followupStatus[1])
            .length;
  }

  Future<void> loadFollowUps() async {
    followUps.value = _followUpRepository.getAllFollowUps();
  }

  Future<void> loadTodayFollowUps() async {
    todayFollowUps.value = _followUpRepository.getTodayFollowUps();
    updateTodayFollowUpCounts(); // Update counts when today's follow-ups are loaded
  }

  Future<void> loadUpcomingFollowUps() async {
    upcomingFollowUps.value = await _followUpRepository.getUpcomingFollowUps();
  }

  void searchFollowUps(String query) {
    searchQuery.value = query;
    if (query.isEmpty && fillter.value == 'All') {
      loadFollowUps();
    } else if (query.isEmpty) {
      followUps.value = _followUpRepository.filterFollowUpsByStatus(
        fillter.value,
      );
    } else if (fillter.value == 'All') {
      followUps.value = _followUpRepository.searchFollowUps(query);
    } else {
      followUps.value =
          _followUpRepository
              .filterFollowUpsByStatus(fillter.value)
              .where(
                (fu) => fu.reason.toLowerCase().contains(query.toLowerCase()),
              )
              .toList();
    }
  }

  void filterByStatus(String status) async {
    fillter.value = status;
    isLoading.value = true;

    await Future.delayed(Duration(milliseconds: 1)); // Yield to UI thread

    final filtered =
        status == 'All'
            ? _followUpRepository.getAllFollowUps()
            : _followUpRepository.filterFollowUpsByStatus(status);

    if (status != 'All') {
      followUps.value =
          filtered
              .where(
                (fu) => fu.reason.toLowerCase().contains(
                  searchQuery.value.toLowerCase(),
                ),
              )
              .toList();
    } else {
      followUps.value = filtered;
    }

    isLoading.value = false;
  }

  void filterTodayFolloUpByStatus(String status) async {
    todayListFillter.value = status;
    isLoading.value = true;

    await Future.delayed(Duration(milliseconds: 1)); // Yield to UI thread

    final filtered =
        status == 'All'
            ? _followUpRepository.getTodayFollowUps()
            : _followUpRepository.filterTodayFollowUpsByStatus(status);

    if (status != 'All') {
      todayFollowUps.value =
          filtered
              .where(
                (fu) => fu.reason.toLowerCase().contains(
                  searchQuery.value.toLowerCase(),
                ),
              )
              .toList();
    } else {
      todayFollowUps.value = filtered;
    }

    isLoading.value = false;
    updateTodayFollowUpCounts(); // Update counts after filtering
  }

  Future<void> addFollowUp(FollowUpModel followUp) async {
    isLoading.value = true;
    try {
      await _followUpRepository.addFollowUp(followUp);
      await _refreshData();
      Get.back();
      Get.snackbar('Success', 'Follow-up added successfully',backgroundColor: Get.theme.colorScheme.secondaryContainer);
    } catch (e) {
      Get.snackbar('Error', 'Failed to add follow-up: ${e.toString()}');
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> updateFollowUp(FollowUpModel followUp) async {
    isLoading.value = true;
    try {
      await _followUpRepository.updateFollowUp(followUp);
      await _refreshData();
      Get.back();
      Get.snackbar(
        'Success',
        'Follow-up updated successfully',
        backgroundColor: Get.theme.colorScheme.secondaryContainer
      );
    } catch (e) {
      Get.snackbar('Error', 'Failed to update follow-up: ${e.toString()}');
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> deleteFollowUp(String followUpId) async {
    isLoading.value = true;
    try {
      await _followUpRepository.deleteFollowUp(followUpId);
      await _refreshData();
      Get.snackbar('Success', 'Follow-up deleted successfully',backgroundColor: Get.theme.colorScheme.secondaryContainer);
    } catch (e) {
      Get.snackbar('Error', 'Failed to delete follow-up: ${e.toString()}');
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> _refreshData() async {
    await Future.wait([
      loadFollowUps(),
      loadTodayFollowUps(),
      loadUpcomingFollowUps(),
    ]);
    updateTodayFollowUpCounts(); // Update counts after refreshing data
  }

  Future<void> updateLeadStatus(String leadId, String newStatus) async {
    try {
      final lead = _leadRepository.getLeadById(leadId);
      if (lead != null) {
        final updatedLead = lead.copyWith(type: newStatus);
        await _leadRepository.updateLead(updatedLead);
      }
    } catch (e) {
      Get.snackbar('Warning', 'Failed to update lead status: ${e.toString()}');
    }
  }

  List<LeadModel> searchLeadsForFollowUp(String query) {
    return _leadRepository.searchLeads(query);
  }

  List<FollowUpModel> getFollowUpsByLeadId(String leadId) {
    return _followUpRepository.getFollowUpsByLeadId(leadId);
  }
}

// followup_card.dart
import 'package:flutter/material.dart';
import 'package:flutter_phone_direct_caller/flutter_phone_direct_caller.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import '../../../../../core/app_colors.dart';
import '../../../../../core/app_icons.dart';
import '../../../../../core/app_style.dart';
import '../../../../utils/repository/lead_repository.dart';
import '../../../../utils/utils.dart';
import '../../../leads/contoller/lead_controller.dart';
import '../../model/followup_model.dart';

class FollowUpCard extends StatelessWidget {
 final FollowUpModel followUp;
 final VoidCallback onTap;
 final bool noCall ;
  final leadcon = Get.put(LeadController());
  FollowUpCard({
    super.key,
    required this.followUp,
    required this.onTap,
    this.noCall = true,
  });

  @override
  Widget build(BuildContext context) {
    final lead = Get.find<LeadRepository>().getLeadById(followUp.leadId);

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 4),
      decoration: AppStyle.decoration.copyWith(border: Border(
          left: BorderSide(
            color: AppColors.getFolloupsStatusColor(followUp.status),
            width: 5.0,
          ),
        )),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 5),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    lead != null ?Utils.capitalizeFirstLetter( lead.name ): "",
                    style: Get.theme.textTheme.bodyMedium!.copyWith(
                      fontWeight: FontWeight.bold,
                      color: Get.theme.primaryColor,
                    ),
                  ),  
                  Text(
                    lead != null ?Utils.capitalizeFirstLetter( followUp.reason ): "",
                    // style: Get.theme.textTheme.bodyMedium!.copyWith(
                    //   // fontWeight: FontWeight.bold,
                    //   color: Get.theme.primaryColor,
                    // ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Row(
                        children: [
                         Image.asset(AppIcons.calendar,width: AppStyle.iconsize2,height: AppStyle.iconsize2,),
                          Text(
                            '${followUp.followUpDate.day}/${followUp.followUpDate.month}/${followUp.followUpDate.year}',
                            style: Get.theme.textTheme.bodyMedium,
                          ),
                        ],
                      ),
                      const SizedBox(width: 8),
                      Row(
                        children: [
                            // Icon(Icons.access_time,color:  Get.theme.primaryColor),
                         Image.asset(AppIcons.time,width: AppStyle.iconsize2,height: AppStyle.iconsize2,),
                          Text(
                            DateFormat('h:mm a').format(followUp.followUpDate),
                            style: Get.theme.textTheme.bodyMedium,
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
              if (noCall)
                IconButton(
                  onPressed: () {
                    if (lead != null) {
                      FlutterPhoneDirectCaller.callNumber(lead.phone);
                    }
                  },
                  icon: Image.asset(AppIcons.call,width: AppStyle.iconsize,height: AppStyle.iconsize,),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

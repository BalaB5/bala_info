import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../core/app_style.dart';

class BuildLeadInfoRow extends StatelessWidget {
final String icon; final String text;
  const BuildLeadInfoRow({super.key,required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Image.asset(icon,width: AppStyle.iconsize2,height: AppStyle.iconsize2,),
        const SizedBox(width: 12),
        Text(text, style: Get.theme.textTheme.bodyLarge),
      ],
    );
  }
}

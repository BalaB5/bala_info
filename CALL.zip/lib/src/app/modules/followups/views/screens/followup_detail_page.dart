import 'package:flutter/material.dart';
import 'package:flutter_phone_direct_caller/flutter_phone_direct_caller.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../../../../../core/app_colors.dart';
import '../../../../../core/app_data.dart';
import '../../../../../core/app_icons.dart';
import '../../../../../core/app_style.dart';
import '../../../../utils/repository/lead_repository.dart';
import '../../../../utils/utils.dart';
import '../../../../widgets/app_text_field.dart';
import '../../contoller/followup_controller.dart';
import '../../model/followup_model.dart';
import '../../../leads/model/lead_model.dart';
import '../widgets/build_detail_item.dart';
import '../widgets/build_lead_info_row.dart';

class FollowUpDetailPage extends StatefulWidget {
  final FollowUpModel followUp;
  final LeadModel? lead;

  const FollowUpDetailPage({super.key, required this.followUp, this.lead});

  @override
  State<FollowUpDetailPage> createState() => _FollowUpDetailPageState();
}

class _FollowUpDetailPageState extends State<FollowUpDetailPage> {
  String? _selectedStatus;
  final controller = Get.find<FollowUpController>();
  final TextEditingController _momController = TextEditingController();
  bool isUpdate = false;
  String? _selectedType;
  LeadModel? lead;
  @override
  void initState() {
    super.initState();
    _selectedStatus = widget.followUp.status;
    lead =
        widget.lead ??
        Get.find<LeadRepository>().getLeadById(widget.followUp.leadId);
    _selectedType = lead!.type;
  }

  @override
  Widget build(BuildContext context) {
    bool isFollowUpDateToday() {
      final followUpDate = widget.followUp.followUpDate;
      final now = DateTime.now();
      return followUpDate.year == now.year &&
          followUpDate.month == now.month &&
          followUpDate.day == now.day;
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Follow Up Details',
          style: Get.theme.textTheme.headlineSmall,
        ),
        centerTitle: true,
        elevation: 0,
      ),
      body: ListView(
        padding: const EdgeInsets.all(10),
        children: [
          if (lead != null) ...[
            Container(
             
            decoration: AppStyle.decoration,
              padding: const EdgeInsets.all(10),
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Lead Information',
                      style: Get.theme.textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                        color: Get.theme.primaryColor,
                      ),
                    ),
                    const SizedBox(height: 10),
                    BuildLeadInfoRow(
                      icon: AppIcons.user3,
                      text: Utils.capitalizeFirstLetter(lead!.name),
                    ),
                    const SizedBox(height: 10),
                    BuildLeadInfoRow(
                      icon: AppIcons.call,
                      text: lead!.phone,
                    ),
                    const SizedBox(height: 10),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),
          ],

          // Status Update Section
          Container(
            decoration: AppStyle.decoration,
              padding: const EdgeInsets.all(10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Status',
                  style: Get.theme.textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: Get.theme.primaryColor,
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          color: Get.theme.cardColor,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                            color: Colors.grey.shade300,
                            width: 1,
                          ),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 12),
                          child: DropdownButton<String>(
                            value: _selectedStatus,
                            isExpanded: true,
                            items:
                                AppData.followupStatus.map((status) {
                                  return DropdownMenuItem<String>(
                                    value: status,
                                    child: Text(
                                      status,
                                      style: TextStyle(
                                        color:
                                            AppColors.getFolloupsStatusColor(
                                              status,
                                            ),
                                      ),
                                    ),
                                  );
                                }).toList(),
                            onChanged:
                                isFollowUpDateToday()
                                    ? (value) {
                                      setState(() {
                                        _selectedStatus = value;
                                        isUpdate = true;
                                      });
                                    }
                                    : null,
                            underline: const SizedBox(),
            
                            icon:
                                isFollowUpDateToday()
                                    ? Icon(
                                      Icons.keyboard_arrow_down_outlined,
                                      color: Get.theme.primaryColor,
                                    )
                                    : const SizedBox(),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    InkWell(
                      onTap: () async {
                        if (lead != null) {
                          await FlutterPhoneDirectCaller.callNumber(
                            lead!.phone,
                          );
                        }
                      },
                      child: Container(
                        height: 50,
                        width: 50,
                        decoration: BoxDecoration(
                          color: Colors.green,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Image.asset(AppIcons.call,width: AppStyle.iconsize3,height: AppStyle.iconsize3,color: Colors.white, ),
                        ),
                      ),
                    ),
                  ],
                ),
                if (isFollowUpDateToday())
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    margin: const EdgeInsets.symmetric(vertical: 8),
                    decoration: BoxDecoration(
                      color: Get.theme.cardColor,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: Colors.grey.shade300,
                        width: 1,
                      ),
                    ),
                    child: DropdownButton<String>(
                      value: _selectedType,
                      underline: const SizedBox(),
                      isExpanded: true,
                      icon:
                          isFollowUpDateToday()
                              ? Icon(
                                Icons.keyboard_arrow_down_outlined,
                                color: Get.theme.primaryColor,
                              )
                              : const SizedBox(),
                      items:
                          AppData.leadTypes.map((type) {
                            return DropdownMenuItem<String>(
                              value: type,
                              child: Text(
                                type,
                                style: TextStyle(
                                  color: AppColors.getLeadTypeColor(type),
                                  fontSize: 16,
                                ),
                              ),
                            );
                          }).toList(),
                      onChanged:
                          (value) => setState(() {
                            _selectedType = value!;
                            controller.updateLeadStatus(lead!.id, value);
                          }),
                    ),
                  ),
              ],
            ),
          ),

          const SizedBox(height: 10),

          // Follow Up Details Card
          Container(
            
            decoration: AppStyle.decoration,
              padding: const EdgeInsets.all(10),
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Follow Up Details',
                    style: Get.theme.textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: Get.theme.primaryColor,
                    ),
                  ),
                  const SizedBox(height: 10),
                  DetailItem(label: 'Reason', value: widget.followUp.reason),
                  DetailItem(label: 'Status', value: widget.followUp.status),

                  DetailItem(
                    label: 'Date',
                    value:
                        '${widget.followUp.followUpDate.day}/${widget.followUp.followUpDate.month}/${widget.followUp.followUpDate.year}',
                  ),
                  DetailItem(
                    label: 'Time',
                    value: DateFormat(
                      'h:mm a',
                    ).format(widget.followUp.followUpDate),
                  ),
                  if (widget.followUp.notes.isNotEmpty) ...[
                    const SizedBox(height: 10),
                    Text(
                      'Notes',
                      style: Get.theme.textTheme.bodyLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    // const SizedBox(height: 8),
                    Container(
                      width: double.infinity,
                      // padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        // color: Colors.grey.shade100,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        widget.followUp.notes,
                        style: Get.theme.textTheme.bodyMedium,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
          const SizedBox(height: 10),
          if(_selectedStatus == AppData.followupStatus[2]&& isUpdate && _selectedStatus!= widget.followUp.status)
          AppTextField(
            controller: _momController,
            labelText: 'MOM',
            maxLines: 3,
          ),
          const SizedBox(height: 10),
          // Update Button
          if (isUpdate && _selectedStatus!= widget.followUp.status)
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                InkWell(
                  child: Container(
                    height: 40,
                    // width: 60,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 18,
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: Get.theme.primaryColor,
                      borderRadius: BorderRadius.circular(10),
                      boxShadow: AppStyle.boxShadow,
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.save, color: Colors.white),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 10),
                          child: Text(
                            "Updated",
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ],
                    ),
                  ),
                  onTap: () async {
                    final followUp = widget.followUp;

                    final updatedFollowUp = followUp.copyWith(
                      status: _selectedStatus,
                    );
                    await controller.updateFollowUp(updatedFollowUp);
                  },
                ),
              ],
            ),
        ],
      ),
    );
  }
}

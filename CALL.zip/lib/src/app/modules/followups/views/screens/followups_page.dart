// followups_page.dart
import 'package:call_tracker/src/core/app_colors.dart';
import 'package:call_tracker/src/core/app_data.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../core/app_style.dart';
import '../../contoller/followup_controller.dart';
import '../../model/followup_model.dart';
import '../../../../widgets/empty_state.dart';
import '../widgets/followup_card.dart';
import 'followup_detail_page.dart';

class FollowUpsPage extends GetView<FollowUpController> {
  const FollowUpsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar( backgroundColor: Colors.white,
        title: Text('All Followups', style: Get.theme.textTheme.titleMedium!),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Column(
          children: [
            Column(
              children: [
                // AppTextField(
                //   hintText: 'Search followups...',
                //   prefixIcon: Icons.search,
                //   onChanged: controller.searchFollowUps,
                // ),
                Obx(
                  () => Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                      boxShadow:  AppStyle.boxShadow,
                    ),
                    padding: const  EdgeInsets.symmetric(horizontal: 8),
                    margin: const  EdgeInsets.symmetric(vertical: 8),
                    child: DropdownButtonFormField<String>(
                      initialValue: controller.fillter.value,
                      items:
                          ['All', ...AppData.followupStatus].map((status) {
                            return DropdownMenuItem<String>(
                              value: status,
                              child: Text(
                                status,
                                style: TextStyle(
                                  color: AppColors.getFolloupsStatusColor(
                                    status,
                                  ),
                                ),
                              ),
                            );
                          }).toList(),
                      onChanged: (value) => controller.filterByStatus(value!),
                      decoration: InputDecoration(
                        // labelText: 'Filter by status',
                        border: InputBorder.none,
                      ),
                      icon: Icon(
                        Icons.keyboard_arrow_down_outlined,
                        color: Get.theme.primaryColor,
                      ),
                    ),
                  ),
                ),
                // const SizedBox(height: 8),
              ],
            ),
            Expanded(
              child: Obx(() {
                if (controller.followUps.isEmpty) {
                  return EmptyState(
                    icon: Icons.calendar_today,
                    title: 'No Followups',
                    subtitle: 'Add your first followup to get started',
                  );
                }

                // Group followups by date
                final Map<DateTime, List<FollowUpModel>> groupedFollowUps = {};
                for (var followUp in controller.followUps) {
                  final date = DateTime(
                    followUp.followUpDate.year,
                    followUp.followUpDate.month,
                    followUp.followUpDate.day,
                  );

                  if (groupedFollowUps.containsKey(date)) {
                    groupedFollowUps[date]!.add(followUp);
                  } else {
                    groupedFollowUps[date] = [followUp];
                  }
                }

                // Sort dates
                final sortedDates =
                    groupedFollowUps.keys.toList()
                      ..sort((a, b) => b.compareTo(a));

                return RefreshIndicator(
                  onRefresh: () async => controller.loadFollowUps(),
                  child: ListView.builder(
                    padding: const EdgeInsets.only(bottom: 16),
                    itemCount: sortedDates.length,
                    itemBuilder: (context, index) {
                      final date = sortedDates[index];
                      final followUps = groupedFollowUps[date]!;

                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 16,
                              vertical: 8,
                            ),
                            child: Text(
                              '${date.day}/${date.month}/${date.year}',
                              style: Get.theme.textTheme.bodyMedium!.copyWith(
                                color: Get.theme.primaryColor,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          ...followUps.map(
                            (FollowUpModel followUp) => FollowUpCard(
                              followUp: followUp,
                              onTap:
                                  () => Get.to(
                                    () =>
                                        FollowUpDetailPage(followUp: followUp),
                                  ),
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                );
              }),
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:call_tracker/src/core/app_data.dart';
import 'package:call_tracker/src/core/app_icons.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../../../../../core/app_colors.dart';
import '../../../../../core/app_style.dart';
import '../../contoller/followup_controller.dart';
import '../../model/followup_model.dart';
import '../../../leads/model/lead_model.dart';
import '../../../../widgets/app_button.dart';
import '../../../../widgets/app_text_field.dart';

class AddFollowUpPage extends StatefulWidget {
  const AddFollowUpPage({super.key});

  @override
  State<AddFollowUpPage> createState() => _AddFollowUpPageState();
}

class _AddFollowUpPageState extends State<AddFollowUpPage> {
  final FollowUpController _controller = Get.find();
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _reasonController = TextEditingController();
  final TextEditingController _notesController = TextEditingController();
  final TextEditingController _leadSearchController = TextEditingController();

  String _selectedStatus = AppData.followupStatus[0];
  DateTime _selectedDate = DateTime.now();
  TimeOfDay _selectedTime = TimeOfDay.now();
  LeadModel? _selectedLead;

  @override
  void dispose() {
    _reasonController.dispose();
    _notesController.dispose();
    _leadSearchController.dispose();
    super.dispose();
  }

  Future<void> _selectDate() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime.now(),
      lastDate: DateTime(2100),
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  Future<void> _selectTime() async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: _selectedTime,
    );
    if (picked != null && picked != _selectedTime) {
      setState(() {
        _selectedTime = picked;
      });
    }
  }

  Future<void> _submitForm() async {
    if (_formKey.currentState!.validate() && _selectedLead != null) {
      final followUpDateTime = DateTime(
        _selectedDate.year,
        _selectedDate.month,
        _selectedDate.day,
        _selectedTime.hour,
        _selectedTime.minute,
      );

      final newFollowUp = FollowUpModel(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        leadId: _selectedLead!.id,
        followUpDate: followUpDateTime,
        reason: _reasonController.text,
        status: _selectedStatus,
        notes: _notesController.text,
        createdAt: DateTime.now(),
      );

      await _controller.addFollowUp(newFollowUp);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Follow Up', style: Get.theme.textTheme.titleMedium!),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                'Select Lead',
                style: Get.theme.textTheme.bodyMedium!.copyWith(
                  fontWeight: FontWeight.bold,
                  color: Get.theme.primaryColor,
                ),
              ),
              const SizedBox(height: 8),
              Autocomplete<LeadModel>(
                optionsBuilder: (TextEditingValue textEditingValue) {
                  if (textEditingValue.text.isEmpty) {
                    return const Iterable<LeadModel>.empty();
                  }
                  return _controller.searchLeadsForFollowUp(
                    textEditingValue.text,
                  );
                },
                onSelected: (LeadModel selection) {
                  setState(() {
                    _selectedLead = selection;
                    _leadSearchController.text = selection.name;
                  });
                },
                displayStringForOption:
                    (LeadModel option) => '${option.name} (${option.phone})',
                fieldViewBuilder: (
                  BuildContext context,
                  TextEditingController fieldTextEditingController,
                  FocusNode fieldFocusNode,
                  VoidCallback onFieldSubmitted,
                ) {
                  return AppTextField(
                    controller: fieldTextEditingController,
                    focusNode: fieldFocusNode,
                    hintText: 'Search lead by name or phone...',
                    prefixIcon:  Image.asset(AppIcons.search,width: AppStyle.iconsize,height: AppStyle.iconsize,),
               
                    validator: (value) {
                      if (_selectedLead == null &&
                          (value == null || value.isEmpty)) {
                        return 'Please select a lead';
                      }
                      return null;
                    },
                  );
                },
                optionsViewBuilder: (
                  BuildContext context,
                  AutocompleteOnSelected<LeadModel> onSelected,
                  Iterable<LeadModel> options,
                ) {
                  return Align(
                    alignment: Alignment.topLeft,
                    child: Material(
                      elevation: 4.0,
                      child: SizedBox(
                        height: 200,
                        child: ListView.builder(
                          padding: EdgeInsets.zero,
                          itemCount: options.length,
                          itemBuilder: (BuildContext context, int index) {
                            final LeadModel option = options.elementAt(index);
                            return ListTile(
                              title: Text(option.name),
                              subtitle: Text(option.phone),
                              onTap: () {
                                onSelected(option);
                              },
                            );
                          },
                        ),
                      ),
                    ),
                  );
                },
              ),
              if (_selectedLead != null)
                Container(
                  margin:  const EdgeInsets.symmetric(vertical: 8),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                    boxShadow:  AppStyle.boxShadow,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            _selectedLead!.name,
                            style: Get.theme.textTheme.bodyMedium!.copyWith(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          IconButton(
                            icon: const Icon(Icons.close),
                            onPressed: () {
                              setState(() {
                                _selectedLead = null;
                                _leadSearchController.clear();
                              });
                            },
                          ),
                        ],
                      ),
                      Text(_selectedLead!.phone),
                      if (_selectedLead!.city.isNotEmpty ||
                          _selectedLead!.state.isNotEmpty)
                        Text(
                          '${_selectedLead!.city}${', '}${_selectedLead!.state}',
                        ),
                    ],
                  ),
                ),
              const SizedBox(height: 16),
              Text(
                'Follow Up Date & Time',
                style: Get.theme.textTheme.bodyMedium!.copyWith(
                  fontWeight: FontWeight.bold,
                  color: Get.theme.primaryColor,
                ),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: Container(
                      padding: const  EdgeInsets.symmetric(horizontal: 8),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.all(Radius.circular(10)),
                        boxShadow:  AppStyle.boxShadow,
                      ),
                      child: InkWell(
                        onTap: _selectDate,
                        child: InputDecorator(
                          decoration: InputDecoration(
                            labelText: 'Date',
                            border: InputBorder.none,
                            suffixIcon:Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Image.asset(AppIcons.calendar,width: AppStyle.iconsize3,height: AppStyle.iconsize3,),
                            ),
                          ),
                          child: Text(
                            DateFormat('dd MMM yyyy').format(_selectedDate),
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Container(
                      padding: const  EdgeInsets.symmetric(horizontal: 8),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.all(Radius.circular(10)),
                        boxShadow:  AppStyle.boxShadow,
                      ),
                      child: InkWell(
                        onTap: _selectTime,
                        child: InputDecorator(
                          decoration: InputDecoration(
                            labelText: 'Time',
                            border: InputBorder.none,
                            suffixIcon: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Image.asset(AppIcons.time,width: AppStyle.iconsize3,height: AppStyle.iconsize3,),
                            ),
                          ),
                          child: Text(_selectedTime.format(context)),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Container(
                padding:  const  EdgeInsets.symmetric(horizontal: 8),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                  boxShadow:  AppStyle.boxShadow
                ),
                child: DropdownButtonFormField<String>(
                  initialValue: _selectedStatus,
                  items:
                      AppData.followupStatus.map((status) {
                        return DropdownMenuItem<String>(
                          value: status,
                          child: Text(status,style: TextStyle(color: AppColors.getFolloupsStatusColor(status)),),
                        );
                      }).toList(),
                  onChanged:
                      (value) => setState(() => _selectedStatus = value!),
                  decoration: InputDecoration(
                    labelText: 'Status',
                    border: InputBorder.none,
                  ),
                  icon: Icon(
                    Icons.keyboard_arrow_down_outlined,
                    color: Get.theme.primaryColor
                  ),
                ),
              ),
              const SizedBox(height: 16),
              AppTextField(
                controller: _reasonController,
                labelText: 'Reason',
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter reason';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              AppTextField(
                controller: _notesController,
                labelText: 'Notes',
                maxLines: 3,
              ),
              const SizedBox(height: 24),
              AppButton(
                text: 'Save Follow Up',
                onPressed: _submitForm,
                enabled: _selectedLead != null,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class AppInjection {
  
  
}
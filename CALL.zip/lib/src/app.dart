import 'package:call_tracker/src/app/utils/routes/routes.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'app/bindings/app_binding.dart';
import 'app/data/localization/app_translations.dart';
import 'app/utils/routes/app_pages.dart';
import 'core/theme.dart';

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) {
    TextTheme textTheme = createTextTheme(context, "Roboto", "Roboto");
    MaterialTheme theme = MaterialTheme(textTheme);
    return GetMaterialApp(
      initialRoute: AppPages.home,
      debugShowCheckedModeBanner: false,
      initialBinding: AppBinding(),
          locale: Get.deviceLocale,
    translations: AppTranslations(),
    fallbackLocale: const Locale('en', 'US'),
      theme: theme.light(),
      darkTheme: theme.dark(),
      themeMode: ThemeMode.light,
      getPages: Routes.pages,
    );
  }
}

import 'package:call_tracker/src/app.dart';
import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';

import 'src/app/modules/followups/model/followup_model.dart';
import 'src/app/modules/leads/model/lead_model.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
 await Hive.initFlutter();
  
  // Register Hive adapters
  Hive.registerAdapter(LeadModelAdapter());
  Hive.registerAdapter(FollowUpModelAdapter());
  
  // Open Hive boxes
  await Hive.openBox<LeadModel>('leads');
  await Hive.openBox<FollowUpModel>('followups');
  await Hive.openBox('tagsBox');
  runApp(const App());
}
